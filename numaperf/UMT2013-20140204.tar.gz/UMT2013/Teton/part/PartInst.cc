#include "geom/CMI/MeshBase.hh"
#include "Part.cc"

using namespace Geometry;

template class Part<MeshBase>;
