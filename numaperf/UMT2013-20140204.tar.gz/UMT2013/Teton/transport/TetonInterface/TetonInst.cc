#include "geom/CMI/MeshBase.hh"
#include <vector>
#include "transport/TetonInterface/Teton.cc"
using namespace Geometry;
 
template class Teton< MeshBase >;
