/* A Bison parser, made from parse.y
   by GNU bison 1.35.  */

#define YYBISON 1  /* Identify Bison output.  */

# define	IDENTIFIER	257
# define	tTYPENAME	258
# define	SELFNAME	259
# define	PFUNCNAME	260
# define	SCSPEC	261
# define	TYPESPEC	262
# define	CV_QUALIFIER	263
# define	CONSTANT	264
# define	VAR_FUNC_NAME	265
# define	STRING	266
# define	ELLIPSIS	267
# define	SIZEOF	268
# define	ENUM	269
# define	IF	270
# define	ELSE	271
# define	WHILE	272
# define	DO	273
# define	FOR	274
# define	SWITCH	275
# define	CASE	276
# define	DEFAULT	277
# define	BREAK	278
# define	CONTINUE	279
# define	RETURN_KEYWORD	280
# define	GOTO	281
# define	ASM_KEYWORD	282
# define	TYPEOF	283
# define	ALIGNOF	284
# define	SIGOF	285
# define	ATTRIBUTE	286
# define	EXTENSION	287
# define	LABEL	288
# define	REALPART	289
# define	IMAGPART	290
# define	VA_ARG	291
# define	AGGR	292
# define	VISSPEC	293
# define	DELETE	294
# define	NEW	295
# define	THIS	296
# define	OPERATOR	297
# define	CXX_TRUE	298
# define	CXX_FALSE	299
# define	NAMESPACE	300
# define	TYPENAME_KEYWORD	301
# define	USING	302
# define	LEFT_RIGHT	303
# define	TEMPLATE	304
# define	TYPEID	305
# define	DYNAMIC_CAST	306
# define	STATIC_CAST	307
# define	REINTERPRET_CAST	308
# define	CONST_CAST	309
# define	SCOPE	310
# define	EXPORT	311
# define	EMPTY	312
# define	PTYPENAME	313
# define	NSNAME	314
# define	THROW	315
# define	ASSIGN	316
# define	OROR	317
# define	ANDAND	318
# define	MIN_MAX	319
# define	EQCOMPARE	320
# define	ARITHCOMPARE	321
# define	LSHIFT	322
# define	RSHIFT	323
# define	POINTSAT_STAR	324
# define	DOT_STAR	325
# define	UNARY	326
# define	PLUSPLUS	327
# define	MINUSMINUS	328
# define	HYPERUNARY	329
# define	POINTSAT	330
# define	TRY	331
# define	CATCH	332
# define	EXTERN_LANG_STRING	333
# define	ALL	334
# define	PRE_PARSED_CLASS_DECL	335
# define	DEFARG	336
# define	DEFARG_MARKER	337
# define	PRE_PARSED_FUNCTION_DECL	338
# define	TYPENAME_DEFN	339
# define	IDENTIFIER_DEFN	340
# define	PTYPENAME_DEFN	341
# define	END_OF_LINE	342
# define	END_OF_SAVED_INPUT	343

#line 30 "parse.y"

#include "config.h"

#include "system.h"

#include "tree.h"
#include "input.h"
#include "flags.h"
#include "cp-tree.h"
#include "decl.h"
#include "lex.h"
#include "c-pragma.h"		/* For YYDEBUG definition.  */
#include "output.h"
#include "except.h"
#include "toplev.h"
#include "ggc.h"

/* Like YYERROR but do call yyerror.  */
#define YYERROR1 { yyerror ("syntax error"); YYERROR; }

/* Like the default stack expander, except (1) use realloc when possible,
   (2) impose no hard maxiumum on stack size, (3) REALLY do not use alloca.

   Irritatingly, YYSTYPE is defined after this %{ %} block, so we cannot
   give malloced_yyvs its proper type.  This is ok since all we need from
   it is to be able to free it.  */

static short *malloced_yyss;
static void *malloced_yyvs;

#define yyoverflow(MSG, SS, SSSIZE, VS, VSSIZE, YYSSZ)			\
do {									\
  size_t newsize;							\
  short *newss;								\
  YYSTYPE *newvs;							\
  newsize = *(YYSSZ) *= 2;						\
  if (malloced_yyss)							\
    {									\
      newss = (short *)							\
	really_call_realloc (*(SS), newsize * sizeof (short));		\
      newvs = (YYSTYPE *)						\
	really_call_realloc (*(VS), newsize * sizeof (YYSTYPE));	\
    }									\
  else									\
    {									\
      newss = (short *) really_call_malloc (newsize * sizeof (short));	\
      newvs = (YYSTYPE *) really_call_malloc (newsize * sizeof (YYSTYPE)); \
      if (newss)							\
        memcpy (newss, *(SS), (SSSIZE));				\
      if (newvs)							\
        memcpy (newvs, *(VS), (VSSIZE));				\
    }									\
  if (!newss || !newvs)							\
    {									\
      yyerror (MSG);							\
      return 2;								\
    }									\
  *(SS) = newss;							\
  *(VS) = newvs;							\
  malloced_yyss = newss;						\
  malloced_yyvs = (void *) newvs;					\
} while (0)
#define OP0(NODE) (TREE_OPERAND (NODE, 0))
#define OP1(NODE) (TREE_OPERAND (NODE, 1))

/* Contains the statement keyword (if/while/do) to include in an
   error message if the user supplies an empty conditional expression.  */
static const char *cond_stmt_keyword;

/* List of types and structure classes of the current declaration.  */
static GTY(()) tree current_declspecs;

/* List of prefix attributes in effect.
   Prefix attributes are parsed by the reserved_declspecs and declmods
   rules.  They create a list that contains *both* declspecs and attrs.  */
/* ??? It is not clear yet that all cases where an attribute can now appear in
   a declspec list have been updated.  */
static GTY(()) tree prefix_attributes;

/* When defining an enumeration, this is the type of the enumeration.  */
static GTY(()) tree current_enum_type;

/* When parsing a conversion operator name, this is the scope of the
   operator itself.  */
static GTY(()) tree saved_scopes;

static tree empty_parms PARAMS ((void));
static tree parse_decl0 PARAMS ((tree, tree, tree, tree, int));
static tree parse_decl PARAMS ((tree, tree, int));
static void parse_end_decl PARAMS ((tree, tree, tree));
static tree parse_field0 PARAMS ((tree, tree, tree, tree, tree, tree));
static tree parse_field PARAMS ((tree, tree, tree, tree));
static tree parse_bitfield0 PARAMS ((tree, tree, tree, tree, tree));
static tree parse_bitfield PARAMS ((tree, tree, tree));
static tree parse_method PARAMS ((tree, tree, tree));
static void frob_specs PARAMS ((tree, tree));
static void check_class_key PARAMS ((tree, tree));
static tree parse_scoped_id PARAMS ((tree));
static tree parse_xref_tag (tree, tree, int);
static tree parse_handle_class_head (tree, tree, tree, int, int *);
static void parse_decl_instantiation (tree, tree, tree);
static int parse_begin_function_definition (tree, tree);
static tree parse_finish_call_expr (tree, tree, int);

/* Cons up an empty parameter list.  */
static inline tree
empty_parms ()
{
  tree parms;

#ifndef NO_IMPLICIT_EXTERN_C
  if (in_system_header && current_class_type == NULL
      && current_lang_name == lang_name_c)
    parms = NULL_TREE;
  else
#endif
  parms = void_list_node;
  return parms;
}

/* Record the decl-specifiers, attributes and type lookups from the
   decl-specifier-seq in a declaration.  */

static void
frob_specs (specs_attrs, lookups)
     tree specs_attrs, lookups;
{
  save_type_access_control (lookups);
  split_specs_attrs (specs_attrs, &current_declspecs, &prefix_attributes);
  if (current_declspecs
      && TREE_CODE (current_declspecs) != TREE_LIST)
    current_declspecs = build_tree_list (NULL_TREE, current_declspecs);
  if (have_extern_spec)
    {
      /* We have to indicate that there is an "extern", but that it
         was part of a language specifier.  For instance,

    	    extern "C" typedef int (*Ptr) ();

         is well formed.  */
      current_declspecs = tree_cons (error_mark_node,
				     get_identifier ("extern"),
				     current_declspecs);
      have_extern_spec = false;
    }
}

static tree
parse_decl (declarator, attributes, initialized)
     tree declarator, attributes;
     int initialized;
{
  return start_decl (declarator, current_declspecs, initialized,
		     attributes, prefix_attributes);
}

static tree
parse_decl0 (declarator, specs_attrs, lookups, attributes, initialized)
     tree declarator, specs_attrs, lookups, attributes;
     int initialized;
{
  frob_specs (specs_attrs, lookups);
  return parse_decl (declarator, attributes, initialized);
}

static void
parse_end_decl (decl, init, asmspec)
     tree decl, init, asmspec;
{
  /* If decl is NULL_TREE, then this was a variable declaration using
     () syntax for the initializer, so we handled it in grokdeclarator.  */
  if (decl)
    decl_type_access_control (decl);
  cp_finish_decl (decl, init, asmspec, init ? LOOKUP_ONLYCONVERTING : 0);
}

static tree
parse_field (declarator, attributes, asmspec, init)
     tree declarator, attributes, asmspec, init;
{
  tree d = grokfield (declarator, current_declspecs, init, asmspec,
		      chainon (attributes, prefix_attributes));
  decl_type_access_control (d);
  return d;
}

static tree
parse_field0 (declarator, specs_attrs, lookups, attributes, asmspec, init)
     tree declarator, specs_attrs, lookups, attributes, asmspec, init;
{
  frob_specs (specs_attrs, lookups);
  return parse_field (declarator, attributes, asmspec, init);
}

static tree
parse_bitfield (declarator, attributes, width)
     tree declarator, attributes, width;
{
  tree d = grokbitfield (declarator, current_declspecs, width);
  cplus_decl_attributes (&d, chainon (attributes, prefix_attributes), 0);
  decl_type_access_control (d);
  return d;
}

static tree
parse_bitfield0 (declarator, specs_attrs, lookups, attributes, width)
     tree declarator, specs_attrs, lookups, attributes, width;
{
  frob_specs (specs_attrs, lookups);
  return parse_bitfield (declarator, attributes, width);
}

static tree
parse_method (declarator, specs_attrs, lookups)
     tree declarator, specs_attrs, lookups;
{
  tree d;
  frob_specs (specs_attrs, lookups);
  d = start_method (current_declspecs, declarator, prefix_attributes);
  decl_type_access_control (d);
  return d;
}

static void
check_class_key (key, aggr)
     tree key;
     tree aggr;
{
  if (TREE_CODE (key) == TREE_LIST)
    key = TREE_VALUE (key);
  if ((key == union_type_node) != (TREE_CODE (aggr) == UNION_TYPE))
    pedwarn ("`%s' tag used in naming `%#T'",
	     key == union_type_node ? "union"
	     : key == record_type_node ? "struct" : "class", aggr);
}


#line 270 "parse.y"
#ifndef YYSTYPE
typedef union { GTY(())
  long itype;
  tree ttype;
  char *strtype;
  enum tree_code code;
  flagged_type_tree ftype;
  struct unparsed_text *pi;
} yystype;
# define YYSTYPE yystype
# define YYSTYPE_IS_TRIVIAL 1
#endif
#line 477 "parse.y"

/* Tell yyparse how to print a token's value, if yydebug is set.  */
#define YYPRINT(FILE,YYCHAR,YYLVAL) yyprint(FILE,YYCHAR,YYLVAL)
extern void yyprint			PARAMS ((FILE *, int, YYSTYPE));
#ifndef YYDEBUG
# define YYDEBUG 0
#endif



#define	YYFINAL		1821
#define	YYFLAG		-32768
#define	YYNTBASE	114

/* YYTRANSLATE(YYLEX) -- Bison token number corresponding to YYLEX. */
#define YYTRANSLATE(x) ((unsigned)(x) <= 343 ? yytranslate[x] : 408)

/* YYTRANSLATE[YYLEX] -- Bison token number corresponding to YYLEX. */
static const char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   112,     2,     2,     2,    85,    73,     2,
      95,   110,    83,    81,    62,    82,    94,    84,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    65,    63,
      77,    67,    78,    68,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    96,     2,   113,    72,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    61,    71,   111,    91,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    60,    64,    66,    69,    70,    74,
      75,    76,    79,    80,    86,    87,    88,    89,    90,    92,
      93,    97,    98,    99,   100,   101,   102,   103,   104,   105,
     106,   107,   108,   109
};

#if YYDEBUG
static const short yyprhs[] =
{
       0,     0,     1,     3,     4,     7,    10,    12,    13,    14,
      15,    17,    19,    20,    23,    26,    28,    29,    33,    35,
      41,    46,    52,    57,    58,    65,    66,    72,    74,    77,
      79,    82,    83,    90,    93,    97,   101,   105,   109,   114,
     115,   121,   124,   128,   130,   132,   135,   138,   140,   143,
     144,   150,   154,   156,   158,   160,   164,   166,   167,   170,
     173,   177,   179,   183,   185,   189,   191,   195,   198,   201,
     204,   206,   208,   214,   219,   222,   225,   229,   233,   236,
     239,   243,   247,   250,   253,   256,   259,   262,   265,   267,
     269,   271,   273,   274,   276,   279,   280,   282,   283,   290,
     294,   298,   302,   303,   312,   318,   319,   329,   336,   337,
     346,   352,   353,   363,   370,   373,   376,   378,   381,   383,
     390,   399,   404,   411,   418,   423,   426,   428,   431,   434,
     436,   439,   441,   444,   447,   452,   455,   456,   460,   461,
     462,   464,   468,   471,   472,   474,   476,   478,   483,   486,
     488,   490,   492,   494,   496,   498,   500,   502,   504,   506,
     508,   510,   511,   518,   519,   526,   527,   533,   534,   540,
     541,   549,   550,   558,   559,   566,   567,   574,   575,   576,
     582,   588,   590,   592,   598,   604,   605,   607,   609,   610,
     612,   614,   618,   620,   622,   625,   627,   631,   633,   635,
     637,   639,   641,   643,   645,   647,   651,   653,   657,   658,
     660,   662,   663,   671,   673,   675,   679,   684,   688,   692,
     696,   700,   704,   706,   708,   710,   713,   716,   719,   722,
     725,   728,   731,   736,   739,   744,   747,   751,   755,   760,
     765,   771,   777,   784,   787,   792,   798,   801,   804,   808,
     812,   816,   818,   822,   825,   829,   834,   836,   839,   845,
     847,   851,   855,   859,   863,   867,   871,   875,   879,   883,
     887,   891,   895,   899,   903,   907,   911,   915,   919,   923,
     929,   933,   937,   939,   942,   944,   948,   952,   956,   960,
     964,   968,   972,   976,   980,   984,   988,   992,   996,  1000,
    1004,  1008,  1012,  1016,  1022,  1026,  1030,  1032,  1035,  1039,
    1043,  1045,  1047,  1049,  1051,  1053,  1054,  1060,  1066,  1072,
    1078,  1084,  1086,  1088,  1090,  1092,  1095,  1097,  1100,  1103,
    1107,  1112,  1117,  1119,  1121,  1123,  1127,  1129,  1131,  1133,
    1135,  1137,  1141,  1145,  1149,  1150,  1155,  1160,  1163,  1168,
    1171,  1178,  1183,  1186,  1189,  1191,  1196,  1198,  1206,  1214,
    1222,  1230,  1235,  1240,  1243,  1246,  1249,  1251,  1256,  1259,
    1262,  1268,  1272,  1275,  1278,  1284,  1288,  1294,  1298,  1303,
    1310,  1313,  1315,  1318,  1320,  1323,  1325,  1327,  1328,  1331,
    1334,  1338,  1342,  1346,  1349,  1352,  1355,  1357,  1359,  1361,
    1364,  1367,  1370,  1373,  1375,  1377,  1379,  1381,  1384,  1387,
    1391,  1395,  1399,  1404,  1406,  1409,  1412,  1414,  1416,  1419,
    1422,  1425,  1427,  1430,  1433,  1437,  1439,  1442,  1445,  1447,
    1449,  1451,  1453,  1455,  1457,  1459,  1464,  1469,  1474,  1479,
    1481,  1483,  1485,  1487,  1491,  1493,  1497,  1499,  1503,  1504,
    1509,  1510,  1517,  1521,  1522,  1527,  1529,  1533,  1537,  1538,
    1543,  1547,  1548,  1550,  1552,  1555,  1562,  1564,  1568,  1569,
    1571,  1576,  1583,  1588,  1590,  1592,  1594,  1596,  1598,  1602,
    1603,  1606,  1608,  1611,  1615,  1620,  1622,  1624,  1628,  1633,
    1637,  1643,  1647,  1651,  1655,  1656,  1660,  1664,  1668,  1669,
    1672,  1675,  1676,  1683,  1684,  1690,  1693,  1696,  1699,  1700,
    1701,  1702,  1714,  1716,  1717,  1719,  1720,  1722,  1724,  1727,
    1730,  1733,  1736,  1739,  1742,  1746,  1751,  1755,  1758,  1762,
    1767,  1769,  1772,  1774,  1777,  1780,  1783,  1786,  1790,  1794,
    1797,  1798,  1801,  1805,  1807,  1812,  1814,  1818,  1820,  1822,
    1825,  1828,  1832,  1836,  1837,  1839,  1843,  1846,  1849,  1851,
    1854,  1857,  1860,  1863,  1866,  1869,  1872,  1874,  1877,  1880,
    1884,  1886,  1889,  1892,  1897,  1902,  1905,  1907,  1913,  1918,
    1920,  1921,  1923,  1927,  1928,  1930,  1934,  1936,  1938,  1940,
    1942,  1947,  1952,  1957,  1962,  1967,  1971,  1976,  1981,  1986,
    1991,  1995,  1998,  2000,  2002,  2006,  2008,  2012,  2015,  2017,
    2024,  2025,  2028,  2030,  2033,  2035,  2038,  2042,  2046,  2048,
    2052,  2054,  2057,  2061,  2065,  2068,  2071,  2075,  2077,  2082,
    2087,  2091,  2095,  2098,  2100,  2102,  2105,  2107,  2109,  2112,
    2115,  2117,  2120,  2124,  2128,  2131,  2134,  2138,  2140,  2144,
    2148,  2151,  2154,  2158,  2160,  2165,  2169,  2174,  2178,  2180,
    2183,  2186,  2189,  2192,  2195,  2198,  2201,  2203,  2206,  2211,
    2216,  2219,  2221,  2223,  2225,  2227,  2230,  2235,  2239,  2243,
    2246,  2249,  2252,  2255,  2257,  2260,  2263,  2266,  2269,  2273,
    2275,  2278,  2282,  2287,  2290,  2293,  2296,  2299,  2302,  2305,
    2310,  2313,  2315,  2318,  2321,  2325,  2327,  2331,  2334,  2338,
    2341,  2344,  2348,  2350,  2354,  2359,  2361,  2364,  2368,  2371,
    2374,  2376,  2380,  2383,  2386,  2388,  2391,  2395,  2397,  2401,
    2408,  2413,  2418,  2422,  2428,  2432,  2436,  2440,  2443,  2445,
    2447,  2450,  2453,  2456,  2457,  2459,  2461,  2464,  2468,  2469,
    2474,  2476,  2477,  2478,  2484,  2486,  2487,  2491,  2493,  2496,
    2498,  2501,  2502,  2507,  2509,  2510,  2511,  2517,  2518,  2519,
    2527,  2528,  2529,  2530,  2531,  2544,  2545,  2546,  2554,  2555,
    2561,  2562,  2570,  2571,  2576,  2579,  2582,  2585,  2589,  2596,
    2605,  2616,  2625,  2638,  2649,  2660,  2665,  2669,  2672,  2675,
    2677,  2679,  2681,  2683,  2685,  2686,  2687,  2693,  2694,  2695,
    2701,  2703,  2706,  2707,  2708,  2709,  2715,  2717,  2719,  2723,
    2727,  2730,  2733,  2736,  2739,  2742,  2744,  2747,  2748,  2750,
    2751,  2753,  2755,  2756,  2758,  2760,  2764,  2769,  2777,  2779,
    2783,  2784,  2786,  2788,  2790,  2793,  2796,  2799,  2801,  2804,
    2807,  2808,  2812,  2814,  2816,  2818,  2821,  2824,  2827,  2832,
    2835,  2838,  2841,  2844,  2847,  2850,  2852,  2855,  2857,  2860,
    2862,  2864,  2865,  2866,  2868,  2874,  2878,  2879,  2883,  2884,
    2885,  2890,  2893,  2895,  2897,  2899,  2903,  2904,  2908,  2912,
    2916,  2918,  2919,  2923,  2927,  2931,  2935,  2939,  2943,  2947,
    2951,  2955,  2959,  2963,  2967,  2971,  2975,  2979,  2983,  2987,
    2991,  2995,  2999,  3003,  3007,  3011,  3016,  3020,  3024,  3028,
    3032,  3037,  3041,  3045,  3051,  3057,  3062,  3066
};
static const short yyrhs[] =
{
      -1,   115,     0,     0,   116,   122,     0,   115,   122,     0,
     115,     0,     0,     0,     0,    33,     0,    28,     0,     0,
     123,   124,     0,   155,   152,     0,   149,     0,     0,    57,
     125,   146,     0,   146,     0,   121,    95,    12,   110,    63,
       0,   136,    61,   117,   111,     0,   136,   118,   155,   119,
     152,     0,   136,   118,   149,   119,     0,     0,    46,   172,
      61,   126,   117,   111,     0,     0,    46,    61,   127,   117,
     111,     0,   128,     0,   130,    63,     0,   132,     0,   120,
     124,     0,     0,    46,   172,    67,   129,   135,    63,     0,
      48,   316,     0,    48,   330,   316,     0,    48,   330,   215,
       0,    48,   134,   172,     0,    48,   330,   172,     0,    48,
     330,   134,   172,     0,     0,    48,    46,   133,   135,    63,
       0,    60,    56,     0,   134,    60,    56,     0,   215,     0,
     316,     0,   330,   316,     0,   330,   215,     0,    99,     0,
     136,    99,     0,     0,    50,    77,   138,   141,    78,     0,
      50,    77,    78,     0,   137,     0,   139,     0,   145,     0,
     141,    62,   145,     0,   172,     0,     0,   276,   142,     0,
      47,   142,     0,   137,   276,   142,     0,   143,     0,   143,
      67,   230,     0,   394,     0,   394,    67,   210,     0,   144,
       0,   144,    67,   193,     0,   140,   147,     0,   140,     1,
       0,   155,   152,     0,   148,     0,   146,     0,   136,   118,
     155,   119,   152,     0,   136,   118,   148,   119,     0,   120,
     147,     0,   244,    63,     0,   234,   243,    63,     0,   231,
     242,    63,     0,   268,    63,     0,   244,    63,     0,   234,
     243,    63,     0,   231,   242,    63,     0,   234,    63,     0,
     175,    63,     0,   231,    63,     0,     1,    63,     0,     1,
     111,     0,     1,   109,     0,    63,     0,   397,     0,   225,
       0,   166,     0,     0,   165,     0,   165,    63,     0,     0,
     109,     0,     0,   168,   150,   407,    61,   154,   201,     0,
     161,   151,   153,     0,   161,   151,   365,     0,   161,   151,
       1,     0,     0,   321,     5,    95,   157,   385,   110,   303,
     400,     0,   321,     5,    49,   303,   400,     0,     0,   330,
     321,     5,    95,   158,   385,   110,   303,   400,     0,   330,
     321,     5,    49,   303,   400,     0,     0,   321,   188,    95,
     159,   385,   110,   303,   400,     0,   321,   188,    49,   303,
     400,     0,     0,   330,   321,   188,    95,   160,   385,   110,
     303,   400,     0,   330,   321,   188,    49,   303,   400,     0,
     231,   228,     0,   234,   313,     0,   313,     0,   234,   156,
       0,   156,     0,     5,    95,   385,   110,   303,   400,     0,
      95,     5,   110,    95,   385,   110,   303,   400,     0,     5,
      49,   303,   400,     0,    95,     5,   110,    49,   303,   400,
       0,   188,    95,   385,   110,   303,   400,     0,   188,    49,
     303,   400,     0,   234,   162,     0,   162,     0,   231,   228,
       0,   234,   313,     0,   313,     0,   234,   156,     0,   156,
       0,    26,     3,     0,   164,   261,     0,   164,    95,   203,
     110,     0,   164,    49,     0,     0,    65,   167,   169,     0,
       0,     0,   171,     0,   169,    62,   171,     0,   169,     1,
       0,     0,   173,     0,   309,     0,   323,     0,   170,    95,
     203,   110,     0,   170,    49,     0,     1,     0,     3,     0,
       4,     0,     5,     0,    59,     0,    60,     0,     3,     0,
      59,     0,    60,     0,   106,     0,   105,     0,   107,     0,
       0,    50,   184,   240,    63,   176,   185,     0,     0,    50,
     184,   231,   228,   177,   185,     0,     0,    50,   184,   313,
     178,   185,     0,     0,    50,   184,   156,   179,   185,     0,
       0,     7,    50,   184,   240,    63,   180,   185,     0,     0,
       7,    50,   184,   231,   228,   181,   185,     0,     0,     7,
      50,   184,   313,   182,   185,     0,     0,     7,    50,   184,
     156,   183,   185,     0,     0,     0,    59,    77,   191,   190,
     189,     0,     4,    77,   191,   190,   189,     0,   188,     0,
     186,     0,   172,    77,   191,    78,   189,     0,     5,    77,
     191,   190,   189,     0,     0,    78,     0,    80,     0,     0,
     192,     0,   193,     0,   192,    62,   193,     0,   230,     0,
      59,     0,   330,    59,     0,   210,     0,   321,    50,   172,
       0,    82,     0,    81,     0,    89,     0,    90,     0,   112,
       0,   202,     0,   209,     0,    49,     0,    95,   195,   110,
       0,    49,     0,    95,   199,   110,     0,     0,   199,     0,
       1,     0,     0,   375,   228,   245,   254,    67,   200,   262,
       0,   195,     0,   111,     0,   338,   336,   111,     0,   338,
     336,     1,   111,     0,   338,     1,   111,     0,   209,    62,
     209,     0,   209,    62,     1,     0,   202,    62,   209,     0,
     202,    62,     1,     0,   209,     0,   202,     0,   220,     0,
     120,   208,     0,    83,   208,     0,    73,   208,     0,    91,
     208,     0,   194,   208,     0,    70,   172,     0,   237,   204,
       0,   237,    95,   230,   110,     0,   238,   204,     0,   238,
      95,   230,   110,     0,   222,   302,     0,   222,   302,   206,
       0,   222,   205,   302,     0,   222,   205,   302,   206,     0,
     222,    95,   230,   110,     0,   222,    95,   230,   110,   206,
       0,   222,   205,    95,   230,   110,     0,   222,   205,    95,
     230,   110,   206,     0,   223,   208,     0,   223,    96,   113,
     208,     0,   223,    96,   195,   113,   208,     0,    35,   208,
       0,    36,   208,     0,    95,   203,   110,     0,    61,   203,
     111,     0,    95,   203,   110,     0,    49,     0,    95,   240,
     110,     0,    67,   262,     0,    95,   230,   110,     0,   207,
      95,   230,   110,     0,   204,     0,   207,   204,     0,   207,
      61,   263,   274,   111,     0,   208,     0,   209,    86,   209,
       0,   209,    87,   209,     0,   209,    81,   209,     0,   209,
      82,   209,     0,   209,    83,   209,     0,   209,    84,   209,
       0,   209,    85,   209,     0,   209,    79,   209,     0,   209,
      80,   209,     0,   209,    76,   209,     0,   209,    77,   209,
       0,   209,    78,   209,     0,   209,    75,   209,     0,   209,
      74,   209,     0,   209,    73,   209,     0,   209,    71,   209,
       0,   209,    72,   209,     0,   209,    70,   209,     0,   209,
      69,   209,     0,   209,    68,   380,    65,   209,     0,   209,
      67,   209,     0,   209,    66,   209,     0,    64,     0,    64,
     209,     0,   208,     0,   210,    86,   210,     0,   210,    87,
     210,     0,   210,    81,   210,     0,   210,    82,   210,     0,
     210,    83,   210,     0,   210,    84,   210,     0,   210,    85,
     210,     0,   210,    79,   210,     0,   210,    80,   210,     0,
     210,    76,   210,     0,   210,    77,   210,     0,   210,    75,
     210,     0,   210,    74,   210,     0,   210,    73,   210,     0,
     210,    71,   210,     0,   210,    72,   210,     0,   210,    70,
     210,     0,   210,    69,   210,     0,   210,    68,   380,    65,
     210,     0,   210,    67,   210,     0,   210,    66,   210,     0,
      64,     0,    64,   210,     0,    91,   395,   172,     0,    91,
     395,   186,     0,   213,     0,   406,     0,     3,     0,    59,
       0,    60,     0,     0,     6,    77,   212,   191,   190,     0,
     406,    77,   212,   191,   190,     0,    50,   172,    77,   191,
     190,     0,    50,     6,    77,   191,   190,     0,    50,   406,
      77,   191,   190,     0,   211,     0,     4,     0,     5,     0,
     217,     0,   255,   217,     0,   211,     0,    83,   216,     0,
      73,   216,     0,    95,   216,   110,     0,     3,    77,   191,
     190,     0,    60,    77,   192,   190,     0,   315,     0,   211,
       0,   218,     0,    95,   216,   110,     0,   211,     0,    10,
       0,   224,     0,    12,     0,    11,     0,    95,   195,   110,
       0,    95,   216,   110,     0,    95,     1,   110,     0,     0,
      95,   221,   341,   110,     0,   211,    95,   203,   110,     0,
     211,    49,     0,   220,    95,   203,   110,     0,   220,    49,
       0,    37,    95,   209,    62,   230,   110,     0,   220,    96,
     195,   113,     0,   220,    89,     0,   220,    90,     0,    42,
       0,     9,    95,   203,   110,     0,   319,     0,    52,    77,
     230,    78,    95,   195,   110,     0,    53,    77,   230,    78,
      95,   195,   110,     0,    54,    77,   230,    78,    95,   195,
     110,     0,    55,    77,   230,    78,    95,   195,   110,     0,
      51,    95,   195,   110,     0,    51,    95,   230,   110,     0,
     330,     3,     0,   330,   213,     0,   330,   406,     0,   318,
       0,   318,    95,   203,   110,     0,   318,    49,     0,   226,
     214,     0,   226,   214,    95,   203,   110,     0,   226,   214,
      49,     0,   226,   215,     0,   226,   318,     0,   226,   215,
      95,   203,   110,     0,   226,   215,    49,     0,   226,   318,
      95,   203,   110,     0,   226,   318,    49,     0,   226,    91,
       8,    49,     0,   226,     8,    56,    91,     8,    49,     0,
     226,     1,     0,    41,     0,   330,    41,     0,    40,     0,
     330,   223,     0,    44,     0,    45,     0,     0,   220,    94,
       0,   220,    93,     0,   240,   242,    63,     0,   231,   242,
      63,     0,   234,   243,    63,     0,   231,    63,     0,   234,
      63,     0,   120,   227,     0,   307,     0,   313,     0,    49,
       0,   229,    49,     0,   235,   334,     0,   304,   334,     0,
     240,   334,     0,   235,     0,   304,     0,   235,     0,   232,
       0,   234,   240,     0,   240,   233,     0,   240,   236,   233,
       0,   234,   240,   233,     0,   234,   240,   236,     0,   234,
     240,   236,   233,     0,     7,     0,   233,   241,     0,   233,
       7,     0,   304,     0,     7,     0,   234,     9,     0,   234,
       7,     0,   234,   255,     0,   240,     0,   304,   240,     0,
     240,   236,     0,   304,   240,   236,     0,   241,     0,   236,
     241,     0,   236,   255,     0,   255,     0,    14,     0,    30,
       0,    29,     0,   268,     0,     8,     0,   310,     0,   239,
      95,   195,   110,     0,   239,    95,   230,   110,     0,    31,
      95,   195,   110,     0,    31,    95,   230,   110,     0,     8,
       0,     9,     0,   268,     0,   250,     0,   242,    62,   246,
       0,   251,     0,   243,    62,   246,     0,   252,     0,   244,
      62,   246,     0,     0,   121,    95,    12,   110,     0,     0,
     228,   245,   254,    67,   247,   262,     0,   228,   245,   254,
       0,     0,   254,    67,   249,   262,     0,   254,     0,   228,
     245,   248,     0,   313,   245,   248,     0,     0,   313,   245,
     253,   248,     0,   156,   245,   254,     0,     0,   255,     0,
     256,     0,   255,   256,     0,    32,    95,    95,   257,   110,
     110,     0,   258,     0,   257,    62,   258,     0,     0,   259,
       0,   259,    95,     3,   110,     0,   259,    95,     3,    62,
     203,   110,     0,   259,    95,   203,   110,     0,   172,     0,
       7,     0,     8,     0,     9,     0,   172,     0,   260,    62,
     172,     0,     0,    67,   262,     0,   209,     0,    61,   111,
       0,    61,   263,   111,     0,    61,   263,    62,   111,     0,
       1,     0,   262,     0,   263,    62,   262,     0,    96,   209,
     113,   262,     0,   172,    65,   262,     0,   263,    62,   172,
      65,   262,     0,   104,   151,   153,     0,   104,   151,   365,
       0,   104,   151,     1,     0,     0,   265,   264,   152,     0,
     103,   209,   109,     0,   103,     1,   109,     0,     0,   267,
     266,     0,   267,     1,     0,     0,    15,   172,    61,   269,
     299,   111,     0,     0,    15,    61,   270,   299,   111,     0,
      15,   172,     0,    15,   328,     0,    47,   323,     0,     0,
       0,     0,   280,   281,    61,   271,   286,   111,   254,   272,
     267,   273,   265,     0,   279,     0,     0,    62,     0,     0,
      62,     0,    38,     0,   276,     7,     0,   276,     8,     0,
     276,     9,     0,   276,    38,     0,   276,   255,     0,   276,
     172,     0,   276,   321,   172,     0,   276,   330,   321,   172,
       0,   276,   330,   172,     0,   276,   187,     0,   276,   321,
     187,     0,   276,   330,   321,   187,     0,   277,     0,   276,
     174,     0,   278,     0,   277,    61,     0,   277,    65,     0,
     278,    61,     0,   278,    65,     0,   276,   174,    61,     0,
     276,   174,    65,     0,   276,    61,     0,     0,    65,   395,
       0,    65,   395,   282,     0,   283,     0,   282,    62,   395,
     283,     0,   284,     0,   285,   395,   284,     0,   323,     0,
     309,     0,    39,   395,     0,     7,   395,     0,   285,    39,
     395,     0,   285,     7,   395,     0,     0,   288,     0,   286,
     287,   288,     0,   286,   287,     0,    39,    65,     0,   289,
       0,   288,   289,     0,   290,    63,     0,   290,   111,     0,
     163,    65,     0,   163,    97,     0,   163,    26,     0,   163,
      61,     0,    63,     0,   120,   289,     0,   140,   289,     0,
     140,   231,    63,     0,   397,     0,   231,   291,     0,   234,
     292,     0,   313,   245,   254,   261,     0,   156,   245,   254,
     261,     0,    65,   209,     0,     1,     0,   234,   162,   245,
     254,   261,     0,   162,   245,   254,   261,     0,   130,     0,
       0,   293,     0,   291,    62,   294,     0,     0,   296,     0,
     292,    62,   298,     0,   295,     0,   296,     0,   297,     0,
     298,     0,   307,   245,   254,   261,     0,     4,    65,   209,
     254,     0,   313,   245,   254,   261,     0,   156,   245,   254,
     261,     0,     3,    65,   209,   254,     0,    65,   209,   254,
       0,   307,   245,   254,   261,     0,     4,    65,   209,   254,
       0,   313,   245,   254,   261,     0,     3,    65,   209,   254,
       0,    65,   209,   254,     0,   300,   275,     0,   275,     0,
     301,     0,   300,    62,   301,     0,   172,     0,   172,    67,
     209,     0,   375,   331,     0,   375,     0,    95,   230,   110,
      96,   195,   113,     0,     0,   303,     9,     0,     9,     0,
     304,     9,     0,   255,     0,   304,   255,     0,    95,   203,
     110,     0,    95,   385,   110,     0,    49,     0,    95,     1,
     110,     0,   307,     0,   255,   307,     0,    83,   304,   306,
       0,    73,   304,   306,     0,    83,   306,     0,    73,   306,
       0,   329,   303,   306,     0,   308,     0,   308,   305,   303,
     400,     0,   308,    96,   195,   113,     0,   308,    96,   113,
       0,    95,   306,   110,     0,   321,   320,     0,   320,     0,
     320,     0,   330,   320,     0,   309,     0,   311,     0,   330,
     311,     0,   321,   320,     0,   313,     0,   255,   313,     0,
      83,   304,   312,     0,    73,   304,   312,     0,    83,   312,
       0,    73,   312,     0,   329,   303,   312,     0,   219,     0,
      83,   304,   312,     0,    73,   304,   312,     0,    83,   314,
       0,    73,   314,     0,   329,   303,   312,     0,   315,     0,
     219,   305,   303,   400,     0,    95,   314,   110,     0,   219,
      96,   195,   113,     0,   219,    96,   113,     0,   317,     0,
     330,   317,     0,   330,   211,     0,   321,   218,     0,   321,
     215,     0,   321,   214,     0,   321,   211,     0,   321,   214,
       0,   317,     0,   330,   317,     0,   240,    95,   203,   110,
       0,   240,    95,   216,   110,     0,   240,   229,     0,     4,
       0,     5,     0,   186,     0,   322,     0,   321,   322,     0,
     321,    50,   327,    56,     0,   321,     3,    56,     0,   321,
      59,    56,     0,     4,    56,     0,     5,    56,     0,    60,
      56,     0,   186,    56,     0,   324,     0,   330,   324,     0,
     325,   172,     0,   325,   186,     0,   325,   327,     0,   325,
      50,   327,     0,   326,     0,   325,   326,     0,   325,   327,
      56,     0,   325,    50,   327,    56,     0,     4,    56,     0,
       5,    56,     0,   186,    56,     0,    59,    56,     0,     3,
      56,     0,    60,    56,     0,   172,    77,   191,   190,     0,
     330,   320,     0,   311,     0,   330,   311,     0,   321,    83,
       0,   330,   321,    83,     0,    56,     0,    83,   303,   331,
       0,    83,   303,     0,    73,   303,   331,     0,    73,   303,
       0,   329,   303,     0,   329,   303,   331,     0,   332,     0,
      96,   195,   113,     0,   332,    96,   195,   113,     0,   334,
       0,   255,   334,     0,    83,   304,   333,     0,    83,   333,
       0,    83,   304,     0,    83,     0,    73,   304,   333,     0,
      73,   333,     0,    73,   304,     0,    73,     0,   329,   303,
       0,   329,   303,   333,     0,   335,     0,    95,   333,   110,
       0,   335,    95,   385,   110,   303,   400,     0,   335,    49,
     303,   400,     0,   335,    96,   195,   113,     0,   335,    96,
     113,     0,    95,   386,   110,   303,   400,     0,   207,   303,
     400,     0,   229,   303,   400,     0,    96,   195,   113,     0,
      96,   113,     0,   349,     0,   337,     0,   336,   349,     0,
     336,   337,     0,     1,    63,     0,     0,   339,     0,   340,
       0,   339,   340,     0,    34,   260,    63,     0,     0,   407,
      61,   342,   201,     0,   341,     0,     0,     0,    16,   345,
     197,   346,   347,     0,   343,     0,     0,   348,   407,   350,
       0,   343,     0,   407,   350,     0,   227,     0,   195,    63,
       0,     0,   344,    17,   351,   347,     0,   344,     0,     0,
       0,    18,   352,   197,   353,   347,     0,     0,     0,    19,
     354,   347,    18,   355,   196,    63,     0,     0,     0,     0,
       0,    20,   356,    95,   378,   357,   198,    63,   358,   380,
     110,   359,   347,     0,     0,     0,    21,   360,    95,   199,
     110,   361,   347,     0,     0,    22,   209,    65,   362,   349,
       0,     0,    22,   209,    13,   209,    65,   363,   349,     0,
       0,    23,    65,   364,   349,     0,    24,    63,     0,    25,
      63,     0,    26,    63,     0,    26,   195,    63,     0,   121,
     379,    95,    12,   110,    63,     0,   121,   379,    95,    12,
      65,   381,   110,    63,     0,   121,   379,    95,    12,    65,
     381,    65,   381,   110,    63,     0,   121,   379,    95,    12,
      56,   381,   110,    63,     0,   121,   379,    95,    12,    65,
     381,    65,   381,    65,   384,   110,    63,     0,   121,   379,
      95,    12,    56,   381,    65,   384,   110,    63,     0,   121,
     379,    95,    12,    65,   381,    56,   384,   110,    63,     0,
      27,    83,   195,    63,     0,    27,   172,    63,     0,   377,
     349,     0,   377,   111,     0,    63,     0,   368,     0,   132,
       0,   131,     0,   128,     0,     0,     0,    97,   366,   153,
     367,   371,     0,     0,     0,    97,   369,   343,   370,   371,
       0,   372,     0,   371,   372,     0,     0,     0,     0,    98,
     373,   376,   374,   343,     0,   235,     0,   304,     0,    95,
      13,   110,     0,    95,   394,   110,     0,     3,    65,     0,
      59,    65,     0,     4,    65,     0,     5,    65,     0,   380,
      63,     0,   227,     0,    61,   201,     0,     0,     9,     0,
       0,   195,     0,     1,     0,     0,   382,     0,   383,     0,
     382,    62,   383,     0,    12,    95,   195,   110,     0,    96,
     172,   113,    12,    95,   195,   110,     0,    12,     0,   384,
      62,    12,     0,     0,   386,     0,   230,     0,   390,     0,
     391,    13,     0,   390,    13,     0,   230,    13,     0,    13,
       0,   390,    65,     0,   230,    65,     0,     0,    67,   388,
     389,     0,   102,     0,   262,     0,   392,     0,   394,   387,
       0,   391,   393,     0,   391,   396,     0,   391,   396,    67,
     262,     0,   390,    62,     0,   230,    62,     0,   232,   228,
       0,   235,   228,     0,   240,   228,     0,   232,   334,     0,
     232,     0,   234,   313,     0,   394,     0,   394,   387,     0,
     392,     0,   230,     0,     0,     0,   313,     0,     3,   398,
       3,   399,    63,     0,    77,   191,   190,     0,     0,    95,
     203,   110,     0,     0,     0,    64,    95,   402,   110,     0,
      64,    49,     0,   230,     0,     1,     0,   401,     0,   402,
      62,   401,     0,     0,    83,   303,   403,     0,    73,   303,
     403,     0,   329,   303,   403,     0,    43,     0,     0,   404,
      83,   405,     0,   404,    84,   405,     0,   404,    85,   405,
       0,   404,    81,   405,     0,   404,    82,   405,     0,   404,
      73,   405,     0,   404,    71,   405,     0,   404,    72,   405,
       0,   404,    91,   405,     0,   404,    62,   405,     0,   404,
      76,   405,     0,   404,    77,   405,     0,   404,    78,   405,
       0,   404,    75,   405,     0,   404,    66,   405,     0,   404,
      67,   405,     0,   404,    79,   405,     0,   404,    80,   405,
       0,   404,    89,   405,     0,   404,    90,   405,     0,   404,
      70,   405,     0,   404,    69,   405,     0,   404,   112,   405,
       0,   404,    68,    65,   405,     0,   404,    74,   405,     0,
     404,    93,   405,     0,   404,    86,   405,     0,   404,    49,
     405,     0,   404,    96,   113,   405,     0,   404,    41,   405,
       0,   404,    40,   405,     0,   404,    41,    96,   113,   405,
       0,   404,    40,    96,   113,   405,     0,   404,   375,   403,
     405,     0,   404,     1,   405,     0,     0
};

#endif

#if YYDEBUG
/* YYRLINE[YYN] -- source line where rule number YYN was defined. */
static const short yyrline[] =
{
       0,   484,   487,   495,   495,   499,   503,   505,   508,   512,
     516,   522,   526,   526,   534,   537,   540,   540,   544,   546,
     548,   550,   552,   554,   554,   558,   558,   562,   563,   565,
     566,   570,   570,   582,   585,   587,   591,   594,   596,   600,
     600,   615,   622,   631,   633,   634,   636,   640,   643,   649,
     649,   656,   662,   664,   667,   670,   674,   677,   681,   684,
     688,   693,   703,   705,   707,   709,   711,   718,   721,   725,
     728,   730,   732,   735,   738,   742,   744,   746,   748,   758,
     760,   762,   764,   766,   767,   774,   775,   776,   778,   779,
     782,   784,   787,   789,   790,   793,   795,   801,   801,   812,
     815,   817,   821,   821,   826,   830,   830,   834,   838,   838,
     842,   846,   846,   850,   856,   861,   864,   867,   870,   878,
     881,   884,   886,   888,   890,   896,   905,   908,   910,   912,
     915,   917,   922,   929,   932,   934,   938,   938,   947,   954,
     960,   965,   976,   979,   987,   990,   993,   998,  1002,  1005,
    1010,  1012,  1013,  1014,  1015,  1018,  1020,  1021,  1024,  1026,
    1027,  1030,  1030,  1035,  1035,  1039,  1039,  1042,  1042,  1045,
    1045,  1050,  1050,  1056,  1056,  1060,  1060,  1066,  1070,  1078,
    1082,  1085,  1088,  1090,  1095,  1101,  1111,  1113,  1121,  1124,
    1127,  1130,  1134,  1137,  1143,  1149,  1150,  1162,  1165,  1167,
    1169,  1171,  1175,  1178,  1181,  1186,  1190,  1195,  1199,  1202,
    1203,  1207,  1207,  1230,  1233,  1235,  1236,  1237,  1240,  1244,
    1247,  1249,  1253,  1256,  1259,  1263,  1266,  1268,  1270,  1272,
    1275,  1277,  1280,  1284,  1287,  1294,  1297,  1300,  1303,  1306,
    1311,  1314,  1317,  1321,  1323,  1327,  1331,  1333,  1337,  1340,
    1345,  1348,  1350,  1355,  1365,  1370,  1376,  1378,  1380,  1393,
    1396,  1398,  1400,  1402,  1404,  1406,  1408,  1410,  1412,  1414,
    1416,  1418,  1420,  1422,  1424,  1426,  1428,  1430,  1432,  1434,
    1436,  1440,  1442,  1444,  1448,  1451,  1453,  1455,  1457,  1459,
    1461,  1463,  1465,  1467,  1469,  1471,  1473,  1475,  1477,  1479,
    1481,  1483,  1485,  1487,  1489,  1493,  1495,  1497,  1501,  1504,
    1506,  1507,  1508,  1509,  1510,  1513,  1526,  1534,  1543,  1546,
    1548,  1553,  1555,  1556,  1559,  1561,  1569,  1571,  1573,  1575,
    1579,  1582,  1586,  1590,  1591,  1592,  1596,  1604,  1605,  1606,
    1616,  1618,  1620,  1623,  1625,  1625,  1640,  1642,  1644,  1646,
    1648,  1651,  1653,  1655,  1658,  1660,  1671,  1672,  1676,  1680,
    1684,  1688,  1690,  1694,  1696,  1698,  1706,  1708,  1710,  1712,
    1714,  1716,  1718,  1720,  1722,  1724,  1726,  1728,  1731,  1733,
    1735,  1779,  1782,  1786,  1789,  1793,  1796,  1800,  1808,  1811,
    1818,  1824,  1828,  1830,  1835,  1837,  1844,  1846,  1850,  1854,
    1860,  1864,  1867,  1871,  1874,  1884,  1887,  1891,  1895,  1898,
    1901,  1904,  1907,  1913,  1919,  1921,  1942,  1945,  1950,  1955,
    1963,  1973,  1977,  1980,  1983,  1988,  1991,  1993,  1995,  1999,
    2003,  2007,  2015,  2018,  2020,  2022,  2026,  2030,  2045,  2064,
    2067,  2069,  2072,  2074,  2078,  2080,  2084,  2086,  2090,  2093,
    2097,  2097,  2103,  2116,  2116,  2124,  2130,  2135,  2140,  2140,
    2149,  2156,  2159,  2163,  2166,  2170,  2175,  2178,  2182,  2185,
    2187,  2189,  2191,  2198,  2200,  2201,  2202,  2206,  2209,  2213,
    2216,  2223,  2225,  2228,  2231,  2234,  2240,  2243,  2246,  2248,
    2250,  2254,  2260,  2265,  2271,  2273,  2278,  2281,  2285,  2287,
    2289,  2293,  2293,  2303,  2303,  2312,  2315,  2318,  2324,  2324,
    2324,  2324,  2369,  2377,  2379,  2382,  2384,  2389,  2391,  2393,
    2395,  2397,  2399,  2403,  2409,  2414,  2419,  2426,  2432,  2437,
    2444,  2452,  2458,  2465,  2475,  2483,  2494,  2505,  2513,  2521,
    2534,  2537,  2540,  2544,  2546,  2550,  2553,  2557,  2561,  2565,
    2567,  2571,  2582,  2596,  2597,  2598,  2599,  2602,  2611,  2618,
    2626,  2628,  2633,  2635,  2637,  2639,  2641,  2643,  2646,  2656,
    2661,  2665,  2690,  2696,  2698,  2700,  2702,  2713,  2718,  2720,
    2726,  2729,  2736,  2746,  2749,  2756,  2766,  2768,  2771,  2773,
    2776,  2780,  2785,  2789,  2792,  2795,  2800,  2803,  2807,  2810,
    2812,  2816,  2818,  2825,  2827,  2830,  2833,  2838,  2842,  2847,
    2857,  2860,  2864,  2868,  2871,  2874,  2883,  2886,  2888,  2890,
    2896,  2898,  2907,  2910,  2912,  2914,  2916,  2920,  2923,  2926,
    2928,  2930,  2932,  2936,  2939,  2950,  2960,  2962,  2963,  2967,
    2975,  2977,  2985,  2988,  2990,  2992,  2994,  2998,  3001,  3004,
    3006,  3008,  3010,  3014,  3017,  3020,  3022,  3024,  3026,  3028,
    3030,  3034,  3041,  3045,  3050,  3054,  3059,  3061,  3065,  3068,
    3070,  3074,  3076,  3077,  3080,  3082,  3084,  3088,  3091,  3098,
    3109,  3115,  3121,  3125,  3127,  3131,  3145,  3147,  3149,  3153,
    3161,  3174,  3177,  3184,  3197,  3203,  3205,  3206,  3207,  3215,
    3220,  3229,  3230,  3234,  3237,  3243,  3249,  3252,  3254,  3256,
    3258,  3262,  3266,  3270,  3273,  3277,  3279,  3288,  3291,  3293,
    3295,  3297,  3299,  3301,  3303,  3305,  3309,  3313,  3317,  3321,
    3323,  3325,  3327,  3329,  3331,  3333,  3335,  3337,  3345,  3347,
    3348,  3349,  3352,  3358,  3360,  3365,  3367,  3370,  3381,  3381,
    3389,  3394,  3394,  3394,  3405,  3407,  3407,  3415,  3417,  3421,
    3425,  3427,  3427,  3435,  3438,  3438,  3438,  3448,  3448,  3448,
    3458,  3458,  3458,  3458,  3458,  3469,  3469,  3469,  3476,  3476,
    3480,  3480,  3484,  3484,  3488,  3490,  3492,  3494,  3496,  3501,
    3504,  3507,  3510,  3513,  3516,  3519,  3525,  3527,  3529,  3533,
    3536,  3538,  3540,  3543,  3547,  3547,  3547,  3556,  3556,  3556,
    3565,  3567,  3568,  3579,  3579,  3579,  3588,  3590,  3593,  3610,
    3618,  3621,  3623,  3625,  3629,  3632,  3633,  3641,  3644,  3647,
    3650,  3651,  3657,  3660,  3663,  3665,  3669,  3672,  3678,  3681,
    3691,  3696,  3697,  3704,  3707,  3710,  3712,  3715,  3717,  3727,
    3741,  3741,  3748,  3750,  3754,  3758,  3761,  3764,  3766,  3770,
    3772,  3779,  3785,  3788,  3792,  3795,  3798,  3803,  3807,  3812,
    3814,  3817,  3822,  3828,  3844,  3852,  3855,  3858,  3861,  3864,
    3867,  3869,  3873,  3879,  3883,  3886,  3890,  3893,  3895,  3897,
    3903,  3916,  3925,  3928,  3930,  3932,  3934,  3936,  3938,  3940,
    3942,  3944,  3946,  3948,  3950,  3952,  3954,  3956,  3958,  3960,
    3962,  3964,  3966,  3968,  3970,  3972,  3974,  3976,  3978,  3980,
    3982,  3984,  3986,  3988,  3990,  3992,  3994,  4001
};
#endif


#if (YYDEBUG) || defined YYERROR_VERBOSE

/* YYTNAME[TOKEN_NUM] -- String name of the token TOKEN_NUM. */
static const char *const yytname[] =
{
  "$", "error", "$undefined.", "IDENTIFIER", "tTYPENAME", "SELFNAME", 
  "PFUNCNAME", "SCSPEC", "TYPESPEC", "CV_QUALIFIER", "CONSTANT", 
  "VAR_FUNC_NAME", "STRING", "ELLIPSIS", "SIZEOF", "ENUM", "IF", "ELSE", 
  "WHILE", "DO", "FOR", "SWITCH", "CASE", "DEFAULT", "BREAK", "CONTINUE", 
  "RETURN_KEYWORD", "GOTO", "ASM_KEYWORD", "TYPEOF", "ALIGNOF", "SIGOF", 
  "ATTRIBUTE", "EXTENSION", "LABEL", "REALPART", "IMAGPART", "VA_ARG", 
  "AGGR", "VISSPEC", "DELETE", "NEW", "THIS", "OPERATOR", "CXX_TRUE", 
  "CXX_FALSE", "NAMESPACE", "TYPENAME_KEYWORD", "USING", "LEFT_RIGHT", 
  "TEMPLATE", "TYPEID", "DYNAMIC_CAST", "STATIC_CAST", "REINTERPRET_CAST", 
  "CONST_CAST", "SCOPE", "EXPORT", "EMPTY", "PTYPENAME", "NSNAME", "'{'", 
  "','", "';'", "THROW", "':'", "ASSIGN", "'='", "'?'", "OROR", "ANDAND", 
  "'|'", "'^'", "'&'", "MIN_MAX", "EQCOMPARE", "ARITHCOMPARE", "'<'", 
  "'>'", "LSHIFT", "RSHIFT", "'+'", "'-'", "'*'", "'/'", "'%'", 
  "POINTSAT_STAR", "DOT_STAR", "UNARY", "PLUSPLUS", "MINUSMINUS", "'~'", 
  "HYPERUNARY", "POINTSAT", "'.'", "'('", "'['", "TRY", "CATCH", 
  "EXTERN_LANG_STRING", "ALL", "PRE_PARSED_CLASS_DECL", "DEFARG", 
  "DEFARG_MARKER", "PRE_PARSED_FUNCTION_DECL", "TYPENAME_DEFN", 
  "IDENTIFIER_DEFN", "PTYPENAME_DEFN", "END_OF_LINE", 
  "END_OF_SAVED_INPUT", "')'", "'}'", "'!'", "']'", "program", "extdefs", 
  "@1", "extdefs_opt", ".hush_warning", ".warning_ok", "extension", 
  "asm_keyword", "lang_extdef", "@2", "extdef", "@3", "@4", "@5", 
  "namespace_alias", "@6", "using_decl", "namespace_using_decl", 
  "using_directive", "@7", "namespace_qualifier", "any_id", 
  "extern_lang_string", "template_parm_header", "@8", 
  "template_spec_header", "template_header", "template_parm_list", 
  "maybe_identifier", "template_type_parm", "template_template_parm", 
  "template_parm", "template_def", "template_extdef", "template_datadef", 
  "datadef", "ctor_initializer_opt", "maybe_return_init", 
  "eat_saved_input", "function_body", "@9", "fndef", 
  "constructor_declarator", "@10", "@11", "@12", "@13", "fn.def1", 
  "component_constructor_declarator", "fn_def2", "return_id", 
  "return_init", "base_init", "@14", "begin_function_body_", 
  "member_init_list", "begin_member_init", "member_init", "identifier", 
  "notype_identifier", "identifier_defn", "explicit_instantiation", "@15", 
  "@16", "@17", "@18", "@19", "@20", "@21", "@22", 
  "begin_explicit_instantiation", "end_explicit_instantiation", 
  "template_type", "apparent_template_type", "self_template_type", 
  "finish_template_type_", "template_close_bracket", 
  "template_arg_list_opt", "template_arg_list", "template_arg", "unop", 
  "expr", "paren_expr_or_null", "paren_cond_or_null", "xcond", 
  "condition", "@23", "compstmtend", "nontrivial_exprlist", 
  "nonnull_exprlist", "unary_expr", "new_placement", "new_initializer", 
  "regcast_or_absdcl", "cast_expr", "expr_no_commas", 
  "expr_no_comma_rangle", "notype_unqualified_id", "do_id", "template_id", 
  "object_template_id", "unqualified_id", "expr_or_declarator_intern", 
  "expr_or_declarator", "notype_template_declarator", 
  "direct_notype_declarator", "primary", "@24", "new", "delete", 
  "boolean_literal", "nodecls", "object", "decl", "declarator", 
  "fcast_or_absdcl", "type_id", "typed_declspecs", "typed_declspecs1", 
  "reserved_declspecs", "declmods", "typed_typespecs", 
  "reserved_typespecquals", "sizeof", "alignof", "typeof", "typespec", 
  "typespecqual_reserved", "initdecls", "notype_initdecls", 
  "nomods_initdecls", "maybeasm", "initdcl", "@25", "initdcl0_innards", 
  "@26", "initdcl0", "notype_initdcl0", "nomods_initdcl0", "@27", 
  "maybe_attribute", "attributes", "attribute", "attribute_list", 
  "attrib", "any_word", "identifiers_or_typenames", "maybe_init", "init", 
  "initlist", "pending_inline", "pending_inlines", "defarg_again", 
  "pending_defargs", "structsp", "@28", "@29", "@30", "@31", "@32", 
  "maybecomma", "maybecomma_warn", "aggr", "class_head", 
  "class_head_apparent_template", "class_head_decl", "class_head_defn", 
  "maybe_base_class_list", "base_class_list", "base_class", 
  "base_class_1", "base_class_access_list", "opt.component_decl_list", 
  "access_specifier", "component_decl_list", "component_decl", 
  "component_decl_1", "components", "notype_components", 
  "component_declarator0", "component_declarator", 
  "after_type_component_declarator0", "notype_component_declarator0", 
  "after_type_component_declarator", "notype_component_declarator", 
  "enumlist_opt", "enumlist", "enumerator", "new_type_id", 
  "cv_qualifiers", "nonempty_cv_qualifiers", "maybe_parmlist", 
  "after_type_declarator_intern", "after_type_declarator", 
  "direct_after_type_declarator", "nonnested_type", "complete_type_name", 
  "nested_type", "notype_declarator_intern", "notype_declarator", 
  "complex_notype_declarator", "complex_direct_notype_declarator", 
  "qualified_id", "notype_qualified_id", "overqualified_id", 
  "functional_cast", "type_name", "nested_name_specifier", 
  "nested_name_specifier_1", "typename_sub", "typename_sub0", 
  "typename_sub1", "typename_sub2", "explicit_template_type", 
  "complex_type_name", "ptr_to_mem", "global_scope", "new_declarator", 
  "direct_new_declarator", "absdcl_intern", "absdcl", 
  "direct_abstract_declarator", "stmts", "errstmt", "maybe_label_decls", 
  "label_decls", "label_decl", "compstmt_or_stmtexpr", "@33", "compstmt", 
  "simple_if", "@34", "@35", "implicitly_scoped_stmt", "@36", "stmt", 
  "simple_stmt", "@37", "@38", "@39", "@40", "@41", "@42", "@43", "@44", 
  "@45", "@46", "@47", "@48", "@49", "@50", "function_try_block", "@51", 
  "@52", "try_block", "@53", "@54", "handler_seq", "handler", "@55", 
  "@56", "type_specifier_seq", "handler_args", "label_colon", 
  "for.init.statement", "maybe_cv_qualifier", "xexpr", "asm_operands", 
  "nonnull_asm_operands", "asm_operand", "asm_clobbers", "parmlist", 
  "complex_parmlist", "defarg", "@57", "defarg1", "parms", "parms_comma", 
  "named_parm", "full_parm", "parm", "see_typename", "bad_parm", 
  "bad_decl", "template_arg_list_ignore", "arg_list_ignore", 
  "exception_specification_opt", "ansi_raise_identifier", 
  "ansi_raise_identifiers", "conversion_declarator", "operator", 
  "unoperator", "operator_name", "save_lineno", 0
};
#endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives. */
static const short yyr1[] =
{
       0,   114,   114,   116,   115,   115,   117,   117,   118,   119,
     120,   121,   123,   122,   124,   124,   125,   124,   124,   124,
     124,   124,   124,   126,   124,   127,   124,   124,   124,   124,
     124,   129,   128,   130,   130,   130,   131,   131,   131,   133,
     132,   134,   134,   135,   135,   135,   135,   136,   136,   138,
     137,   139,   140,   140,   141,   141,   142,   142,   143,   143,
     144,   145,   145,   145,   145,   145,   145,   146,   146,   147,
     147,   147,   147,   147,   147,   148,   148,   148,   148,   149,
     149,   149,   149,   149,   149,   149,   149,   149,   149,   149,
     150,   150,   151,   151,   151,   152,   152,   154,   153,   155,
     155,   155,   157,   156,   156,   158,   156,   156,   159,   156,
     156,   160,   156,   156,   161,   161,   161,   161,   161,   162,
     162,   162,   162,   162,   162,   163,   163,   163,   163,   163,
     163,   163,   164,   165,   165,   165,   167,   166,   168,   169,
     169,   169,   169,   170,   170,   170,   170,   171,   171,   171,
     172,   172,   172,   172,   172,   173,   173,   173,   174,   174,
     174,   176,   175,   177,   175,   178,   175,   179,   175,   180,
     175,   181,   175,   182,   175,   183,   175,   184,   185,   186,
     186,   186,   187,   187,   188,   189,   190,   190,   191,   191,
     192,   192,   193,   193,   193,   193,   193,   194,   194,   194,
     194,   194,   195,   195,   196,   196,   197,   197,   198,   198,
     198,   200,   199,   199,   201,   201,   201,   201,   202,   202,
     202,   202,   203,   203,   204,   204,   204,   204,   204,   204,
     204,   204,   204,   204,   204,   204,   204,   204,   204,   204,
     204,   204,   204,   204,   204,   204,   204,   204,   205,   205,
     206,   206,   206,   206,   207,   207,   208,   208,   208,   209,
     209,   209,   209,   209,   209,   209,   209,   209,   209,   209,
     209,   209,   209,   209,   209,   209,   209,   209,   209,   209,
     209,   209,   209,   209,   210,   210,   210,   210,   210,   210,
     210,   210,   210,   210,   210,   210,   210,   210,   210,   210,
     210,   210,   210,   210,   210,   210,   210,   210,   211,   211,
     211,   211,   211,   211,   211,   212,   213,   213,   214,   214,
     214,   215,   215,   215,   216,   216,   217,   217,   217,   217,
     218,   218,   219,   219,   219,   219,   220,   220,   220,   220,
     220,   220,   220,   220,   221,   220,   220,   220,   220,   220,
     220,   220,   220,   220,   220,   220,   220,   220,   220,   220,
     220,   220,   220,   220,   220,   220,   220,   220,   220,   220,
     220,   220,   220,   220,   220,   220,   220,   220,   220,   220,
     220,   222,   222,   223,   223,   224,   224,   225,   226,   226,
     227,   227,   227,   227,   227,   227,   228,   228,   229,   229,
     230,   230,   230,   230,   230,   231,   231,   232,   232,   232,
     232,   232,   232,   233,   233,   233,   234,   234,   234,   234,
     234,   235,   235,   235,   235,   236,   236,   236,   236,   237,
     238,   239,   240,   240,   240,   240,   240,   240,   240,   241,
     241,   241,   242,   242,   243,   243,   244,   244,   245,   245,
     247,   246,   246,   249,   248,   248,   250,   251,   253,   252,
     252,   254,   254,   255,   255,   256,   257,   257,   258,   258,
     258,   258,   258,   259,   259,   259,   259,   260,   260,   261,
     261,   262,   262,   262,   262,   262,   263,   263,   263,   263,
     263,   264,   264,   264,   265,   265,   266,   266,   267,   267,
     267,   269,   268,   270,   268,   268,   268,   268,   271,   272,
     273,   268,   268,   274,   274,   275,   275,   276,   276,   276,
     276,   276,   276,   277,   277,   277,   277,   278,   278,   278,
     279,   279,   279,   280,   280,   280,   280,   280,   280,   280,
     281,   281,   281,   282,   282,   283,   283,   284,   284,   285,
     285,   285,   285,   286,   286,   286,   286,   287,   288,   288,
     289,   289,   289,   289,   289,   289,   289,   289,   289,   289,
     289,   290,   290,   290,   290,   290,   290,   290,   290,   290,
     291,   291,   291,   292,   292,   292,   293,   293,   294,   294,
     295,   295,   296,   296,   296,   296,   297,   297,   298,   298,
     298,   299,   299,   300,   300,   301,   301,   302,   302,   302,
     303,   303,   304,   304,   304,   304,   305,   305,   305,   305,
     306,   306,   307,   307,   307,   307,   307,   307,   308,   308,
     308,   308,   308,   308,   309,   309,   310,   310,   310,   311,
     312,   312,   313,   313,   313,   313,   313,   313,   314,   314,
     314,   314,   314,   314,   315,   315,   315,   315,   315,   315,
     315,   315,   316,   316,   317,   317,   318,   318,   319,   319,
     319,   320,   320,   320,   321,   321,   321,   321,   321,   322,
     322,   322,   322,   323,   323,   324,   324,   324,   324,   325,
     325,   325,   325,   326,   326,   326,   326,   326,   326,   327,
     328,   328,   328,   329,   329,   330,   331,   331,   331,   331,
     331,   331,   331,   332,   332,   333,   333,   334,   334,   334,
     334,   334,   334,   334,   334,   334,   334,   334,   335,   335,
     335,   335,   335,   335,   335,   335,   335,   335,   336,   336,
     336,   336,   337,   338,   338,   339,   339,   340,   342,   341,
     343,   345,   346,   344,   347,   348,   347,   349,   349,   350,
     350,   351,   350,   350,   352,   353,   350,   354,   355,   350,
     356,   357,   358,   359,   350,   360,   361,   350,   362,   350,
     363,   350,   364,   350,   350,   350,   350,   350,   350,   350,
     350,   350,   350,   350,   350,   350,   350,   350,   350,   350,
     350,   350,   350,   350,   366,   367,   365,   369,   370,   368,
     371,   371,   371,   373,   374,   372,   375,   375,   376,   376,
     377,   377,   377,   377,   378,   378,   378,   379,   379,   380,
     380,   380,   381,   381,   382,   382,   383,   383,   384,   384,
     385,   385,   385,   386,   386,   386,   386,   386,   386,   386,
     388,   387,   389,   389,   390,   390,   390,   390,   390,   391,
     391,   392,   392,   392,   392,   392,   392,   393,   393,   394,
     394,   395,   396,   396,   397,   398,   398,   399,   399,   400,
     400,   400,   401,   401,   402,   402,   403,   403,   403,   403,
     404,   405,   406,   406,   406,   406,   406,   406,   406,   406,
     406,   406,   406,   406,   406,   406,   406,   406,   406,   406,
     406,   406,   406,   406,   406,   406,   406,   406,   406,   406,
     406,   406,   406,   406,   406,   406,   406,   407
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN. */
static const short yyr2[] =
{
       0,     0,     1,     0,     2,     2,     1,     0,     0,     0,
       1,     1,     0,     2,     2,     1,     0,     3,     1,     5,
       4,     5,     4,     0,     6,     0,     5,     1,     2,     1,
       2,     0,     6,     2,     3,     3,     3,     3,     4,     0,
       5,     2,     3,     1,     1,     2,     2,     1,     2,     0,
       5,     3,     1,     1,     1,     3,     1,     0,     2,     2,
       3,     1,     3,     1,     3,     1,     3,     2,     2,     2,
       1,     1,     5,     4,     2,     2,     3,     3,     2,     2,
       3,     3,     2,     2,     2,     2,     2,     2,     1,     1,
       1,     1,     0,     1,     2,     0,     1,     0,     6,     3,
       3,     3,     0,     8,     5,     0,     9,     6,     0,     8,
       5,     0,     9,     6,     2,     2,     1,     2,     1,     6,
       8,     4,     6,     6,     4,     2,     1,     2,     2,     1,
       2,     1,     2,     2,     4,     2,     0,     3,     0,     0,
       1,     3,     2,     0,     1,     1,     1,     4,     2,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     0,     6,     0,     6,     0,     5,     0,     5,     0,
       7,     0,     7,     0,     6,     0,     6,     0,     0,     5,
       5,     1,     1,     5,     5,     0,     1,     1,     0,     1,
       1,     3,     1,     1,     2,     1,     3,     1,     1,     1,
       1,     1,     1,     1,     1,     3,     1,     3,     0,     1,
       1,     0,     7,     1,     1,     3,     4,     3,     3,     3,
       3,     3,     1,     1,     1,     2,     2,     2,     2,     2,
       2,     2,     4,     2,     4,     2,     3,     3,     4,     4,
       5,     5,     6,     2,     4,     5,     2,     2,     3,     3,
       3,     1,     3,     2,     3,     4,     1,     2,     5,     1,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     5,
       3,     3,     1,     2,     1,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     5,     3,     3,     1,     2,     3,     3,
       1,     1,     1,     1,     1,     0,     5,     5,     5,     5,
       5,     1,     1,     1,     1,     2,     1,     2,     2,     3,
       4,     4,     1,     1,     1,     3,     1,     1,     1,     1,
       1,     3,     3,     3,     0,     4,     4,     2,     4,     2,
       6,     4,     2,     2,     1,     4,     1,     7,     7,     7,
       7,     4,     4,     2,     2,     2,     1,     4,     2,     2,
       5,     3,     2,     2,     5,     3,     5,     3,     4,     6,
       2,     1,     2,     1,     2,     1,     1,     0,     2,     2,
       3,     3,     3,     2,     2,     2,     1,     1,     1,     2,
       2,     2,     2,     1,     1,     1,     1,     2,     2,     3,
       3,     3,     4,     1,     2,     2,     1,     1,     2,     2,
       2,     1,     2,     2,     3,     1,     2,     2,     1,     1,
       1,     1,     1,     1,     1,     4,     4,     4,     4,     1,
       1,     1,     1,     3,     1,     3,     1,     3,     0,     4,
       0,     6,     3,     0,     4,     1,     3,     3,     0,     4,
       3,     0,     1,     1,     2,     6,     1,     3,     0,     1,
       4,     6,     4,     1,     1,     1,     1,     1,     3,     0,
       2,     1,     2,     3,     4,     1,     1,     3,     4,     3,
       5,     3,     3,     3,     0,     3,     3,     3,     0,     2,
       2,     0,     6,     0,     5,     2,     2,     2,     0,     0,
       0,    11,     1,     0,     1,     0,     1,     1,     2,     2,
       2,     2,     2,     2,     3,     4,     3,     2,     3,     4,
       1,     2,     1,     2,     2,     2,     2,     3,     3,     2,
       0,     2,     3,     1,     4,     1,     3,     1,     1,     2,
       2,     3,     3,     0,     1,     3,     2,     2,     1,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     2,     3,
       1,     2,     2,     4,     4,     2,     1,     5,     4,     1,
       0,     1,     3,     0,     1,     3,     1,     1,     1,     1,
       4,     4,     4,     4,     4,     3,     4,     4,     4,     4,
       3,     2,     1,     1,     3,     1,     3,     2,     1,     6,
       0,     2,     1,     2,     1,     2,     3,     3,     1,     3,
       1,     2,     3,     3,     2,     2,     3,     1,     4,     4,
       3,     3,     2,     1,     1,     2,     1,     1,     2,     2,
       1,     2,     3,     3,     2,     2,     3,     1,     3,     3,
       2,     2,     3,     1,     4,     3,     4,     3,     1,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     4,     4,
       2,     1,     1,     1,     1,     2,     4,     3,     3,     2,
       2,     2,     2,     1,     2,     2,     2,     2,     3,     1,
       2,     3,     4,     2,     2,     2,     2,     2,     2,     4,
       2,     1,     2,     2,     3,     1,     3,     2,     3,     2,
       2,     3,     1,     3,     4,     1,     2,     3,     2,     2,
       1,     3,     2,     2,     1,     2,     3,     1,     3,     6,
       4,     4,     3,     5,     3,     3,     3,     2,     1,     1,
       2,     2,     2,     0,     1,     1,     2,     3,     0,     4,
       1,     0,     0,     5,     1,     0,     3,     1,     2,     1,
       2,     0,     4,     1,     0,     0,     5,     0,     0,     7,
       0,     0,     0,     0,    12,     0,     0,     7,     0,     5,
       0,     7,     0,     4,     2,     2,     2,     3,     6,     8,
      10,     8,    12,    10,    10,     4,     3,     2,     2,     1,
       1,     1,     1,     1,     0,     0,     5,     0,     0,     5,
       1,     2,     0,     0,     0,     5,     1,     1,     3,     3,
       2,     2,     2,     2,     2,     1,     2,     0,     1,     0,
       1,     1,     0,     1,     1,     3,     4,     7,     1,     3,
       0,     1,     1,     1,     2,     2,     2,     1,     2,     2,
       0,     3,     1,     1,     1,     2,     2,     2,     4,     2,
       2,     2,     2,     2,     2,     1,     2,     1,     2,     1,
       1,     0,     0,     1,     5,     3,     0,     3,     0,     0,
       4,     2,     1,     1,     1,     3,     0,     3,     3,     3,
       1,     0,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     4,     3,     3,     3,     3,
       4,     3,     3,     5,     5,     4,     3,     0
};

/* YYDEFACT[S] -- default rule to reduce with in state S when YYTABLE
   doesn't specify something else to do.  Zero means the default is an
   error. */
static const short yydefact[] =
{
       3,    12,    12,     5,     0,     4,     0,   312,   671,   672,
       0,   417,   433,   612,     0,    11,   431,     0,     0,    10,
     517,   890,     0,     0,     0,   177,   705,    16,   313,   314,
      88,     0,     0,   871,     0,    47,     0,     0,    13,    27,
       0,    29,     8,    52,    53,     0,    18,    15,    95,   118,
      92,     0,   673,   181,   333,   310,   334,   647,     0,   406,
       0,   405,     0,   421,     0,   446,   614,   463,   432,     0,
     530,   532,   512,   540,   416,   636,   434,   637,   116,   332,
     658,   634,     0,   674,   610,     0,    89,     0,   311,    85,
      87,    86,   188,     0,   679,   188,   680,   188,   315,   177,
     150,   151,   152,   153,   154,   503,   505,     0,   701,     0,
     506,     0,     0,     0,   151,   152,   153,   154,    25,     0,
       0,     0,     0,     0,     0,     0,   507,   683,     0,   689,
       0,     0,     0,    39,     0,     0,    33,     0,     0,    49,
       0,     0,   188,   681,     0,   312,   614,     0,   645,   640,
       0,     0,     0,   644,     0,     0,     0,     0,   333,     0,
     324,     0,     0,     0,   332,   610,    30,     0,    28,     3,
      48,     0,    68,   417,     0,     0,     8,    71,    67,    70,
      95,     0,     0,     0,   432,    96,    14,     0,   461,     0,
       0,   479,    93,    83,   682,   618,     0,     0,   610,    84,
       0,     0,     0,   114,     0,   442,   396,   627,   397,   633,
       0,   610,   419,   418,    82,   117,   407,     0,   444,   420,
     115,     0,   413,   439,   440,   408,   423,   425,   428,   441,
       0,    79,   464,   518,   519,   520,   521,   539,   159,   158,
     160,   523,   531,   182,   527,   522,     0,     0,   533,   534,
     535,   536,   871,     0,   613,   422,   615,     0,   458,   312,
     672,     0,   313,   703,   181,   664,   665,   661,   639,   675,
       0,   312,   314,   660,   638,   659,   635,     0,   891,   891,
     891,   891,   891,   891,   891,     0,   891,   891,   891,   891,
     891,   891,   891,   891,   891,   891,   891,   891,   891,   891,
     891,   891,   891,   891,   891,   891,   891,   891,     0,   891,
     816,   421,   817,   886,   315,   612,   337,   340,   339,   429,
     430,     0,     0,     0,   383,   381,   354,   385,   386,     0,
       0,     0,     0,     0,   313,   306,     0,     0,   198,   197,
       0,   199,   200,     0,     0,   201,     0,     0,   189,   190,
       0,   256,     0,   284,   195,   336,   224,     0,     0,   338,
       0,   192,   403,     0,     0,   421,   404,   666,   366,   356,
       0,     0,   878,     0,     0,   188,     0,   515,   501,     0,
       0,     0,   702,   700,   282,     0,   202,   259,   203,     0,
       0,     0,   468,     3,    23,    31,   697,   693,   694,   696,
     698,   695,   150,   151,   152,     0,   153,   154,   685,   686,
     690,   687,   684,     0,   312,   322,   323,   321,   663,   662,
      35,    34,    51,     0,   167,     0,     0,   421,   165,    17,
       0,     0,   188,   641,   615,   643,     0,   642,   151,   152,
     308,   309,   328,   614,     0,   651,   327,     0,   650,     0,
     335,   313,   314,     0,     0,     0,   326,   325,   655,     0,
       0,    12,     0,   177,     9,     9,    74,     0,    69,     0,
       0,    75,    78,     0,   460,   462,   132,   101,   804,    99,
     387,   100,   135,     0,     0,   133,    94,     0,   847,   223,
       0,   222,   842,   865,     0,   403,   421,   404,     0,   841,
     843,   872,   854,     0,     0,   657,     0,     0,   879,   614,
       0,   625,   620,     0,   624,     0,     0,     0,     0,     0,
     610,   461,     0,    81,     0,   610,   632,     0,   410,   411,
       0,    80,   461,     0,     0,   415,   414,   409,   426,   427,
     448,   447,   188,   537,   538,   150,   153,   524,   528,   526,
       0,   541,   508,   424,   461,   677,   610,   102,     0,     0,
       0,     0,   678,   610,   108,   611,     0,   646,   672,   704,
     181,   926,     0,   922,     0,   921,   919,   901,   906,   907,
     891,   913,   912,   898,   899,   897,   916,   905,   902,   903,
     904,   908,   909,   895,   896,   892,   893,   894,   918,   910,
     911,   900,   917,   891,   914,   423,   610,   610,     0,   610,
       0,   891,   188,     0,   246,   247,     0,     0,     0,     0,
       0,     0,   307,   230,   227,   226,   228,     0,     0,     0,
       0,     0,   336,     0,   927,     0,   225,   186,   187,   330,
       0,   229,     0,     0,   257,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   347,     0,   349,   352,
     353,   389,   388,     0,     0,     0,     0,     0,   235,   608,
       0,   243,   380,     0,     0,   871,   369,   372,   373,     0,
       0,   398,   724,   720,     0,     0,   610,   610,   610,   400,
     727,     0,   231,     0,   233,     0,   670,   402,     0,     0,
     401,   368,     0,     0,   363,   382,   194,   364,   384,   667,
       0,   365,     0,     0,   185,   185,     0,   175,     0,   421,
     173,   516,   605,   602,     0,   515,   603,   515,     0,   283,
     437,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   438,   474,   475,   476,   473,
       0,   466,   469,     0,     3,     0,   688,   188,   691,     0,
      43,    44,     0,    57,     0,     0,     0,    61,    65,    54,
     870,   421,    57,   869,    63,   178,   163,   161,   178,   185,
     331,     0,   649,   648,   335,     0,   652,     0,    20,    22,
      95,     9,     9,    77,    76,     0,   138,   136,   927,    91,
      90,   485,     0,   481,   480,     0,   619,   616,   846,   860,
     849,   724,   720,     0,   861,   610,   864,   866,     0,     0,
     862,     0,   863,   617,   845,   859,   848,   844,   873,   856,
     867,   857,   850,   855,   656,     0,   670,     0,   654,   621,
     615,   623,   622,   614,     0,     0,     0,     0,     0,     0,
     610,   631,     0,   456,   455,   443,   630,     0,   879,     0,
     626,   412,   445,   457,   435,   436,   461,     0,   525,   529,
     671,   672,   871,   871,   673,   542,   543,   545,   871,   548,
     547,     0,     0,   459,   879,   840,   188,   188,   676,   188,
     879,   840,   610,   105,   610,   111,   891,   891,   915,   920,
     886,   886,   886,     0,   925,     0,     0,     0,     0,     0,
       0,   421,     0,     0,     0,   343,     0,   341,   342,     0,
       0,   254,   191,   312,   671,   672,   313,   314,     0,     0,
     486,   513,     0,   305,   304,   831,   830,     0,   302,   301,
     299,   300,   298,   297,   296,   294,   295,   292,   293,   287,
     288,   289,   290,   291,   285,   286,     0,     0,     0,     0,
       0,     0,     0,   237,   251,     0,     0,   236,   610,   610,
       0,   610,   607,   712,     0,     0,     0,     0,     0,   371,
       0,   375,     0,   377,     0,   614,   723,   722,   715,   719,
     718,   870,     0,     0,   737,     0,     0,   879,   399,   879,
     725,   610,   840,     0,     0,     0,   724,   720,     0,     0,
     610,     0,   614,     0,     0,     0,     0,   196,     0,   874,
     180,   184,   316,   178,   171,   169,   178,     0,   504,   516,
     601,     0,   221,   220,   219,   218,   281,   280,     0,   278,
     277,   275,   276,   274,   273,   272,   269,   270,   271,   267,
     268,   262,   263,   264,   265,   266,   260,   261,   468,     0,
       0,    26,     0,     0,   692,     0,    40,    46,    45,    59,
      56,    49,    57,     0,    50,     0,     0,    58,   523,     0,
     168,   178,   178,   166,   179,   330,   329,    19,    21,    73,
      95,   449,   805,     0,     0,   482,     0,   134,   614,   723,
     719,   724,   720,     0,   614,   634,     0,   610,   725,     0,
     724,   720,     0,   336,     0,   666,     0,   868,     0,     0,
     881,     0,     0,     0,     0,   453,   629,   628,   452,   185,
     550,   549,   871,   871,   871,     0,   576,   672,     0,   566,
       0,     0,     0,   579,     0,   131,   126,     0,   181,   580,
     583,     0,     0,   558,     0,   129,   570,   104,     0,     0,
       0,     0,   110,     0,   879,   840,   879,   840,   924,   923,
     888,   887,   889,   317,   355,     0,   361,   362,     0,     0,
       0,     0,   342,   345,   748,     0,     0,     0,     0,   255,
       0,   346,   348,   351,   249,   248,   239,     0,   238,   253,
       0,     0,   709,   707,     0,   710,     0,   244,     0,     0,
     188,   378,     0,     0,     0,   716,   615,   721,   717,   728,
     610,   736,   734,   735,     0,   726,   879,     0,   732,     0,
     232,   234,   668,   669,   724,   720,     0,   367,   877,   176,
     178,   178,   174,   606,   604,   502,     0,   467,   465,   312,
       0,    24,    32,   699,    60,    55,    62,    66,    64,   164,
     162,    72,   812,   149,   155,   156,   157,     0,     0,   140,
     144,   145,   146,    97,     0,   483,   615,   723,   719,   724,
     720,     0,   610,   639,   725,     0,     0,   669,   363,   364,
     667,   365,   858,   852,   853,   851,   883,   882,   884,     0,
       0,     0,     0,   615,     0,     0,   450,   183,     0,   552,
     551,   546,   610,   840,   575,     0,   567,   580,   568,   461,
     461,   564,   565,   562,   563,   610,   840,   312,   671,     0,
     448,   127,   571,   581,   586,   587,   448,   448,     0,     0,
     448,   125,   572,   584,   448,     0,   461,     0,   559,   560,
     561,   461,   610,   319,   318,   320,   610,   107,     0,   113,
       0,     0,     0,     0,     0,     0,   743,     0,   489,     0,
     487,   258,   303,     0,   240,   241,   250,   252,   708,   706,
     713,   711,     0,   245,     0,     0,   370,   374,   376,   879,
     730,   610,   731,   172,   170,   279,     0,   470,   472,   813,
     806,   810,   142,     0,   148,     0,   743,   484,   723,   719,
       0,   725,   342,     0,   880,   614,   454,     0,   544,   879,
       0,     0,   569,   479,   479,   879,     0,     0,     0,   461,
     461,     0,   461,   461,     0,   461,     0,   557,   509,     0,
     479,   879,   879,   610,   610,   350,     0,     0,     0,     0,
       0,   214,   749,     0,   744,   745,   488,     0,     0,   242,
     714,   379,   318,   733,   879,     0,     0,   811,   141,     0,
      98,   724,   720,     0,   615,     0,   885,   451,   121,   610,
     610,   840,   574,   578,   124,   610,   461,   461,   595,   479,
     312,   671,     0,   582,   588,   589,   448,   448,   479,   479,
       0,   479,   585,   498,   573,   103,   109,   879,   879,   357,
     358,   359,   360,   477,     0,     0,     0,   739,   750,   757,
     738,     0,   746,   490,   609,   729,   471,     0,   814,   147,
     614,   879,   879,     0,   879,   594,   591,   593,     0,     0,
     461,   461,   461,   590,   592,   577,     0,   106,   112,     0,
     747,   742,   217,     0,   215,   741,   740,   312,   671,   672,
     751,   764,   767,   770,   775,     0,     0,     0,     0,     0,
       0,     0,     0,   313,   799,   807,     0,   827,   803,   802,
     801,     0,   759,     0,     0,   421,   763,   758,   800,   927,
       0,     0,   927,   119,   122,   610,   123,   461,   461,   600,
     479,   479,   500,     0,   499,   494,   478,   216,   820,   822,
     823,     0,     0,   755,     0,     0,     0,   782,   784,   785,
     786,     0,     0,     0,     0,     0,     0,     0,   821,   927,
     395,   828,     0,   760,   393,   448,     0,   394,     0,   448,
       0,     0,   761,   798,   797,   818,   819,   815,   879,   599,
     597,   596,   598,     0,     0,   511,   206,     0,   752,   765,
     754,     0,   927,     0,     0,     0,   778,   927,   787,     0,
     796,    41,   154,    36,   154,     0,    37,   808,     0,   391,
     392,     0,     0,     0,   390,   755,   120,   497,   496,    92,
      95,   213,     0,   421,     0,   755,   755,   768,     0,   743,
     825,   771,     0,     0,     0,   927,   783,   795,    42,    38,
     812,     0,   762,     0,   495,   207,   448,   753,   766,     0,
     756,   826,     0,   824,   776,   780,   779,   809,   832,   832,
       0,   493,   491,   492,   461,   204,     0,     0,   210,     0,
     209,   755,   927,     0,     0,     0,   833,   834,     0,   788,
       0,     0,   769,   772,   777,   781,     0,     0,     0,     0,
       0,     0,   832,     0,   211,   205,     0,     0,     0,   838,
       0,   791,   835,     0,     0,   789,     0,     0,   836,     0,
       0,     0,     0,     0,     0,   212,   773,     0,   839,   793,
     794,     0,   790,   755,     0,     0,   774,   837,   792,     0,
       0,     0
};

static const short yydefgoto[] =
{
    1819,   461,     2,   462,   171,   809,   346,   187,     3,     4,
      38,   141,   774,   393,    39,   775,  1163,  1599,    41,   413,
    1646,   779,    42,    43,   423,    44,  1164,   786,  1089,   787,
     788,   789,    46,   178,   179,    47,   818,   190,   186,   479,
    1426,    48,    49,   905,  1185,   911,  1187,    50,  1166,  1167,
     191,   192,   819,  1113,   480,  1287,  1288,  1289,   732,  1290,
     242,    51,  1102,  1101,   798,   795,  1261,  1260,  1046,  1043,
     140,  1100,    52,   244,    53,  1040,   639,   347,   348,   349,
     350,   631,  1757,  1678,  1759,  1712,  1796,  1472,   386,  1029,
     351,   677,   987,   352,   387,   388,   354,   355,   375,    55,
     266,   780,   442,   160,    56,    57,   356,   634,   357,   358,
     359,   820,   360,  1602,   540,   697,   361,  1169,   493,   225,
     494,   362,   226,   363,   364,    62,   507,   227,   204,   217,
      64,   521,   541,  1437,   873,  1325,   205,   218,    65,   554,
     874,    66,    67,   770,   771,   772,  1534,   485,   950,   951,
    1710,  1675,  1624,  1566,    68,   737,   377,   902,  1523,  1625,
    1208,   733,    69,    70,    71,    72,    73,   253,   895,   896,
     897,   898,  1171,  1367,  1172,  1173,  1174,  1352,  1362,  1353,
    1513,  1354,  1355,  1514,  1515,   734,   735,   736,   678,  1017,
     366,   198,   519,   512,   207,    75,    76,    77,   148,   149,
     163,    79,   136,   367,   368,   369,    81,   390,    83,   900,
     127,   128,   129,   560,   110,    84,   391,   992,   993,  1012,
    1008,   700,  1536,  1537,  1473,  1474,  1475,  1538,  1386,  1539,
    1606,  1631,  1715,  1681,  1682,  1540,  1607,  1705,  1632,  1716,
    1633,  1739,  1634,  1742,  1786,  1813,  1635,  1761,  1725,  1762,
    1687,   481,   816,  1282,  1608,  1649,  1730,  1420,  1421,  1486,
    1612,  1714,  1548,  1609,  1721,  1652,   957,  1765,  1766,  1767,
    1790,   498,  1013,   853,  1139,  1315,   500,   501,   502,   849,
     503,   154,   851,  1176,    93,   723,   858,  1318,  1319,   611,
      87,   571,    88,   940
};

static const short yypact[] =
{
      82,   121,-32768,-32768,  4358,-32768,   189,    87,   243,   260,
      49,   102,-32768,-32768,  1610,-32768,-32768,   110,   211,-32768,
  -32768,-32768,  1644,   974,  1208,   112,-32768,-32768,   216,   270,
  -32768,  2972,  2972,-32768,  5961,-32768,  4358,   234,-32768,-32768,
     273,-32768,    24,-32768,-32768,  2991,-32768,-32768,   237,   824,
     323,   296,   364,-32768,-32768,-32768,-32768,   268,  2450,-32768,
    6419,-32768,   403,  1554,   160,-32768,   495,-32768,-32768,  1872,
     606,   788,-32768,   477,  7215,-32768,-32768,-32768,  1196,-32768,
  -32768,-32768,  2214,-32768,-32768,  2555,-32768,  5640,   480,-32768,
  -32768,-32768, 11788,   578,-32768, 11788,-32768, 11788,-32768,-32768,
  -32768,   243,   260,   216,   598,-32768,   607,   364,-32768,  1238,
  -32768,   535, 11881,   579,-32768,-32768,-32768,-32768,-32768,   346,
     639,   473,   511,   515,   668,   673,-32768,-32768,  1471,-32768,
     453,   243,   260,-32768,   216,   598,-32768,  1305,  2630,   657,
    7721,   717, 11788,-32768, 11788,   693,  6404,  4494,-32768,-32768,
    3156,  2721,  4494,-32768,  1888,  7496,  7496,  5961,   665,   669,
  -32768,   268,   893,   674,   680,-32768,-32768,   792,-32768,   703,
  -32768,  5341,-32768,-32768,   112,  3979,   742,-32768,-32768,-32768,
     237,  5527,  7934,   804,   753,-32768,-32768,   749,   495,   844,
     193,   344,   787,-32768,-32768,-32768,  9415, 10927,-32768,-32768,
    7603,  7603,  7596,  1196,   818,-32768,-32768,   422,-32768,-32768,
    3394,-32768,-32768,-32768,-32768,-32768,  1554,   860,-32768,   495,
    1196, 11881,-32768,-32768,-32768,  1452,  1554,-32768,   495,-32768,
    5527,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,   778,   812,   364,-32768,   495,  1477,  1921,-32768,-32768,
  -32768,-32768,-32768,   796,-32768,  1536,   495,   535,-32768,   553,
    1034,  2491,   584,-32768,    98,-32768,-32768,-32768,-32768,-32768,
    8093,-32768,   598,-32768,-32768,-32768,-32768,  3747,-32768,   793,
     813,-32768,-32768,-32768,-32768,   835,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,   826,-32768,
  -32768,  1536,  7215,   815,-32768,   822,-32768,-32768,-32768,-32768,
  -32768, 12998, 12998,   836,-32768,-32768,-32768,-32768,-32768,   842,
     851,   868,   870,   873,   999, 12346,  1994, 12998,-32768,-32768,
   12998,-32768,-32768, 12998,  9713,-32768, 12998,   484,   895,-32768,
   12998,-32768, 12439,-32768, 13456,   339,   915,  6687, 12532,-32768,
    2012,-32768,   542, 13091, 13184,  7360,  6576,-32768,   355,-32768,
    1933,  2927,   875,   484,   484, 11788,  7721,  1013,-32768,   917,
    1994,   584,-32768,-32768, 12626,   879,   918,-32768, 13386,   896,
    1952,  3650,  1619,   703,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,   639,   473,   511,  1994,   515,   668,   937,   673,
  -32768,   966,-32768,  1601,   917,   243,   260,-32768,-32768,-32768,
  -32768,-32768,-32768,  8717,-32768,  5527, 13290,  1784,-32768,-32768,
     484,   661, 11788,-32768,  6404,-32768,  4434,-32768,   949,   952,
  -32768,-32768,-32768,   893,  4494,-32768,-32768,  4494,-32768,   922,
  -32768,-32768,-32768,   893,   893,   893,-32768,-32768,-32768,  8093,
     933,   934,   955,-32768,-32768,-32768,-32768,  7721,-32768,   872,
     897,-32768,-32768,  1041,-32768,   495,-32768,-32768,-32768,-32768,
    1009,-32768,-32768, 10369, 12626,-32768,-32768,   972,-32768,   918,
     983, 13386,   256,  2092,  7934,  2092,  6103,  5967,  1008,-32768,
     265,  6820,  1017,  1021,   822,-32768,   996,   372,   118,  8175,
    8364,-32768,-32768,  8364,-32768,  8373,  8373,  7596,  8531,  1010,
  -32768,   495,  5527,-32768, 11020,-32768,-32768,  8435,  1452,  1554,
    5527,-32768,   495,  1025,  1027,-32768,-32768,  1452,-32768,   495,
    1116,-32768, 11788,-32768,-32768,   917,   584,   778,-32768,-32768,
    1477,  1904,-32768,  1536,   495,-32768,-32768,-32768,  1072,  1074,
    1103,  1087,-32768,-32768,-32768,-32768,  6404,-32768,  1077,-32768,
     406,-32768,  1055,-32768,  1063,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,  1536,-32768,-32768,   350,-32768,
     978,-32768, 11788, 12626,-32768,-32768, 12626, 11881, 13325, 13325,
   13325, 13325, 13456,-32768,-32768,-32768,-32768,  1068, 12719, 12719,
    9713,  1085,   167,  1089,-32768,  1091,-32768,-32768,-32768,  1199,
   11788,-32768,  9806,  9713,-32768, 12346, 12346, 10462, 12346, 12346,
   12346, 12346, 12346, 12346, 12346, 12346, 12346, 12346, 12346, 12346,
   12346, 12346, 12346, 12346, 12346, 12346,-32768, 12626,-32768,-32768,
  -32768,-32768,-32768, 12626, 12626, 12626, 11881,  1274,   519,   540,
   11113,-32768,-32768,  1149,  2491,  1206,   412,   439,   529,  2368,
     978,-32768,  2623,  2623,  2108, 11206,  1120,  1168,-32768,-32768,
     510,  9713,-32768,  9713,-32768, 11600,  1941,-32768,   449,   535,
  -32768,-32768, 12626,  2491,-32768,-32768,   216,-32768,-32768,-32768,
     407,   480, 12626,  1159,-32768,-32768,   484,-32768,  5527,  2283,
  -32768,-32768,  1158,-32768,  1115,  1170,-32768,  1013,   937, 13434,
  -32768, 10648, 10741, 12626, 12626, 10462, 12626, 12626, 12626, 12626,
   12626, 12626, 12626, 12626, 12626, 12626, 12626, 12626, 12626, 12626,
   12626, 12626, 12626, 12626, 12626,-32768,-32768,-32768,-32768,-32768,
     136,-32768,  1139,  1124,   703,  1601,  1181, 11788,-32768,  1175,
  -32768,-32768,  2630,  1045,  1163,  1210,   491,  1182,  1184,-32768,
  -32768,  6310,  1872,-32768,  1186,-32768,-32768,-32768,-32768,-32768,
  -32768,   484,-32768,-32768,  1147,  1151,-32768,  1202,-32768,-32768,
     237,-32768,-32768,-32768,-32768,  1152,-32768,-32768,-32768,-32768,
  -32768,-32768,  9601, 13434,-32768,  1156,-32768,-32768,-32768,-32768,
  -32768,  2228,  2228,  4836,-32768,-32768,-32768,-32768,  3394,  2555,
  -32768, 11694,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
    1021,  1203,-32768,-32768,-32768, 11974,  1168,   538,-32768,-32768,
    8175,-32768,-32768,  8531,  8364,  8364,  8516,  8516,  8531,   449,
  -32768,-32768,  8435,-32768,  1204,-32768,-32768,  1161,   118,  8175,
  -32768,  1452,-32768,-32768,-32768,-32768,   495,  1194,   778,-32768,
     473,   511,-32768,-32768,   673,  1214,-32768,-32768,   109,-32768,
  -32768,  2084,  3860,-32768,   118,  8792, 11788, 11788,-32768, 11788,
     118,  8792,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
     575,   575,   575,   833,-32768,   484,  1167, 13412,  1171,  1174,
    1209,  7995,  1215,  1223,  1226,-32768,  1176,-32768,-32768,  1197,
    1254,-32768,-32768,  1255,   942,   990,    57,   708, 12626,  1259,
  -32768,  1266,  1219, 13456, 13456,-32768,-32768,  1272,  5425,  8058,
    5992,  7833,  4988,  3739,  3341,  3273,  3273,  2353,  2353,  1379,
    1379,   876,   876,   876,-32768,-32768,  1221,  1228,  1227,  1230,
    1237,  1247, 13325,   519,-32768, 10369, 12626,-32768,-32768,-32768,
   12626,-32768,-32768,  1271, 12998,  1257,  1277,  1294,  1325,-32768,
   12626,-32768, 12626,-32768, 12626,  2812,  4423,-32768,-32768,  4423,
  -32768,   173,  1267,  1268,-32768,  1263, 13325,   118,-32768,   118,
    4709,-32768,  8792, 11299,  1269,  1284,  5512,  5512,  9223,  1285,
   12439,  1289,  3625,  5082,  3650,  1082,  1292,  1074,  1293,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768, 12626,-32768,  1994,
  -32768,  1307,-32768, 13434,-32768, 13434, 13434, 13434,  1317,  6851,
    8782,  4736, 11322,  9624,  5808,  6254,  4166,  4166,  4166,  2566,
    2566,  1627,  1627,   909,   909,   909,-32768,-32768,  1619,  1295,
   12812,-32768,  1312,  1361,-32768,   484,-32768,-32768,-32768,-32768,
  -32768,-32768,  3291,  8717,-32768, 13325, 11788,-32768,   781, 12346,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
     237,-32768,-32768,  1753,  1364,-32768,    21,-32768,  4644,  2746,
    2746,  3231,  3231,  4836,  4908,   131,  3394,-32768,  3387,  5086,
    8268,  8268,  9319,   333,  1318,   696,  1357,-32768, 10369,  9902,
  -32768,  4747,  2957,  2957,  3186,-32768,-32768,-32768,  1363,-32768,
  -32768,-32768,-32768,-32768,-32768,  1856,-32768,  1078,   998,-32768,
   12626,  8574,  5152,-32768,  5152,   208,   208,   493,   592,  3549,
    7341,    60,  4133,-32768,   154,   208,-32768,-32768,  1326,   484,
     484,   484,-32768,  1329,   118,  8792,   118,  8792,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768, 13325,-32768,-32768,  1340,  1345,
    1348,  1349,  1147,-32768,-32768, 13320, 10369,  9997,  1335,-32768,
   12346,-32768,-32768,-32768,-32768,-32768,   664,  1337,-32768,-32768,
    1339,   172,   465,   465,  1338,   465, 12626,-32768, 12998,  1449,
   11788,-32768,  1373,  1375,  1376,-32768,  2812,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,  2812,-32768,   118,  1377,-32768,  1360,
  -32768,-32768,-32768,-32768,  3853,  3853,  5759,-32768,-32768,-32768,
  -32768,-32768,-32768, 13434,-32768,-32768, 12626,-32768,-32768,   186,
    1381,-32768,-32768,-32768,-32768,-32768,-32768,-32768, 13456,-32768,
  -32768,-32768,  1391,-32768,   639,   515,   668,   149,   608,-32768,
  -32768,-32768,-32768,-32768, 10090,-32768,  4644,  2746,  2746,  3998,
    3998,  5867,-32768,   707,  3387,  4644,  1384,   410,   714,   774,
     816,   624,-32768,-32768,-32768,-32768,-32768,-32768,-32768,   198,
    3288,  3288,  2444,  2444,  2444, 10369,-32768,-32768,  1904,-32768,
  -32768,-32768,-32768,  8792, 13434,   331,-32768,  1065,-32768,   495,
     495,-32768,-32768,-32768,-32768,-32768,  8792,   505,  1042, 12626,
    1116,-32768,  1433,-32768,-32768,-32768,   248,   418,  2214,  2721,
     582,   208,  1439,-32768,   724,  1437,   495,  4228,-32768,-32768,
  -32768,   495,-32768,-32768,  1448,-32768,-32768,-32768,  1395,-32768,
    1397,  1403, 12626, 12626, 12626, 12626,    47, 10369,-32768,  1451,
  -32768,-32768, 13456, 12626,-32768,   664,-32768,-32768,-32768,-32768,
  -32768,-32768,  1406,-32768,  1473,   484,-32768,-32768,-32768,   118,
  -32768,-32768,-32768,-32768,-32768, 13434, 12626,-32768,-32768,-32768,
    1391,-32768,-32768,   964,-32768, 12626,    47,-32768,  4983,  4983,
     449,  5281,   848,  4747,-32768,  2444,-32768, 10369,-32768,   118,
    1414,   614,-32768,  1458,  1458,   118,  1418, 12626, 12626,  7391,
     495,  3722,   495,   495,  5248,   495,  7103,-32768,-32768,  4540,
    1458,   118,   118,-32768,-32768,-32768,  1423,  1424,  1425,  1429,
    1994,-32768,-32768,  9128,  1514,-32768,-32768, 10369,  1436,-32768,
  -32768,-32768,-32768,-32768,   118,  1440,  1457,-32768,-32768,  1443,
  -32768,  6112,  6112,  6504,  4027,  4027,-32768,-32768,-32768,-32768,
  -32768,  8792,-32768,-32768,-32768,-32768,  7391,  7391,-32768,  1458,
     585,  1097, 12626,-32768,-32768,-32768,  1116,  1116,  1458,  1458,
    1077,  1458,-32768,-32768,-32768,-32768,-32768,   118,   118,-32768,
  -32768,-32768,-32768,-32768,   977,   201,  9016,-32768,-32768,-32768,
  -32768, 11410,-32768,-32768,-32768,-32768,-32768, 13255,-32768,-32768,
    4027,   118,   118,  1446,   118,-32768,-32768,-32768, 12626, 12626,
    7391,   495,   495,-32768,-32768,-32768,  8879,-32768,-32768,  1994,
  -32768,-32768,-32768,   217,-32768,-32768,-32768,  1494,  1114,  1127,
  -32768,-32768,-32768,-32768,-32768, 12626,  1499,  1502,  1507, 12067,
     335,  1994,   779,   684,-32768,-32768, 12160,  1564,-32768,-32768,
  -32768,  1512,-32768,  3114,  6951,  7782,  1561,-32768,-32768,  1480,
    1472,  1484,-32768,-32768,-32768,-32768,-32768,  7391,  7391,-32768,
    1458,  1458,-32768, 10834,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,   633,   633,  1538,  1513,  1515,  8627,-32768,-32768,-32768,
  -32768,  1539, 12626,  1549,  1553,  1560,  2125,  2278,-32768,-32768,
  -32768,-32768,  1535,-32768,-32768,  1116,  1040,-32768,  1050,  1116,
   12253,  1084,-32768,-32768,-32768,-32768,-32768,-32768,   118,-32768,
  -32768,-32768,-32768,  1522, 13342,  1530,-32768, 11881,-32768,-32768,
  -32768,  1618,-32768,  9508, 11881, 12626,-32768,-32768,-32768,  1574,
  -32768,-32768,  1582,-32768,  1560,  2125,-32768,-32768,  1629,-32768,
  -32768, 12905, 12905, 10183,-32768,  1538,-32768,-32768,-32768,   323,
     237,-32768,  1532,   739,  5527,  1538,  1538,-32768, 11505,    47,
  -32768,-32768,  1580,  1544,  8928,-32768,-32768,-32768,-32768,-32768,
    1391,   420,-32768,   207,-32768,-32768,  1116,-32768,-32768,   642,
  -32768,-32768, 10276,-32768,-32768,-32768,-32768,  1391,    94,    94,
    1583,-32768,-32768,-32768,   495,-32768, 12626,  1593,-32768,  1596,
  -32768,  1538,-32768,  1550,  1994,    53,  1600,-32768,   466,-32768,
    1597,  1555,-32768,-32768,-32768,-32768, 12626,  1573,  1651,  1604,
      94,  1651,    94,  1611,-32768,-32768, 10555,  1577,  1676,-32768,
     223,-32768,-32768,   224,    77,-32768, 10369,  1579,-32768,  1598,
    1679,  1631,  1635,  1651,  1636,-32768,-32768, 12626,-32768,-32768,
  -32768,   225,-32768,  1538,  1590,  1638,-32768,-32768,-32768,  1718,
    1720,-32768
};

static const short yypgoto[] =
{
  -32768,  1722,-32768,  -348,  1547,  -413,    44,    -3,  1723,-32768,
    1688,-32768,-32768,-32768, -1473,-32768,   524,-32768, -1469,-32768,
      83,   953,    31,  -401,-32768,-32768,   132,-32768,  -730,-32768,
  -32768,   636,    56,  1558,  1278,  1565,-32768,    26,  -178,  -803,
  -32768,     1,   250,-32768,-32768,-32768,-32768,-32768,   569,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,   321,   -14,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
    1647,  -686,  7562,  -182,   -73,  -689,  -353,    65,  1603,  -602,
  -32768,   127,-32768,   117,-32768, -1576,-32768, -1361,  -189,  1106,
    -322,-32768,  -946,  7383,  6109,  6536,  1926,  4962,  1438,  -340,
     -63,  -110,    35,  -138,   -66,   195,-32768,-32768,-32768,  -337,
  -32768,-32768,-32768, -1498,    70,  -361,  6929,    43,    25,  -160,
      59,    13,  -198,-32768,-32768,-32768,    -1,  -123,  -176,  -171,
      -2,    81,   176,-32768,  -403,-32768,-32768,-32768,-32768,-32768,
     468,  1341,  2007,-32768,   675,-32768,-32768, -1306,  -412,   929,
  -32768,-32768,-32768,-32768,   116,-32768,-32768,-32768,-32768,-32768,
  -32768,  1024,  -409,-32768,-32768,-32768,-32768,-32768,-32768,   432,
     609,-32768,-32768,-32768,   396, -1047,-32768,-32768,-32768,-32768,
  -32768,-32768,   596,-32768,   314,  1037,-32768,   726,  1099,  2267,
      88,  1571,  5665,  1884,-32768,  -528,-32768,    46,   786,   221,
    -130,   347,   -29,  5778,  1420,-32768,  4145,  2244,  1859,   -17,
    -118,-32768,  1655,   -61,-32768,  6190,  3602,  -392,-32768,  1794,
     957,-32768,-32768,   251,-32768,-32768,   312,  1164,-32768, -1056,
  -32768,-32768,-32768, -1560,-32768, -1431,    79,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,    68,-32768,-32768,-32768,-32768,-32768,    73, -1370,-32768,
  -32768,   -55,-32768,-32768,-32768,-32768,  -735, -1457,-32768,    39,
   -1579,  -650,  -143,   970,-32768,-32768,-32768,-32768,  -408,-32768,
    -404,  -212,-32768,    71,-32768,-32768,   715,   388,-32768,   429,
  -32768,  3230,  -222,  -731
};


#define	YYLAST		13543


static const short yytable[] =
{
     106,    37,   468,    63,   706,   469,   126,   489,   119,   264,
    1058,   470,   412,  1112,   792,   793,   267,    61,   529,   794,
     724,   725,   785,   899,   457,   445,   448,   419,   420,    59,
     644,   717,   313,    37,   718,    63,  1041,  1218,   942,   561,
     551,   702,   704,   183,    63,   773,   180,    58,    36,    61,
    1487,   717,   810,   499,   718,   241,   528,   553,    61,   216,
     108,    59,  1097,    60,   548,  1490,   537,   411,  1598,   159,
      59,   824,  1600,   255,   418,    86,   176,   799,   800,    58,
      36,  1470,    -1,  1294,   267,   169,   311,  1114,   181,   175,
    -876,   365,    74,   793,   365,    60,   365,   850,  1650,  1365,
     310,   177,   536,   538,   182,  1576,  1763,    86,  1723,   421,
    1104,   365,  1103,   605,   408,  1336,  1153,  1338,  1778,   147,
     152,    -2,  -153,   170,    74,  1368,    98,   565,   203,   883,
     188,   274,  1295,    74,   142,   706,    45,  1502,  1503,   427,
     440,   365,  1803,   365,   267,  1732,   856,   563,  1154,   721,
    1422,   903,    99,    61,  1524,  1737,  1738,   382,  1471,   258,
     373,   184,   374,  1779,    92,    59,  1760,   605,    45,   721,
      63,  1366,   465,   183,    63,   312,   180,    45,  1664,   229,
    -633,   216,   857,   425,    61,  1720,   828,  1804,    61,   139,
    1764,   446,   449,   564,   477,   496,    59,   429,  1078,   426,
      59,  1774,  1793,  1557,   570,   112,   176,   430,  1751,   495,
    -137,  1423,  1563,  1564,    58,  1565,   666,  1369,   181,   175,
     365,   691,   230,   231,  1811,    78,  -633,  -633,    74,   161,
      60,   177,   547,   549,   182,   829,    15,   159,   830,   385,
    -448,  -633,    86,   444,   447,  1598,  1079,   559,  1416,  1600,
     687,   203,    89,  1816,  -138,  1178,  1726,    78,  -138,    74,
    1433,  1183,   667,    74,  1571,  1370,    78,   855,  -138,   828,
    1394,  -448,  -138,    45,  -396,  -448,    15,  -326,   844,   208,
    1571,   220,  1397,   941,   497,  1800,  1800,  1800,   510,   513,
     478,   184,  1768,   142,  1746,   489,  1417,   686,    90,    94,
      91,   532,   679,   274,   478,   457,   113,    45,  1434,  -396,
     215,   255,  1572,  -396,  1671,  1672,    96,   195,   829,  -448,
      95,   830,   623,  -870,   506,  1794,   143,   845,  1627,   167,
     846,  1775,   229,  1801,  1802,  1815,   168,    97,   100,   114,
     115,   229,   229,   365,   776,  -396,   185,   144,   533,   189,
     161,   161,   161,   379,   131,   132,   311,  1259,  1741,   193,
    1262,   428,  1274,   196,   197,   255,   738,   433,   889,   881,
     310,   229,  1247,  1042,   365,   729,  1092,  1487,   769,   633,
     457,   164,  -333,   718,   781,   445,   448,    96,   666,    61,
     424,   738,    78,   482,   116,   117,    78,   161,  1109,  1110,
     380,    59,   208,   220,   711,   536,   538,   394,    97,   381,
     135,   483,  1368,   395,   536,  1279,  1280,   274,  1642,   728,
     194,   691,   791,  -335,   489,   216,  1082,   229,  -333,  -333,
     538,   365,   215,   263,   667,   426,   495,   274,  -335,   484,
     726,  1441,  -335,  -326,  -397,   312,    15,   324,  1105,  1479,
     712,   208,   379,     8,     9,   914,   120,   121,   122,  -335,
    1327,   999,   561,    26,    74,   183,    63,   855,   812,   131,
     132,   195,  -335,  -335,   565,  -335,  1748,  -335,   489,  -397,
      61,   229,   538,  -397,   489,  1749,   489,   489,  1001,   446,
     805,   561,    59,   216,  1277,   796,   255,   801,   221,   380,
     791,   915,   164,   164,   164,  -335,  -335,  1000,   381,   135,
     181,   497,   123,   124,   495,  -397,   489,   196,   524,  1341,
    -335,    26,  1781,   489,   134,   135,   182,    18,    40,   397,
    1750,  1782,   263,   489,  1002,  1378,   888,  1380,   988,     8,
       9,   365,   252,   229,   131,   132,   131,   132,   989,   164,
      95,   446,   449,  1093,  1342,    74,  1667,   314,  1343,  1021,
      40,   990,   637,   834,   638,   840,   842,   398,   984,  1094,
    1447,   399,  1193,  1219,  1413,  1414,  1783,  1680,  1003,   131,
     132,   372,   432,   184,   565,  1291,   985,  1140,    97,   497,
    1344,   691,   142,  1697,   134,   135,    26,   730,    26,   134,
     135,   134,   135,   864,   865,  1022,  1023,   887,  -130,   555,
      15,   365,   229,   988,   986,   692,   365,   931,   931,   931,
     931,   886,   679,   989,  1004,   693,   727,   899,   949,   365,
     432,    26,  1108,  1141,   134,   135,   990,   694,   695,   365,
     562,  1345,   365,  -130,   229,   229,   208,  -130,   606,  1680,
    1558,   877,   489,   229,   143,   433,   474,  1424,   607,  1680,
    1680,   142,   432,  1500,   446,   936,   489,   248,   378,   229,
     997,   249,  1087,  -311,   392,   365,   311,   925,   633,  -130,
    1150,  1151,  1676,  1440,   792,   793,  1155,  1346,    78,   794,
     310,  1755,   785,   791,   717,   396,  1446,   718,   875,  1037,
     365,   314,   365,  1425,   496,  1680,   882,   495,   644,  1501,
     161,   161,   161,   984,   208,   837,   208,   208,   495,  -311,
    -311,   229,   848,   640,   400,   457,  1312,  1314,  1677,   401,
     433,   985,  1273,   605,  -311,   422,   633,  1756,   633,   637,
    1031,   638,  1541,   208,   928,  -658,   781,   223,   224,  1648,
    -128,   208,    15,  1088,    14,   274,  -632,  1680,   536,   986,
    1393,   142,   499,  -312,   143,   312,   126,   174,   499,  1090,
     432,    18,   267,  -154,   956,  -326,   365,    20,  1098,   450,
    1006,  1009,   497,   412,   458,  -128,    23,   433,   691,  -128,
    -653,  -658,  -658,   497,  1388,  1390,  1309,   489,  1044,   718,
     899,   978,  -632,  -632,   460,  1541,  -658,   995,   949,  -312,
    -312,   489,   721,   489,    -7,   489,   472,  -632,   153,   131,
     132,  -128,  1015,  -310,  -312,   133,  1373,  1374,  1375,  1168,
    1398,  1399,   791,  1401,   855,    26,   379,   131,   132,  1645,
     496,   170,  1085,   -56,   473,   229,   495,   476,   -56,   250,
     486,  1553,    15,   251,   495,   542,  -448,   552,   542,   -56,
     856,   842,   164,   164,   164,  -659,   230,   471,   159,  -310,
    -310,    26,   956,   543,   134,   135,  1134,   544,  1541,   499,
     522,   523,  1390,   380,  -310,   274,  -448,  -448,   606,   572,
    1031,   489,   381,   135,   457,  1291,   271,  -335,   607,    10,
     580,    63,   446,   805,   791,   365,   365,   229,   365,   574,
     791,  -659,  -659,  1436,  1311,    61,   569,   613,   495,  1119,
    1120,   497,   530,   531,   495,    18,  -659,    59,   618,   497,
    1752,   616,  1281,   435,   522,   813,    21,   617,   437,   603,
    1328,  1329,  1330,  -335,  -335,   619,  1162,   620,  1722,   208,
     621,  1718,   451,   452,  1142,  1143,  1541,   640,  -329,   530,
     814,  1170,   664,   665,   668,  1283,   453,  1284,   890,   891,
     722,  1179,  1180,   555,  1181,  1476,   454,   120,   121,   122,
     741,   931,   131,   132,    33,  1221,   457,   153,   455,   740,
      74,   445,   448,   497,  1541,   763,   764,   229,    94,   497,
     445,   448,   131,   132,   669,   670,   765,  -151,   671,   672,
     673,   674,   208,  -143,   777,   931,   100,   114,   115,    95,
      26,   791,   778,  1285,  1286,  1497,    95,   496,   161,    97,
      26,  1541,   804,   123,   124,   495,   161,   134,   135,  1569,
    1570,   495,   499,   807,   499,    -6,    96,   229,   402,   403,
     404,  1797,  1482,   815,    26,  -152,   567,   134,   135,  -143,
     267,  -193,   446,   936,   769,  1543,   808,    97,  1347,  1348,
       9,    10,   116,   117,   817,   731,   142,  -193,  1090,  -193,
     274,   433,   826,   556,  -869,   379,     8,     9,   852,  1168,
      96,  1168,   791,   827,   931,   365,  1292,  1168,    94,  1168,
     433,    26,   522,  1699,   406,   407,   495,  1448,    21,   854,
     497,    97,   530,  1700,  1006,  1009,   497,  1224,   843,    95,
     871,    26,   791,  1175,    28,    29,   912,  1332,  1442,   557,
    1349,   496,   380,    96,    96,   884,   495,   885,   200,   793,
     931,   381,   135,  1611,    15,   495,   522,  1704,   201,   906,
    1249,   907,  1165,    94,    97,    97,    33,   446,   449,   908,
     202,    63,  1559,    63,   909,   569,   446,  1306,   916,   216,
      94,    63,   913,  1333,    95,    61,   917,    61,   935,  1629,
     164,   497,   274,    96,   791,    61,   791,    59,   164,    59,
     499,    95,  1630,  1389,   931,   937,   159,    59,   495,   938,
     495,   941,  -875,   499,    97,   996,  1162,  1337,  1162,  1297,
    1298,   497,   131,   132,   998,  1016,  1162,  1018,  1297,  1298,
     497,  1170,  1039,  1170,    15,  1047,  1048,   489,  -448,   365,
     802,  1170,  1049,   803,  1080,  1081,   489,  1084,  1086,  1351,
    1091,   379,     8,     9,   856,   806,  1339,  1340,    20,  1095,
      74,  1096,    74,  1099,   133,   791,  1371,  -329,  -448,  -448,
      74,  1106,  1111,  -448,    26,  1107,  1117,   134,   135,   495,
    1138,  1145,  1149,   497,  1146,   497,  1152,  1194,     8,     9,
    1389,  1196,    12,    13,  1197,   264,  1202,  1198,   380,    14,
     446,   805,   267,  1199,  1168,  1405,   435,   381,   135,   437,
     791,  1200,   490,    16,  1201,    17,    18,  1203,   414,   415,
     416,    10,    20,   567,   495,  1204,   161,   161,   161,   699,
    -150,    23,   707,   710,  1206,   161,   161,   161,  1207,  1209,
      26,  1211,   791,   134,   135,   446,   805,  1210,  1212,   433,
    1213,  1214,  1006,  1009,   497,   791,   495,  1215,    21,  1190,
    1191,  1192,   856,  1402,  1148,   261,   161,  1216,   499,   495,
    1308,     8,     9,    10,   262,   272,    63,  1226,  1229,   982,
    1228,  1230,   146,   146,  1231,   162,  1241,  1239,  1240,  1250,
      61,   570,  1266,  1175,  1805,  1175,  1168,  1428,  1429,   497,
    1357,  1364,    59,  1175,  1251,  1252,    33,   324,   715,  1253,
      21,   219,  1257,  1258,   228,  1268,  1292,  1351,  1142,  1143,
     245,  1162,  1165,    26,  1165,   256,    28,   272,  1265,  1350,
    1360,   497,  1165,  1271,  1272,  1293,  1170,  1656,  1307,  1661,
    1326,  1450,   931,  1658,   497,  1382,  1372,  1452,  1453,  1376,
    1383,  1450,  1455,  1384,  1385,  1453,  1391,  1395,    33,  1396,
     836,  1400,   699,   707,   710,    74,  1533,  1404,    63,   535,
     223,   224,   661,   662,   663,   664,   665,    14,   164,   164,
     164,   489,    61,  1412,   402,   403,   404,   164,   164,   164,
     545,   101,   102,  1406,    59,  1407,  1408,  1411,   434,  1419,
      20,  1418,   791,   434,  1432,  1451,   443,   443,   162,    23,
     791,  1456,  1457,  1162,  -699,  1463,   495,  1464,   164,  1466,
    1467,  1468,  1469,  1465,   495,   605,  1477,   433,  1170,  1480,
    1478,   405,  1481,   219,  1499,   483,   433,   380,  1505,   475,
     406,   407,  1734,  1529,  1530,  1531,   546,   104,  1597,  1532,
    1605,   509,   509,   518,   223,   224,   791,    74,  1470,  1544,
    1546,    14,  1547,  1549,    61,  1626,  1615,   228,  1357,  1628,
     495,   222,   223,   224,  1637,  1638,    59,   539,    18,    14,
    1639,   445,   448,  1651,    20,  1653,  1643,  1644,  1662,  1428,
    1429,   497,  1665,    23,  1603,  1596,    18,  1350,  1175,   497,
     825,  1663,    20,  1147,  1666,  1605,   228,  1561,  1562,  -927,
    1604,    23,  1688,   216,   271,   415,   416,    10,  1683,    61,
    1684,   566,  1690,   100,   101,   102,  1691,  1165,   153,  1177,
     395,    59,   100,   114,   115,  1182,   766,   767,   768,    74,
    1698,  1707,  1693,  1696,  1709,   497,  1717,  1727,  1728,  1603,
    1596,  1731,  1735,  1743,    21,  1776,  1769,   100,   114,   115,
     802,   803,   228,   256,  1744,  1604,  1772,    26,   806,  1773,
      28,   272,  1780,  1789,  1784,  1785,    26,  1791,  1601,   103,
     104,   105,  1517,  1655,  1795,  1655,  1713,  1517,   116,   117,
    1175,  1729,  1605,  1713,    74,   443,  1788,  1798,  1799,  1806,
     310,  1808,    33,  1807,  1809,  1134,    61,   310,  1810,  1812,
    1817,  1818,   365,   116,   117,   118,   228,   256,    59,  1165,
     760,   761,   762,   763,   764,  1597,  1641,  1605,  1820,   926,
    1821,   229,     1,   467,   166,     5,  1603,  1596,  1083,  1275,
    1695,    61,  1242,   466,  1243,  1733,   464,   446,  1306,  1361,
     532,  1713,  1604,    59,  1488,   811,   376,   431,   707,  1679,
    1777,  1116,   612,  1267,  1283,   310,  1284,   890,   891,  1050,
    1438,  1603,  1596,  1459,  1331,   312,  1363,   219,   228,  1689,
    1522,    74,   312,   976,  1051,  1264,   983,  1604,   525,   977,
     688,   979,   980,   410,  1736,   434,  1542,  1575,   434,   864,
     865,   222,   223,   224,   162,   162,   162,  1740,   939,    14,
     566,  1753,  -143,  1747,  1711,     0,    74,  1443,  1444,    26,
     956,  1711,  1285,  1286,  -139,  -139,    18,  1754,  1036,  1792,
    1137,  1496,    20,     0,   208,  1659,   208,     0,  1038,   229,
     312,    23,     0,     0,  1458,   219,     0,   228,   256,  1460,
       0,     0,     0,     0,     0,  1601,     0,   797,  -143,     0,
       0,   860,     0,     0,   860,   161,   863,   863,   518,   120,
     890,   891,   475,     0,     0,     0,     0,     0,   879,  1711,
     539,     0,     0,   475,     0,   100,   101,   102,     0,   233,
     234,   235,     0,  1771,     0,     0,     0,     0,   707,     0,
       0,   100,   438,   439,   539,   475,   161,   161,   161,  1377,
       0,  1379,     0,  1787,    18,   435,   437,   120,   890,   891,
     236,   892,    26,   956,   567,   123,   124,  1508,  1509,     0,
    1518,  1519,     0,  1521,   100,   101,   102,     0,    26,     0,
       0,   103,   104,   237,  1814,   208,   414,     8,     9,    10,
       0,   269,   206,   893,     0,     0,   539,   103,   117,     0,
    -610,     0,     0,     0,  -610,   414,     8,     9,    10,     0,
      26,  1410,  1235,   123,   124,     0,     0,     0,   269,   162,
     162,   443,     0,     0,  1555,  1556,    21,   238,   239,   240,
     103,   104,     0,   713,   443,     0,     0,     0,     0,  1235,
    1018,     0,   262,   272,     0,    21,   269,   100,   114,   115,
       0,     0,   261,  -610,     0,  -610,  -610,   164,  -610,   269,
       0,   262,   272,   682,     0,   271,   415,   416,    10,  -610,
     683,  -610,     0,     0,    33,     0,     0,     0,  1619,  1620,
    1621,     0,     0,  1005,  1005,  1005,  -610,  -610,     0,     0,
       0,     0,   443,    33,   443,     0,  1032,     0,   164,   164,
     164,  -610,     0,   116,   117,    21,     0,     0,     0,     0,
       0,     0,   684,     0,     0,   206,     0,     0,    26,   269,
     228,    28,   272,   232,     0,  1235,     0,     0,     0,     0,
       0,  1235,     0,   802,   803,  1669,  1670,   120,   890,   891,
     806,     0,  1220,     0,     0,   145,     8,     9,    10,     0,
       0,     0,     0,   685,     0,   269,  1232,     0,  1233,     0,
    1234,     0,     8,     9,   206,   173,    12,    13,     0,     0,
       0,   488,     0,    14,  1483,     0,     0,     0,   100,   114,
     115,     0,   228,   245,     0,    21,   269,    16,     0,    17,
      18,   691,     0,   123,   124,     0,    20,     0,    26,     0,
       0,    28,    29,   232,  1498,    23,     0,   691,     0,     0,
    1504,     0,     0,     0,    26,   831,     0,   134,   135,   232,
       0,     0,  1118,  1118,  1124,   832,  1525,  1526,     0,     0,
       0,   692,  1124,    33,   116,  1692,  1270,   833,   695,     0,
       0,   693,     0,  1235,     0,     0,   162,     0,     0,  1545,
       0,  1235,     0,   694,   695,   860,   860,   863,   863,   518,
       0,     0,     0,   879,     0,     0,     0,   259,     8,   260,
      10,     0,  1770,     0,     0,     0,   232,   475,     0,   269,
       0,   145,     8,     9,    10,   232,     0,    13,     0,     0,
       0,     0,  1567,  1568,     0,     0,     0,     0,    82,   269,
       0,     0,   232,  1235,     0,     0,     0,    21,   109,     0,
      18,   622,  1235,   232,   261,     0,  1613,  1614,   137,  1616,
       0,    21,   228,   262,    29,   150,   150,   691,   150,     0,
      82,   100,   114,   115,    26,     0,     0,    28,    29,    82,
     222,   223,   224,     0,     0,   269,     0,   263,    14,     0,
       0,   831,   210,     0,    82,    33,     0,     0,     0,   206,
       0,   832,     0,   246,     0,    18,     0,     0,   109,    33,
       0,    20,     0,   833,   695,     0,     0,     0,     0,   277,
      23,   109,     0,     0,     0,     0,   370,   116,  1694,   370,
       0,   370,     0,     0,     0,     0,  1045,  1236,     0,     0,
    1236,   270,     0,     0,     0,   109,     0,     0,     0,     0,
       0,  1244,     0,     0,     0,     0,     0,  1032,  1032,  1032,
       0,   414,   131,   132,    10,     0,     0,   206,     0,   206,
     206,     0,   137,  1706,    82,     0,   370,     0,   370,     0,
     150,   150,     0,   859,     0,   436,   150,     0,     0,   150,
     150,   150,   859,     0,     0,     0,   206,     0,     0,   269,
       0,    21,     0,     0,   206,    82,     0,     0,   261,    82,
       0,     0,     0,     0,     0,   210,    82,   262,   272,     0,
       0,     0,   459,   245,   659,   660,   661,   662,   663,   664,
     665,   232,     0,     0,   210,   210,   210,     0,     8,     9,
     232,  1235,  1235,   145,     8,     9,    10,     0,     0,    33,
    1296,  1296,  1124,  1124,  1124,   508,     0,   269,     0,  1305,
       0,  1124,  1124,  1124,   210,     0,    18,     0,   527,     0,
       0,     0,   232,  1323,  1323,  1324,  1007,  1010,     0,     0,
       0,   550,     0,    21,   100,   114,   115,   558,     0,     0,
      26,   109,   162,   134,   135,     0,    26,  1235,     0,    28,
      29,   219,     0,   199,   150,     0,   232,  1320,     0,     0,
       0,     0,  1485,   200,     0,   232,     0,  1321,     0,     0,
       0,  1489,     0,   201,    21,     0,     0,     0,     0,  1322,
       0,    33,     0,     0,     0,   202,   232,     0,   269,     0,
     116,   117,     0,     0,     0,     0,   109,   608,   271,     8,
       9,    10,     0,     0,     0,     0,     0,   269,     0,     0,
       0,   953,   954,   232,   958,   959,   960,   961,   962,   963,
     964,   965,   966,   967,   968,   969,   970,   971,   972,   973,
     974,   975,     0,     0,     0,  1032,  1032,  1032,    21,     0,
       0,   109,     0,     0,   689,     0,   608,     0,     0,   608,
     708,     0,   206,     0,    28,   272,     0,     0,     0,   370,
      82,     0,     0,     0,     0,  1007,  1010,   131,   132,     0,
       0,     0,    13,   271,   415,   416,    10,     0,  1296,  1296,
    1124,  1124,  1124,     0,     0,  1305,    33,   758,   759,   760,
     761,   762,   763,   764,     0,    18,     0,   137,     0,     0,
       0,  1435,  1435,  1324,     0,     0,     0,   109,     0,   210,
     109,     0,   691,    21,     0,   206,   370,     0,   150,    26,
     475,   475,   134,   135,     0,     0,     0,     0,   150,    28,
     272,   150,     0,     0,     0,     0,   692,   269,     0,     0,
       0,     0,     0,   150,     0,     0,   693,   475,     0,     0,
       0,    82,   475,     0,     0,     0,     0,     0,   694,   695,
       0,    33,     0,     0,   271,   131,   132,    10,   269,     0,
       0,     0,     0,     0,     0,     0,     0,   210,   838,   210,
     210,   708,     0,     0,   859,   838,     0,   859,     0,   145,
       8,     9,    10,   210,   210,   254,     0,   210,     0,   210,
     210,   210,   869,   859,    21,     0,   210,     0,     0,  1494,
    1494,   210,  1495,     0,   210,     0,     0,     0,    18,     0,
      28,   272,   269,     0,     0,     0,   370,   872,     0,    21,
     475,   475,   878,   475,   475,   691,   475,     0,     0,     0,
    1237,     0,    26,  1238,     0,    28,    29,     0,     0,     0,
     150,     0,    33,     0,  1245,     0,   131,   132,     0,   831,
    1007,  1010,     0,   904,     0,     0,     0,     0,     0,   832,
     910,     0,  1550,  1550,  1550,     0,     0,    33,     0,     0,
       0,   833,   695,     0,    18,     0,     0,   475,   475,     0,
       0,     0,     0,     0,   923,     0,   370,     0,     0,     0,
       0,   691,   109,   109,   109,   109,     0,   232,    26,     0,
     232,   134,   135,   920,   921,     0,   922,     0,     0,     0,
       0,     0,     0,     0,   370,   692,   232,     0,     0,     0,
       0,     0,   269,     0,   269,   693,     0,     0,     0,     0,
       0,   475,   475,   475,     0,     0,     0,   694,   695,     0,
       0,     0,     0,  1237,  1238,  1007,  1010,     0,     0,     0,
       0,   109,  1245,   608,  1007,  1010,     0,     0,     0,     0,
     714,     8,     9,    10,   689,     0,   608,   608,   708,     0,
       0,     0,     0,     0,     0,   219,   228,     0,     0,  1033,
       0,     0,     0,  1035,     0,     0,     0,     0,   475,   475,
       0,     8,     9,     0,  1019,  1020,   254,   324,   715,     0,
      21,     0,   210,  1019,     0,   145,   131,   132,    10,     0,
       0,    13,     0,    26,     0,   269,   716,   135,   269,    18,
       0,     0,   172,     0,   145,     8,     9,    10,   173,    12,
      13,   518,   859,     0,    18,     0,    14,     0,   859,     0,
       0,     0,   232,    26,     0,    21,   134,   135,     0,   137,
      16,   370,    17,    18,    19,  1278,   137,     0,    26,    20,
    1320,    28,    29,     0,    21,   210,   246,     0,    23,   232,
    1321,   174,   863,   863,   863,    31,     0,    26,  1007,  1010,
      28,    29,  1322,  1356,   228,    32,     0,     0,     0,     0,
       0,     0,     0,    33,    31,     0,     0,    34,     0,     0,
       0,     0,     0,     0,    32,   210,   210,  1126,     0,     0,
       0,     0,    33,  1129,     0,  1126,    34,     0,     0,     0,
      35,  1237,  1238,  1007,  1010,   475,     0,     0,  1245,     0,
       0,     0,  1128,     0,   210,     0,     0,   869,   210,   210,
     869,   869,   869,     0,     0,     0,   210,   145,     8,     9,
      10,     0,     0,   210,     0,   232,     0,     0,     0,     0,
       0,   232,     0,     0,     0,     0,  1392,  1144,     0,     0,
       0,     0,     0,     0,     0,     0,    82,     0,     0,   109,
     370,   370,     0,   370,     0,   109,     0,    21,     0,   259,
     131,   132,    10,     0,   608,   608,   608,     0,     0,     0,
      26,     0,     0,    28,    29,   608,     0,  1654,     0,  1184,
     859,  1186,     0,     0,     0,     0,     0,   200,     0,   859,
       8,     9,     0,     0,     0,   565,     0,   201,     0,    21,
       0,     0,     0,     0,     0,    33,   261,   859,   859,   202,
       0,     0,     0,     0,     0,   262,    29,   269,    18,     0,
       0,  1356,  1237,  1238,     0,  1245,   109,     0,     0,     0,
       0,     0,     0,     0,   145,     8,     9,    10,     0,   263,
      13,     0,    26,   232,     0,   134,   135,    33,     0,   608,
     608,   232,     0,   608,     0,  1222,  1223,     0,  1225,  1320,
     109,     0,     0,    18,   608,     0,   109,     0,     0,  1321,
    1033,  1033,  1033,     0,    21,     0,   608,     0,  1129,     0,
     691,  1322,     0,     0,     0,  1007,  1010,    26,  1246,   269,
      28,    29,     8,     9,   100,   114,   115,    13,   233,   234,
     235,     0,     0,   232,  1121,     0,     0,     0,     0,     0,
       0,     0,   232,   269,  1122,     0,     0,     0,     0,   859,
      18,     0,    33,    18,     0,     0,  1123,   695,     0,   236,
     232,   232,     0,     0,     0,  1516,     0,   109,     0,   109,
     370,     0,     0,     0,    26,     0,     0,   134,   135,     0,
     116,   117,   657,   658,   659,   660,   661,   662,   663,   664,
     665,  1320,   210,   210,   210,   210,   210,  1126,   869,     0,
       0,  1321,   210,     0,  1126,  1126,  1126,     0,   859,   859,
    1129,     0,     0,  1322,     0,   109,   869,   869,   869,     0,
     145,     8,     9,    10,  1304,     0,   565,   259,     8,     9,
      10,     0,   137,     0,     0,   150,    82,     0,    82,     0,
       0,     0,     0,  1358,    82,     0,    82,   655,   656,    18,
     657,   658,   659,   660,   661,   662,   663,   664,   665,   109,
      21,   109,     0,     0,   859,     0,   691,    21,     0,   109,
       0,     0,   232,    26,   261,     0,    28,    29,     0,     0,
       0,     0,     0,   262,    29,     0,     0,     0,     0,     0,
     831,     0,     0,     0,     0,     0,   608,   608,     0,   608,
     832,     0,     0,     0,   370,     0,     0,   263,    33,     0,
     608,     0,   833,   695,     0,    33,     0,   206,   608,   206,
       0,     0,     0,     0,     0,     0,     0,     0,   608,   608,
     708,   232,   232,     0,     0,     0,     0,  1409,     0,   573,
     575,   576,   577,   578,   579,     0,   581,   582,   583,   584,
     585,   586,   587,   588,   589,   590,   591,   592,   593,   594,
     595,   596,   597,   598,   599,   600,   601,   602,     0,   604,
     210,   210,   210,   869,   869,  1430,     0,     0,   210,   210,
       0,     0,  1347,  1348,     9,    10,     0,   232,     0,     0,
       0,     0,     0,     0,   869,   869,   869,   869,   869,  1431,
       0,     0,     0,     0,     0,     0,     0,   109,     0,     0,
       0,  1358,     0,     0,     0,     0,     0,     0,     0,     0,
     109,     0,    21,     0,     0,     0,     0,     0,   206,  1439,
       0,     0,     0,  1454,     0,    26,    85,     0,    28,    29,
       0,    82,  1445,     0,  1349,     0,   111,     0,     0,     0,
       0,     0,   200,     0,     0,   130,   138,     0,   271,   131,
     132,    10,   201,   151,   151,     0,   151,     0,    85,  1461,
      33,     0,     0,  1462,   202,     0,     0,    85,     0,     0,
       0,     0,     0,   714,     8,     9,    10,    18,     0,     0,
     151,     0,    85,     0,     0,     0,     0,     0,    21,     0,
       0,   247,   869,   869,   691,   869,   257,   109,  1484,   869,
       0,    26,     0,     0,    28,   272,     0,     0,     0,   257,
     324,   715,     0,    21,   371,   210,     0,   371,  1254,   371,
     150,     0,     0,    82,     0,     0,    26,     0,  1255,   134,
     135,     0,     0,     0,     0,     0,    33,     0,     0,     0,
    1256,   695,     0,     0,     0,  1510,  1511,     9,    10,     0,
    1527,  1528,     0,     0,     0,   869,   869,  1430,   869,   869,
       0,     0,    85,     0,   371,   109,   371,     0,   151,   151,
     414,     8,   568,    10,   151,     0,     0,   151,   151,   151,
       0,     0,     0,     0,     0,    21,  1551,  1552,     0,     0,
       0,     0,  1554,    85,     0,     0,     0,    85,    26,     0,
       0,    28,    29,   151,    85,     0,     0,  1512,     0,     0,
      21,   109,     0,     0,   869,   200,     0,   261,     0,     0,
       0,     0,   151,   151,   151,   201,   262,   272,     0,     0,
     918,     0,     0,    33,   654,   655,   656,   202,   657,   658,
     659,   660,   661,   662,   663,   664,   665,     0,     0,     0,
     569,     0,   151,   919,     0,     0,     0,     0,    33,     0,
       0,   924,     0,     0,     0,     0,     0,   210,   838,   210,
       0,     0,     0,     0,     0,     0,   271,   131,   132,    10,
       0,  1156,    13,     7,     8,  1157,    10,   173,    12,    13,
       0,     0,   151,     0,     0,    14,     0,     0,     0,     0,
       0,     0,  1668,     0,     0,    18,     0,     0,     0,    16,
       0,    17,    18,    19,     0,     0,    21,     0,    20,  -553,
       0,     0,   691,    21,  1126,     0,     0,    23,  1158,    26,
     174,     0,    28,   272,   257,   610,    26,     0,     0,    28,
      29,     0,     0,  1159,     0,  1160,  1254,     0,     0,     0,
       0,     0,     0,    31,     0,     0,  1255,     0,     0,     0,
       0,     0,     0,    32,    33,  1126,  1126,  1126,  1256,   695,
       0,    33,     0,     0,     0,  1161,     0,     0,   210,   257,
       0,     0,   690,     0,   610,     0,     0,   610,   709,     0,
       0,  -553,     0,   720,     0,     0,     0,   371,    85,     0,
       0,     0,   145,     8,     9,    10,   173,    12,    13,     0,
       0,     0,     0,   720,    14,     0,     0,     0,     0,     0,
       0,   271,     8,     9,    10,     0,     0,    13,    16,     0,
      17,    18,    19,     0,     0,   782,     0,    20,     0,     0,
       0,     0,    21,     0,     0,   257,    23,   151,   257,   174,
      18,     8,     9,     0,   371,    26,   151,     0,    28,    29,
       0,    21,     0,     0,     0,     0,   151,   691,     0,   151,
       0,     0,    31,     0,    26,     0,     0,    28,   272,    18,
       0,   151,    32,     0,     0,     0,     0,     0,     0,    85,
      33,  1299,     0,     0,    34,     0,   691,     0,    35,     0,
       0,  1300,     0,    26,     0,     0,   134,   135,     0,    33,
       0,     0,     0,  1301,   695,   151,   839,   151,   151,   709,
    1491,     0,     0,   839,     0,     0,     0,     0,     0,     0,
    1492,   151,   151,     0,     0,   151,     0,   151,   151,   151,
     610,     0,  1493,   695,   151,     0,     0,     0,     0,   151,
       0,     0,   151,     0,  1156,     0,     7,     8,  1157,    10,
     173,    12,    13,     0,   371,     0,  1188,  1189,    14,     0,
       0,     0,     0,   901,     0,     0,     0,     0,     0,     0,
       0,     0,    16,     0,    17,    18,    19,     0,   151,     0,
       0,    20,  -554,     0,     0,     0,    21,     0,     0,     0,
      23,  1158,     0,   174,     0,     0,     0,     0,     0,    26,
       0,     0,    28,    29,     0,     0,  1159,     0,  1160,     0,
       0,     0,     0,   209,     0,     0,    31,     0,     0,     0,
       0,     0,     0,     0,   371,     0,    32,     0,     0,     0,
     257,   257,   257,   257,    33,     0,     0,   268,  1161,  1156,
     276,     7,     8,  1157,    10,   173,    12,    13,     0,     0,
       0,     0,   371,    14,  -554,   756,   757,   758,   759,   760,
     761,   762,   763,   764,   268,     0,   383,    16,     0,    17,
      18,    19,     0,     0,     0,     0,    20,  -556,     0,     0,
       0,    21,     0,     0,     0,    23,  1158,     0,   174,   257,
       0,   610,     0,     0,    26,     0,     0,    28,    29,     0,
       0,  1159,     0,  1160,   610,   610,   709,     0,     0,     0,
       0,    31,     0,     0,     0,     0,     0,  1034,     0,     0,
       0,    32,     0,     0,     0,     0,     0,     0,     0,    33,
       0,     0,   720,  1161,     0,     0,   209,     0,     0,     0,
     151,     0,     0,     0,     0,     0,     0,     0,     0,  -556,
       0,     0,     0,     0,     0,   209,   209,   209,     0,     0,
       0,     0,     0,     0,     0,   526,     0,     0,     0,     6,
       0,     7,     8,     9,    10,    11,    12,    13,     0,     0,
       0,     0,     0,    14,     0,   209,     0,   782,     0,   371,
       0,     0,     0,     0,     0,   130,    15,    16,     0,    17,
      18,    19,     0,   151,   247,     0,    20,     0,     0,     0,
       0,    21,   276,     0,    22,    23,    24,     0,    25,     0,
       0,     0,     0,     0,    26,    27,     0,    28,    29,     0,
       0,    30,   268,     0,     0,     0,     0,   131,   132,     0,
       0,    31,   254,   151,   151,   839,     0,   414,   131,   132,
      10,    32,     0,  1136,     0,     0,     0,     0,     0,    33,
       0,     0,     0,    34,     0,    18,     0,    35,     0,     0,
       0,     0,   151,     0,     0,   610,   151,   151,   610,   610,
     610,     0,   691,     0,   151,     0,     0,    21,     0,    26,
       0,   151,   134,   135,   261,     0,     0,     0,     0,     0,
       0,     0,     0,   262,   272,     0,   692,   145,   131,   132,
      10,     0,     0,   254,    85,     0,   693,   257,   371,   371,
       0,   371,     0,   257,     0,   268,   276,   569,   694,   695,
       0,     0,   610,   610,   610,    33,    18,     0,     0,     0,
       0,     0,     0,   610,     0,   268,   276,    21,     0,     0,
       0,  1156,     0,     7,     8,  1157,    10,   173,    12,    13,
      26,     0,     0,    28,    29,    14,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    31,     0,    16,
     209,    17,    18,    19,     0,     0,     0,    32,    20,  -555,
       0,     0,     0,    21,   257,    33,     0,    23,  1158,    34,
     174,     0,     0,     0,     0,     0,    26,     0,     0,    28,
      29,     0,     0,  1159,     0,  1160,     0,   610,   610,     0,
       0,   610,     0,    31,     0,     0,     0,     0,   257,     0,
       0,     0,   610,    32,   257,     0,     0,     0,  1034,  1034,
    1034,    33,     0,     0,   610,  1161,   720,     0,   209,     0,
     209,   209,     0,     0,     0,     0,     0,   145,     8,     9,
      10,  -555,     0,     0,   209,   209,     0,     0,   209,     0,
     209,   209,   209,   209,     0,     0,     0,   209,     0,     0,
       0,     0,   209,     0,     0,   209,    18,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    21,     0,     0,
       0,     0,     0,   691,     0,   257,     0,   257,   371,     0,
      26,     0,     0,    28,    29,     0,     0,     0,     0,     0,
       0,     0,     0,   131,   132,   901,     0,   831,   565,     0,
     151,   151,   151,   151,   151,   839,   610,   832,     0,     0,
     151,     0,  1136,  1136,  1136,    33,     0,     0,   720,   833,
     695,    18,     0,   257,   610,   610,   610,     0,  1316,     0,
       0,     8,     9,     0,     0,    12,    13,   901,   691,     0,
     138,     0,    14,   151,    85,    26,    85,     0,   134,   135,
       0,  1359,    85,     0,    85,     0,    16,     0,    17,    18,
       0,     0,   692,     0,     0,    20,     0,   257,     0,   257,
       0,     0,   693,     0,    23,     0,     0,   257,     0,     0,
       0,     0,     0,    26,   694,   695,   134,   135,   749,   750,
     751,   752,   753,   754,   755,   756,   757,   758,   759,   760,
     761,   762,   763,   764,   610,   610,     0,   610,     0,     0,
       0,     0,   371,     0,     0,     0,     0,     0,   610,   145,
       8,     9,    10,   173,    12,    13,   610,     0,     0,   488,
       0,    14,     0,   268,   276,     0,   610,   610,   709,     0,
       0,     0,     0,     0,     0,    16,     0,    17,    18,     0,
       0,     0,     0,   209,    20,     0,     0,     0,     0,    21,
       0,     0,     0,    23,     0,   691,     0,     0,     0,     0,
       0,     0,    26,     0,     0,    28,    29,     0,   151,   151,
     151,   610,   610,   709,     0,     0,   151,   151,     0,  1121,
       0,   271,     8,     9,    10,     0,     0,     0,     0,  1122,
       0,     0,   610,   610,   610,   610,   610,    33,     0,     0,
     901,  1123,   695,     0,     0,   257,   209,     0,     0,  1359,
      18,     0,     0,     0,     0,     0,     0,     0,   257,     0,
       0,    21,     0,     0,     0,     0,     0,   691,     0,     0,
       0,     0,     0,     0,    26,     0,    54,    28,   272,    85,
       0,     0,     0,     0,     0,     0,   209,   209,  1125,     0,
       0,  1299,     0,   268,   276,     0,  1125,     8,     9,     0,
       0,  1300,   254,    54,    54,     0,   158,     0,    54,    33,
       0,     0,     0,  1301,   695,   209,     0,    54,   209,   209,
     209,   209,   209,   209,   526,    18,     0,   209,     0,     0,
      54,     0,    54,     0,   209,   901,     0,     0,     0,     0,
     610,   610,   691,   610,     0,   257,     0,   610,     0,    26,
       0,     0,   134,   135,   265,     0,   276,   273,     0,     0,
       0,     0,     0,   151,     0,     0,  1491,     0,   151,     0,
       0,    85,   653,   654,   655,   656,  1492,   657,   658,   659,
     660,   661,   662,   663,   664,   665,     0,     0,  1493,   695,
       0,     0,     0,     0,     0,   414,     8,     9,    10,   414,
       8,     9,    10,   610,   610,   709,   610,   610,     0,   417,
     417,     0,    54,   257,     0,     0,     0,     0,    54,    54,
       0,     0,   265,   273,    54,     0,     0,   158,   158,   158,
       0,     0,     0,     0,   456,    21,     0,     0,     0,    21,
       0,     0,   261,    54,     0,     0,   261,    54,     0,     0,
       0,   262,   272,    54,    54,   262,   272,     0,     0,   257,
       0,     0,   610,  1156,     0,     7,     8,  1157,    10,   173,
      12,    13,    54,    54,   158,   263,     0,    14,     0,   569,
       0,     0,   265,    33,     0,     0,     0,    33,   268,   276,
     268,    16,     0,    17,    18,    19,     0,     0,     0,     0,
      20,     0,    54,     0,  1647,    21,     0,     0,     0,    23,
    1158,     0,   174,     0,     0,   151,   839,   151,    26,     0,
       0,    28,    29,     0,     0,  1159,     0,  1160,     0,     0,
       0,     0,     0,     0,     0,    31,     0,     0,     0,     0,
       0,     0,    54,     0,     0,    32,     0,     0,     0,   265,
       0,     0,     0,    33,     0,     0,     0,  1161,     0,     0,
       0,   414,   131,  1520,    10,     0,     0,     0,     0,     0,
       0,     0,  1136,   209,   209,   209,   209,   209,  1125,   209,
       0,  1303,     0,   209,   268,  1125,  1125,  1125,     0,     0,
       0,   276,     0,     0,     0,     8,     9,   209,   209,   209,
     565,    21,     0,     0,     0,     0,     0,     0,   261,     0,
       0,     0,     0,  1136,  1136,  1136,   632,   262,   272,     0,
       0,     0,     0,    18,   209,     0,   151,     0,     0,     0,
       0,     0,   417,     0,     0,     0,     0,     0,     0,     0,
     691,   569,   265,     0,     0,     0,     0,    26,    54,    33,
     134,   135,     6,     0,     7,     8,     9,    10,    11,    12,
      13,     0,   265,     0,  1491,     0,    14,     0,     0,     0,
       0,     0,     0,     0,  1492,     0,     0,     0,     0,     0,
      16,     0,    17,    18,     0,   417,  1493,   695,     0,    20,
       0,     0,     0,     0,    21,     0,     0,    54,    23,     0,
       0,   463,     0,     0,     0,     0,    54,    26,   265,     0,
      28,    29,     0,     0,    30,   456,    54,     0,     0,    54,
       0,     0,     0,     0,    31,   456,   456,   456,     0,     0,
       0,    54,     0,     0,    32,     0,     0,     0,     0,    54,
       0,     0,    33,     0,     0,     0,    34,     0,     0,     0,
       0,   209,   209,   209,   209,   209,  1125,     0,     0,   209,
     209,     0,     0,     0,     0,    54,    54,    54,    54,     0,
       0,     0,     0,    54,     0,   209,   209,   209,   209,   209,
       0,    54,    54,     0,     0,    54,     0,   158,   158,   158,
     456,     0,   209,     0,    54,     0,     0,     0,     0,    54,
       0,     0,    54,     0,     0,   649,   650,   651,   652,   653,
     654,   655,   656,   526,   657,   658,   659,   660,   661,   662,
     663,   664,   665,     0,     0,   271,     8,     9,    10,     0,
      12,   315,   316,   317,   318,     0,   319,    14,    54,     0,
     145,     8,     9,    10,     0,     0,     0,     0,     0,     0,
       0,    16,   320,    17,    18,    19,     0,   321,   322,   323,
      20,     0,   324,   325,   326,    21,   327,   328,     0,    23,
       0,   691,     0,   329,   330,   331,   332,   333,    26,     0,
      21,    28,   272,   209,   209,  1303,   209,     0,     0,     0,
     209,     0,   336,    26,     0,  1026,    28,    29,     0,     0,
     632,   632,   632,   338,   339,  1027,   209,     0,     0,     0,
     200,   341,   342,   343,     0,   632,     0,  1028,   695,     0,
     201,     0,     0,     0,     0,     0,     0,     0,    33,     0,
       0,     0,   202,     0,   345,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   209,   209,  1125,   209,
     209,   278,     0,     0,     8,     9,     0,     0,    12,    13,
       0,   265,     0,     0,     0,    14,     0,     0,     0,     0,
       0,     0,     0,   632,     0,   632,     0,   632,     0,    16,
       0,    17,    18,     0,     0,     0,     0,     0,    20,     0,
     279,   280,     0,     0,     0,     0,     0,    23,     0,   281,
      54,     0,     0,     0,     0,   209,    26,     0,     0,   134,
     135,     0,   282,     0,     0,     0,   283,   284,   285,   286,
     287,   288,   289,   290,   291,   292,   293,   294,   295,   296,
     297,   298,   299,   300,   301,   302,   303,     0,     0,   304,
     305,   306,     0,   307,     0,     0,   308,   417,     0,     0,
       0,     0,     0,     0,   417,     0,     0,     0,   209,     0,
     209,     0,   309,    54,     0,     0,     0,     0,     0,     0,
       0,     0,   271,     8,     9,    10,   173,    12,    13,     0,
       0,     0,   488,     0,    14,     0,     0,     0,     0,     0,
       0,     0,    80,     0,     0,     0,     0,     0,    16,     0,
      17,    18,     0,    54,    54,   158,     0,    20,     0,     0,
     265,   273,    21,  1133,     0,  1125,    23,     0,   691,    80,
      80,     0,    80,     0,    80,    26,     0,   632,    28,   272,
       0,     0,    54,    80,     0,   456,    54,    54,   456,   456,
     456,     0,  1254,     0,    54,     0,    80,     0,    80,     0,
       0,    54,  1255,     0,     0,     0,  1125,  1125,  1125,     0,
      33,     0,     0,     0,  1256,   695,     0,     0,     0,   209,
       0,     0,     0,   275,    54,   511,   514,     0,     0,     0,
     271,     8,     9,    10,   173,    12,    13,     0,     0,     0,
     488,     0,    14,   752,   753,   754,   755,   756,   757,   758,
     759,   760,   761,   762,   763,   764,    16,     0,    17,    18,
       0,     0,     0,     0,     0,    20,     0,     0,     0,     0,
      21,     0,     0,     0,    23,     0,   691,     0,    80,     0,
       0,     0,     0,    26,    80,    80,    28,   272,     0,   275,
      80,     0,     0,    80,    80,    80,     0,     0,     0,     0,
    1299,     0,     0,     0,     0,     0,     0,     0,     0,    80,
    1300,     0,     0,    80,     0,     0,     0,     0,    33,    80,
      80,     0,  1301,   695,   145,   131,   132,    10,     0,     0,
    -416,     8,     9,  -416,  -416,    12,   254,     0,    80,    80,
      80,     0,    14,     0,     0,     0,     0,     0,   632,   632,
     632,     0,     0,    18,   456,   265,    16,     0,    17,    18,
       0,     0,     0,     0,    21,    20,     0,     0,    80,     0,
    -416,     0,     0,     0,    23,     0,   691,    26,     0,     0,
      28,    29,     0,    26,     0,     0,   134,   135,     0,     0,
       0,     0,     0,     0,   155,     0,     0,     0,     0,     0,
     692,     0,     0,     0,   156,     0,     0,     0,    80,     0,
     693,     0,    33,     0,     0,     0,   157,     0,  -416,     0,
       0,     0,   694,   695,   651,   652,   653,   654,   655,   656,
       0,   657,   658,   659,   660,   661,   662,   663,   664,   665,
      54,    54,    54,   158,   158,   158,   456,     0,   265,     0,
      54,   265,  1133,  1133,  1133,     0,     0,     0,   273,     0,
       0,     0,     0,     0,     0,     0,   145,     8,     9,    10,
     222,   223,   224,     0,     0,     0,     8,     9,    14,     0,
       0,    13,     0,   158,    54,     0,    54,     0,     0,     0,
       0,    54,    54,     0,    54,    18,     0,     0,     0,     0,
       0,    20,     0,     0,    18,     0,    21,     0,     0,   719,
      23,     0,   691,     0,    80,     0,     0,     0,     0,    26,
       0,   691,    28,    29,     0,     0,     0,     0,    26,   719,
       0,   134,   135,     0,     0,   861,   831,     0,   862,     0,
     511,   514,     0,     0,     0,  1491,   832,     0,     0,     0,
       0,     0,   880,     0,    33,  1492,     0,     0,   841,   695,
       0,   353,     0,    80,   353,     0,   353,  1493,   695,     0,
       0,     0,    80,     0,     0,     0,   456,   456,   456,     0,
       0,     0,    80,     0,   165,    80,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    80,     0,     0,
       0,     0,     0,     0,     0,    80,     0,     0,   211,     0,
       0,   353,     0,   353,     0,     0,     0,     0,    54,    54,
      54,   456,   456,   456,     0,     0,    54,    54,     0,     0,
       0,    80,    80,    80,    80,     0,     0,     0,     0,    80,
       0,     0,     0,     0,     0,     0,     0,    80,    80,     0,
       0,    80,     0,    80,    80,    80,     0,     0,     0,    54,
      80,     0,     0,     0,     0,    80,     0,     0,    80,     0,
       0,     0,     0,   145,     8,     9,    10,   222,   223,   224,
     265,   273,     0,     0,     0,    14,     0,     0,     0,    54,
     753,   754,   755,   756,   757,   758,   759,   760,   761,   762,
     763,   764,    18,     0,    80,   165,   165,   165,    20,     0,
       0,     0,     0,    21,     0,     0,     0,    23,     0,   691,
       0,     0,     0,     0,     0,     0,    26,     0,     0,    28,
      29,   211,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   831,     0,     0,     0,     0,     0,     0,
     211,   211,   520,   832,     0,     0,     0,     0,     0,     0,
       0,    33,     0,     0,     0,   833,   695,   145,   131,   132,
      10,     0,     0,    54,     0,     0,   265,     0,    54,     0,
     211,    54,   145,     8,     9,    10,   212,    12,   213,     0,
     614,   615,     0,     0,    14,     0,    18,     0,     0,     0,
       0,     0,     0,     0,   353,     0,   624,    21,    16,   625,
      17,    18,   626,     0,     0,   636,     0,    20,     0,   641,
      26,     0,    21,    28,    29,     0,    23,   681,   719,     0,
       0,     0,     0,     0,     0,    26,     0,    31,    28,    29,
       0,     0,   214,     0,   353,     0,     0,    32,     0,     0,
       0,     0,    31,     0,     0,    33,   511,   514,     0,    34,
       0,     0,    32,   609,     0,     0,    80,     0,     8,     9,
      33,   173,    12,    13,    34,     0,     0,   488,     0,    14,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   861,
     862,   511,   514,    16,     0,    17,    18,   880,     0,     0,
       0,   353,    20,     0,     0,     0,     0,     0,     0,     0,
       0,    23,   698,   691,     0,   698,   698,     0,     0,     0,
      26,     0,     0,   134,   135,    54,    54,    54,     0,    80,
       0,     0,     0,     0,     0,     0,     0,  1491,     0,     0,
       8,     9,     0,     0,    12,   254,     0,  1492,     0,     0,
       0,    14,     0,     0,     0,     0,     0,     0,     0,  1493,
     695,     0,     0,     0,     0,    16,     0,    17,    18,    80,
      80,    80,     0,     0,    20,   211,     0,   275,     0,  1135,
       0,     0,  1133,    23,     0,   691,     0,     0,     0,     0,
       0,     0,    26,     0,     0,   134,   135,     0,    80,     0,
       0,     0,    80,    80,     0,     0,     0,     0,     0,   692,
      80,   353,     0,     0,     0,     0,     0,    80,     0,   693,
       0,     0,     0,  1133,  1133,  1133,     0,     0,     0,     0,
       0,   694,   695,     0,     0,     0,    54,     0,     0,     0,
      80,     0,     0,   835,     0,   835,   835,   698,     0,     0,
       0,     8,     9,     0,     0,    12,    13,     0,     0,   211,
     211,     0,    14,   211,     0,   520,   520,   520,   870,     0,
       0,     0,   211,     0,     0,     0,    16,   211,    17,    18,
     211,   353,     0,     0,     0,    20,     0,     0,     0,     0,
       0,     0,   491,     0,    23,     0,     0,   624,   625,     0,
       0,     0,     0,    26,     0,     0,   134,   135,   675,   353,
       0,     0,     0,     0,   353,   353,     0,   353,   353,   353,
     353,   353,   353,   353,   353,   353,   353,   353,   353,   353,
     353,   353,   353,   353,   353,     0,     0,     0,     0,     0,
       0,     0,   676,     0,   861,   862,   511,   514,     0,     0,
       0,     0,     0,   880,     0,   511,   514,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   861,   862,   880,
       0,     0,   719,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   145,     8,     9,    10,   173,    12,    13,
       0,     0,     0,   847,     0,    14,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    16,
       0,    17,    18,     0,     0,     0,     0,     0,    20,     0,
       0,     0,     0,    21,     0,     0,     0,    23,     0,   991,
       0,     0,     0,     0,     0,     0,    26,     0,     0,    28,
      29,     0,   698,   698,   698,     0,   353,     0,     0,     0,
       0,     0,     0,    31,     0,   698,    80,    80,    80,    80,
      80,    80,     0,    32,     0,     0,    80,     0,  1135,  1135,
    1135,    33,     0,     0,  1310,    34,     0,     0,   211,     0,
     739,   747,   748,   749,   750,   751,   752,   753,   754,   755,
     756,   757,   758,   759,   760,   761,   762,   763,   764,    80,
      80,     0,    80,     0,     0,     0,     0,    80,    80,     0,
      80,     0,     0,     0,   145,     8,     9,    10,   212,    12,
     213,     0,   861,   862,   511,   514,    14,     0,     0,   880,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      16,   835,    17,    18,     0,   511,   514,     0,     0,    20,
       0,     0,     0,     0,    21,     0,     0,     0,    23,     0,
       0,     0,     0,     0,     0,     0,     0,    26,     0,     0,
      28,    29,     0,     0,  1657,   353,   353,     0,   353,   823,
     491,   835,   835,  1127,    31,     0,     0,     0,     0,     0,
       0,  1127,     0,     0,    32,     0,     0,     0,     0,     0,
       0,   389,    33,     0,     0,     0,    34,     0,     0,     0,
     211,     0,     0,   870,   211,   211,   870,   870,   870,     0,
       0,     0,   211,     0,     0,     0,     0,     0,     0,   211,
       0,     0,     0,     0,    80,    80,    80,     0,     0,     0,
       0,     0,    80,    80,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   861,   862,     0,   880,     0,     0,     0,
       0,     0,     0,  1227,     0,     0,  1510,   131,   132,    10,
     609,   609,   609,     0,     0,    80,     0,     0,     0,     0,
       0,   698,     0,     0,     0,   492,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   624,   625,   275,     0,     0,
       0,     0,     0,     0,     0,    80,    21,     0,     0,   491,
     534,     0,   927,     0,     0,     0,   511,   514,     0,    26,
       0,     0,    28,    29,     0,     0,     0,     0,  1512,     0,
       0,     0,     0,     0,     0,     0,    31,     0,   823,     0,
       0,     0,     0,     0,     0,     0,    32,     0,     0,     0,
       0,     0,     0,     0,    33,   698,   698,     0,    34,   698,
       0,     0,     0,   491,     0,   353,     0,     0,   353,   491,
     698,   491,   491,     0,     0,     0,   698,   698,   698,     8,
       9,     0,   698,    12,   254,     0,     0,     0,     0,    80,
      14,     0,     0,     0,    80,     0,     0,    80,     0,   624,
     625,   491,     0,     0,    16,     0,    17,    18,   491,     0,
       0,     0,     0,    20,     0,     0,     0,     0,   491,     0,
       0,     0,    23,     0,     0,     0,     0,     0,     0,     0,
       0,    26,     0,   635,   134,   135,     0,  1053,  1055,  1056,
    1057,     0,  1059,  1060,  1061,  1062,  1063,  1064,  1065,  1066,
    1067,  1068,  1069,  1070,  1071,  1072,  1073,  1074,  1075,  1076,
    1077,     0,     0,     0,     0,     0,     0,     0,   835,   835,
     835,  1127,  1127,  1127,  1302,     0,     0,     0,   835,   353,
    1127,  1127,  1127,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   870,   870,   870,     0,     0,  1403,     0,   353,
       0,     0,     0,     0,  1347,     8,  1157,    10,   212,    12,
     213,   165,   790,     0,     0,     0,    14,     0,   823,   211,
       0,     0,     0,     0,   131,   132,   511,   514,   223,   224,
      16,     0,    17,    18,     0,    14,     0,   491,     0,    20,
       0,    80,    80,    80,    21,     0,     0,     0,    23,     0,
       0,   491,    18,     0,     0,     0,     0,    26,    20,     0,
      28,    29,     0,     0,     0,     0,  1349,    23,     0,   691,
       0,     0,   991,   991,    31,   991,    26,     0,     0,   134,
     135,     0,     0,    18,    32,     0,   698,     0,     0,     0,
     790,     0,    33,   692,   698,     0,  1161,     0,  1135,     0,
       0,     0,     0,   693,   698,   698,   698,     0,     0,     0,
       0,     0,     0,     0,     0,   705,   695,   743,   744,   745,
     746,   747,   748,   749,   750,   751,   752,   753,   754,   755,
     756,   757,   758,   759,   760,   761,   762,   763,   764,  1135,
    1135,  1135,     0,     0,  1205,     0,   835,   835,   835,  1302,
    1302,  1302,    80,     0,   835,   835,     0,     0,     0,   145,
     131,   132,    10,     0,     0,    13,     0,     0,     0,     0,
     870,   870,   870,   870,   870,     0,     0,     0,     0,     0,
       0,   823,   491,     0,     0,     0,     0,   211,    18,     0,
       0,     0,     0,     0,     0,     0,   491,     0,   491,    21,
     491,     0,     0,     0,     0,     0,   929,   930,   932,   933,
     934,     0,    26,     0,     0,    28,    29,     0,     0,   635,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   155,
       0,     0,   952,     0,     0,     0,   107,     0,     0,   156,
       0,     0,     0,  1263,     0,   125,   107,    33,     0,     0,
       0,   157,     0,   107,   107,     0,   107,     0,     0,   145,
       8,     9,    10,     0,     0,   981,   145,     8,     9,    10,
       0,     0,    13,     0,     0,     0,   491,     0,  1302,  1302,
       0,  1302,     0,  1011,     0,   870,     0,     0,    18,     0,
    1024,   243,  1025,     0,  1011,    18,     0,     0,     0,    21,
       0,   211,     0,     0,     0,     0,    21,     0,     0,     0,
       0,     0,    26,     0,     0,    28,    29,     0,     0,    26,
       0,     0,    28,    29,     0,     0,     0,     0,     0,   515,
       0,     0,     0,     0,   823,   823,   200,     0,     0,   516,
       0,  1302,  1302,  1302,  1302,  1302,   201,    33,     0,     0,
     409,   517,   125,     0,    33,     0,  1334,     0,   202,   107,
     107,     0,     0,     0,     0,   636,     0,     0,   107,   107,
       0,     0,   107,   107,   107,     0,   441,   107,   107,   107,
       0,     0,     0,     0,   145,     8,     9,    10,   173,    12,
      13,     0,     0,     0,     0,     0,    14,     0,     0,     0,
    1302,     0,   823,   823,     0,   696,     0,     0,   696,   696,
      16,     0,    17,    18,     0,     0,     0,     0,     0,    20,
       0,     0,  1011,     0,    21,     0,     0,     0,    23,     0,
    1011,     0,     0,     0,     0,     0,     0,    26,     0,     0,
      28,    29,     0,     0,     0,   145,     8,     9,    10,   222,
     223,   224,     0,   211,    31,   211,     0,    14,     0,     0,
       0,     0,  1415,     0,    32,     0,     0,     0,   243,   107,
     624,   625,    33,     0,    18,     0,    34,     0,     0,     0,
      20,     0,     0,     0,     0,    21,     0,     0,     0,    23,
     823,   691,   107,     0,   492,     0,     0,     0,    26,     0,
     492,    28,    29,     0,     0,     0,     0,     0,     0,     0,
     520,     0,     0,     0,     0,   200,     0,     0,     0,     0,
       0,   823,     0,     0,     0,   201,     0,     0,     0,     0,
       0,     0,     0,    33,     0,   107,   696,  1660,   696,   696,
     696,     0,     0,     0,     0,  1449,     0,     0,     0,     0,
       0,   520,   520,   520,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   211,     0,   652,   653,   654,   655,
     656,  1217,   657,   658,   659,   660,   661,   662,   663,   664,
     665,     0,   107,   823,   107,     0,     0,   107,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   145,     8,     9,
      10,   212,    12,   213,     0,   952,     0,     0,     0,    14,
       0,   492,   491,     0,     0,     0,     0,  1011,     0,     0,
       0,   491,     0,    16,     0,    17,    18,     0,     0,     0,
       0,     0,    20,   823,     0,   107,     0,    21,     0,     0,
       0,    23,     0,  1506,  1507,     0,     0,     0,     0,     0,
      26,     0,     0,    28,    29,     0,   107,     0,   107,   131,
     132,     0,     0,   223,   224,     0,   107,    31,     0,   107,
      14,     0,     0,   823,     0,     0,     0,    32,     0,     0,
       0,   107,   790,     0,  1276,    33,     0,    18,     0,    34,
       0,     0,     0,    20,     0,     0,     0,     0,     0,     0,
       0,     0,    23,     0,   691,     0,     0,     0,  1560,     0,
       0,    26,  1011,     0,   134,   135,     0,     0,     0,     0,
       0,  1011,     0,     0,     0,     0,     0,     0,   692,     0,
    1317,     0,     0,     0,     0,   696,   696,   696,   693,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  1030,     0,
     694,   695,     0,     0,  1617,  1618,   145,   131,   132,    10,
       0,     0,   565,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   243,   894,   492,     0,   492,     0,     0,     0,
       0,  1636,     0,     0,  1381,    18,     0,     0,   107,   650,
     651,   652,   653,   654,   655,   656,    21,   657,   658,   659,
     660,   661,   662,   663,   664,   665,     0,     0,     0,    26,
       0,     0,    28,    29,     0,     0,     0,     0,     0,  1674,
       0,     0,     0,     0,     0,     0,    31,     0,     0,     0,
     107,     0,   107,     0,   696,     0,    32,     0,   145,     8,
       9,    10,     0,     0,    33,  1011,     0,     0,    34,     0,
       0,     0,     0,     0,     0,     0,   491,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    18,     0,     0,
       0,     0,     0,     0,   696,   696,   696,     0,    21,     0,
       0,  1724,     0,     0,  1030,     0,     0,     0,     0,     0,
    1011,    26,     0,     0,    28,    29,     0,     0,     0,     0,
       0,   107,     0,     0,     0,     0,     0,     0,   200,     0,
       0,   107,   107,     0,   107,   107,     0,     0,   201,     0,
       0,     0,   492,     0,     0,     0,    33,     0,     0,     0,
     202,   145,     8,     9,    10,   492,    12,   315,   316,   317,
     318,     0,   319,    14,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    16,   320,    17,
      18,    19,     0,   321,   322,   323,    20,     0,   324,   325,
     326,    21,   327,   328,   696,    23,     0,   691,     0,   329,
     330,   331,   332,   333,    26,     0,     0,    28,    29,     0,
       0,     0,   823,     0,     0,     0,     0,   107,   336,     0,
       0,  1130,     0,     0,   107,   125,     0,     0,     0,   338,
     339,  1131,     0,     0,   243,     0,     0,   341,   342,   343,
       0,     0,  1317,  1132,   695,     0,     0,   145,     8,     9,
      10,     0,     0,   254,     0,     0,   145,     8,     9,    10,
     345,     0,    13,     0,     0,     0,     0,     0,   696,   696,
       0,     0,   696,     0,     0,     0,    18,     0,     0,     0,
       0,     0,     0,   696,     0,    18,     0,    21,     0,  1030,
    1030,  1030,     0,     0,     0,   696,    21,     0,     0,     0,
      26,     0,  1011,    28,    29,     0,     0,     0,     0,    26,
     492,     0,    28,    29,     0,     0,     0,   200,   145,     8,
       9,    10,     0,     0,   565,     0,   515,   201,     0,     0,
       0,     0,     0,     0,     0,    33,   516,     0,     0,   202,
       0,     0,     0,   894,    33,     0,     0,    18,   517,     0,
       0,     0,     0,     0,     0,     0,   790,     0,    21,     0,
       0,     0,   107,   107,   107,   107,     0,     0,     0,     0,
       0,    26,     0,   107,    28,    29,     0,     0,     0,     0,
       0,   696,   696,   696,   696,   696,   696,   696,   200,     0,
       0,   696,     0,  1030,  1030,  1030,     0,     0,   201,   271,
       8,     9,    10,     0,     0,    13,    33,     0,     0,     0,
     202,     0,     0,     0,   271,     8,     9,    10,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    18,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    21,
       0,     0,     0,    18,     0,     0,     0,   107,   107,     0,
       0,   107,    26,     0,    21,    28,   272,   145,   131,  1335,
      10,     0,   107,     0,     0,     0,     0,    26,     0,   866,
      28,   272,     0,     0,   107,     0,     0,     0,     0,   867,
       0,     0,     0,     0,   866,     0,    18,    33,     0,     0,
       0,   868,     0,     0,   867,     0,     0,    21,     0,   696,
       0,     0,    33,     0,     0,     0,   868,   696,     0,     0,
      26,     0,   635,    28,    29,     0,     0,   696,   696,   696,
    1685,     0,     0,     0,     0,     0,     0,   155,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   156,     0,     0,
       0,     0,     0,     0,     0,    33,     0,     0,     0,   157,
       0,     0,     0,     0,     0,   894,     0,     0,     0,   696,
     696,   696,   696,   696,   696,     0,     0,   696,   696,     0,
       0,     0,  1686,   743,   744,   745,   746,   747,   748,   749,
     750,   751,   752,   753,   754,   755,   756,   757,   758,   759,
     760,   761,   762,   763,   764,     0,     0,   894,     0,     0,
     107,     8,     9,   107,   173,    12,    13,     0,     0,     0,
       0,     0,    14,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    16,     0,    17,    18,
       0,     0,     0,     0,     0,    20,     0,     0,     0,     0,
       0,     0,     0,     0,   783,     0,     0,   784,     0,     0,
       0,     0,     0,    26,     0,     0,   134,   135,     0,     0,
       0,     0,     0,     0,   107,   107,     0,   107,     0,     0,
       0,     0,     0,     0,     0,     0,     8,     9,   107,   173,
      12,    13,     0,     0,     0,   488,   107,    14,     0,     0,
       0,   696,   696,     0,   696,     0,   107,   107,     0,     0,
       0,    16,     0,    17,    18,     0,     0,     0,     0,     0,
      20,     0,     0,     0,     0,     0,     0,     0,     0,    23,
       0,     0,     0,     0,     0,     0,     0,     0,    26,     0,
       0,   134,   135,   748,   749,   750,   751,   752,   753,   754,
     755,   756,   757,   758,   759,   760,   761,   762,   763,   764,
       0,     0,     0,     0,   696,   696,   696,   696,   696,     0,
    1622,     0,  -510,  -510,  -510,  -510,  -510,  -510,  -510,     0,
     894,     0,  -510,     0,  -510,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  -510,     0,  -510,     0,     0,
       0,  -510,     0,     0,     0,     0,     0,  -510,     0,     0,
       0,   107,  -510,     0,     0,     0,  -510,     0,  -510,     0,
       0,     0,     0,   696,     0,  -510,     0,     0,  -510,  -510,
    -510,  -510,  -510,     0,  -510,  -510,  -510,  -510,  -510,  -510,
    -510,  -510,  -510,  -510,  -510,  -510,  -510,  -510,  -510,  -510,
    -510,  -510,  -510,  -510,  -510,  -510,  -510,     0,  -510,  -510,
    -510,     0,  -510,  -510,  -510,  -510,  -510,     0,     0,     0,
       0,     0,  1623,  -510,     0,   894,     0,     0,  -510,  -510,
    -510,     0,  -510,  1745,   743,   744,   745,   746,   747,   748,
     749,   750,   751,   752,   753,   754,   755,   756,   757,   758,
     759,   760,   761,   762,   763,   764,   107,  1573,   107,  -927,
    -927,  -927,  -927,  -927,  -927,  -927,  -927,  -927,  -927,     0,
    -927,  -927,  -927,     0,  -927,  -927,  -927,  -927,  -927,  -927,
    -927,  -927,  -927,  -927,  -927,  -927,  -927,  -927,  -927,  -927,
       0,  -927,  -927,  -927,  -927,     0,  -927,  -927,  -927,  -927,
    -927,  -927,  -927,  -927,  -927,     0,     0,  -927,  -927,  -927,
    -927,  -927,  -927,     0,     0,  -927,  -927,  -927,     0,  -927,
    -927,     0,     0,     0,     0,     0,  -927,     0,     0,  -927,
       0,     0,     0,     0,     0,     0,     0,  -927,  -927,  -927,
       0,     0,     0,     0,     0,  -927,  -927,  -927,     0,     0,
       0,  -927,     0,  -927,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,  1574,  -927,  1535,
       0,  -927,  -927,  -927,  -927,  -927,  -927,  -927,  -927,  -927,
    -927,     0,  -927,  -927,  -927,     0,  -927,  -927,  -927,  -927,
    -927,  -927,  -927,  -927,  -927,  -927,  -927,  -927,  -927,  -927,
    -927,  -927,     0,  -927,  -927,  -927,  -927,     0,  -927,  -927,
    -927,  -927,  -927,  -927,  -927,  -927,  -927,     0,     0,  -927,
    -927,  -927,  -927,  -927,  -927,     0,     0,  -927,  -927,  -927,
       0,  -927,  -927,     0,     0,     0,     0,     0,  -927,     0,
       0,  -927,     0,     0,     0,     0,     0,     0,     0,  -927,
    -927,  -927,     0,     0,     0,     0,     0,  -927,  -927,  -927,
       0,     0,     0,  -927,   627,  -927,   271,     8,     9,    10,
     173,    12,   315,   316,   317,   318,   488,   319,    14,     0,
    -927,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    16,   320,    17,    18,    19,     0,   321,   322,
     323,    20,     0,   324,   325,   326,    21,   327,   328,     0,
      23,     0,   691,     0,   329,   330,   331,   332,   333,    26,
       0,     0,    28,   272,  -344,     0,     0,   384,     0,     0,
       0,     0,     0,   336,     0,     0,  1026,     0,     0,     0,
       0,     0,     0,     0,   338,   339,  1027,     0,     0,     0,
       0,     0,   341,   342,   343,     0,     0,     0,  1028,   695,
     627,     0,   145,     8,     9,    10,   173,    12,   315,   316,
     317,   318,   488,   319,    14,   345,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    16,   320,
      17,    18,    19,     0,   321,   322,   323,    20,     0,   324,
     325,   326,    21,   327,   328,     0,    23,     0,   691,     0,
     329,   330,   331,   332,   333,    26,     0,     0,    28,    29,
    -344,     0,     0,   384,     0,     0,     0,     0,     0,   336,
       0,     0,  1130,     0,     0,     0,     0,     0,     0,     0,
     338,   339,  1131,     0,     0,     0,     0,     0,   341,   342,
     343,     0,     0,     0,  1132,   695,   487,     0,   271,     8,
       9,    10,   173,    12,   315,   316,   317,   318,   488,   319,
      14,   345,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    16,   320,    17,    18,    19,     0,
     321,   322,   323,    20,     0,   324,   325,   326,    21,   327,
     328,     0,    23,     0,     0,     0,   329,   330,   331,   332,
     333,    26,     0,     0,    28,   272,     0,     0,     0,   384,
       0,     0,     0,     0,     0,   336,     0,     0,   337,     0,
       0,     0,     0,     0,     0,     0,   338,   339,   340,     0,
       0,     0,     0,     0,   341,   342,   343,     0,     0,   955,
     344,   271,     8,     9,    10,   173,    12,   315,   316,   317,
     318,     0,   319,    14,     0,  -840,     0,   345,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    16,   320,    17,
      18,    19,     0,   321,   322,   323,    20,     0,   324,   325,
     326,    21,   327,   328,     0,    23,     0,     0,     0,   329,
     330,   331,   332,   333,    26,     0,     0,    28,   272,  1719,
       0,  -829,   384,     0,     0,     0,     0,     0,   336,     0,
       0,   337,     0,     0,     0,     0,     0,     0,     0,   338,
     339,   340,     0,     0,     0,     0,     0,   341,   342,   343,
       0,     0,   821,   344,   943,   944,   945,    10,     0,    12,
     504,   316,   317,   318,     0,   319,    14,     0,     0,     0,
     345,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      16,   320,    17,     0,    19,     0,   321,   322,   323,    20,
       0,   324,   325,   326,    21,   327,   328,     0,    23,     0,
       0,     0,   329,   330,   331,   332,   333,    26,     0,     0,
     946,   947,   822,     0,     0,   384,     0,     0,     0,     0,
       0,   336,     0,     0,   337,     0,     0,     0,     0,     0,
       0,     0,   338,   339,   340,     0,     0,     0,     0,     0,
     341,   342,   343,     0,     0,     0,   344,   948,   751,   752,
     753,   754,   755,   756,   757,   758,   759,   760,   761,   762,
     763,   764,  1115,   345,   627,     0,   271,     8,     9,    10,
       0,    12,   315,   316,   317,   318,     0,   319,    14,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    16,   320,    17,    18,    19,     0,   321,   322,
     323,    20,     0,   324,   325,   326,    21,   327,   328,     0,
      23,     0,     0,     0,   329,   330,   331,   332,   333,    26,
       0,     0,    28,   272,  -344,     0,     0,   384,     0,     0,
       0,     0,     0,   336,     0,     0,   628,     0,     0,     0,
       0,     0,     0,     0,   338,   339,   629,     0,     0,     0,
       0,     0,   341,   342,   343,     0,     0,   821,   630,   943,
     944,   945,    10,     0,    12,   504,   316,   317,   318,     0,
     319,    14,     0,     0,     0,   345,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    16,   320,    17,     0,    19,
       0,   321,   322,   323,    20,     0,   324,   325,   326,    21,
     327,   328,     0,    23,     0,     0,     0,   329,   330,   331,
     332,   333,    26,     0,     0,   946,   947,   822,     0,     0,
     384,     0,     0,     0,     0,     0,   336,     0,     0,   337,
       0,     0,     0,     0,     0,     0,     0,   338,   339,   340,
       0,     0,     0,     0,     0,   341,   342,   343,     0,     0,
       0,   344,   948,   821,     0,   271,     8,     9,    10,     0,
      12,   504,   316,   317,   318,     0,   319,    14,   345,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    16,   320,    17,     0,    19,     0,   321,   322,   323,
      20,     0,   324,   325,   326,    21,   327,   328,     0,    23,
       0,     0,     0,   329,   330,   331,   332,   333,    26,     0,
       0,    28,   272,   822,     0,     0,   384,     0,     0,     0,
       0,     0,   336,     0,     0,   337,     0,     0,     0,     0,
       0,     0,     0,   338,   339,   340,     0,     0,     0,     0,
       0,   341,   342,   343,     0,     0,     0,   344,   821,     0,
     943,   944,   945,    10,  1313,    12,   504,   316,   317,   318,
       0,   319,    14,     0,   345,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    16,   320,    17,     0,
      19,     0,   321,   322,   323,    20,     0,   324,   325,   326,
      21,   327,   328,     0,    23,     0,     0,     0,   329,   330,
     331,   332,   333,    26,     0,     0,   946,   947,   822,     0,
       0,   384,     0,     0,     0,     0,     0,   336,     0,     0,
     337,     0,     0,     0,     0,     0,     0,     0,   338,   339,
     340,     0,     0,     0,     0,     0,   341,   342,   343,     0,
       0,   821,   344,   943,   944,   945,    10,     0,    12,   504,
     316,   317,   318,     0,   319,    14,     0,     0,  -514,   345,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    16,
     320,    17,     0,    19,     0,   321,   322,   323,    20,     0,
     324,   325,   326,    21,   327,   328,     0,    23,     0,     0,
       0,   329,   330,   331,   332,   333,    26,     0,     0,   946,
     947,   822,     0,     0,   384,     0,     0,     0,     0,     0,
     336,     0,     0,   337,     0,     0,     0,     0,     0,     0,
       0,   338,   339,   340,     0,     0,     0,     0,     0,   341,
     342,   343,     0,     0,   627,   344,   145,     8,     9,    10,
       0,    12,   315,   316,   317,   318,     0,   319,    14,     0,
       0,  1427,   345,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    16,   320,    17,    18,    19,     0,   321,   322,
     323,    20,     0,   324,   325,   326,    21,   327,   328,     0,
      23,     0,     0,     0,   329,   330,   331,   332,   333,    26,
       0,     0,    28,    29,  -344,     0,     0,   384,     0,     0,
       0,     0,     0,   336,     0,     0,  1701,     0,     0,     0,
       0,     0,     0,     0,   338,   339,  1702,     0,     0,     0,
       0,     0,   341,   342,   343,     0,     0,  1758,  1703,   271,
       8,     9,    10,     0,    12,   315,   316,   317,   318,     0,
     319,    14,     0,     0,     0,   345,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    16,   320,    17,    18,    19,
       0,   321,   322,   323,    20,     0,   324,   325,   326,    21,
     327,   328,     0,    23,     0,     0,     0,   329,   330,   331,
     332,   333,    26,     0,     0,    28,   272,     0,     0,  -208,
     384,     0,     0,     0,     0,     0,   336,     0,     0,   337,
       0,     0,     0,     0,     0,     0,     0,   338,   339,   340,
       0,     0,     0,     0,     0,   341,   342,   343,     0,     0,
     821,   344,   271,     8,     9,    10,     0,    12,   504,   316,
     317,   318,     0,   319,    14,     0,     0,     0,   345,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    16,   320,
      17,     0,    19,     0,   321,   322,   323,    20,     0,   324,
     325,   326,    21,   327,   328,     0,    23,     0,     0,     0,
     329,   330,   331,   332,   333,    26,     0,     0,    28,   272,
     822,     0,     0,   384,     0,     0,     0,     0,     0,   336,
       0,     0,   337,     0,     0,     0,     0,     0,     0,     0,
     338,   339,   340,     0,     0,     0,     0,     0,   341,   342,
     343,     0,     0,   955,   344,   271,     8,     9,    10,     0,
      12,   504,   316,   317,   318,     0,   319,    14,     0,     0,
       0,   345,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    16,   320,    17,     0,    19,     0,   321,   322,   323,
      20,     0,   324,   325,   326,    21,   327,   328,     0,    23,
       0,     0,     0,   329,   330,   331,   332,   333,    26,     0,
       0,    28,   272,     0,     0,     0,   384,  -829,     0,     0,
       0,     0,   336,     0,     0,   337,     0,     0,     0,     0,
       0,     0,     0,   338,   339,   340,     0,     0,     0,     0,
       0,   341,   342,   343,     0,     0,   955,   344,   271,     8,
       9,    10,     0,    12,   504,   316,   317,   318,     0,   319,
      14,     0,     0,     0,   345,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    16,   320,    17,     0,    19,     0,
     321,   322,   323,    20,     0,   324,   325,   326,    21,   327,
     328,     0,    23,     0,     0,     0,   329,   330,   331,   332,
     333,    26,     0,     0,    28,   272,     0,     0,     0,   384,
       0,     0,     0,     0,     0,   336,     0,     0,   337,     0,
       0,     0,     0,     0,     0,     0,   338,   339,   340,     0,
       0,     0,     0,     0,   341,   342,   343,     0,     0,  1052,
     344,   271,     8,     9,    10,     0,    12,   504,   316,   317,
     318,     0,   319,    14,     0,  -829,     0,   345,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    16,   320,    17,
       0,    19,     0,   321,   322,   323,    20,     0,   324,   325,
     326,    21,   327,   328,     0,    23,     0,     0,     0,   329,
     330,   331,   332,   333,    26,     0,     0,    28,   272,     0,
       0,     0,   384,     0,     0,     0,     0,     0,   336,     0,
       0,   337,     0,     0,     0,     0,     0,     0,     0,   338,
     339,   340,     0,     0,     0,     0,     0,   341,   342,   343,
       0,     0,  1054,   344,   271,     8,     9,    10,     0,    12,
     504,   316,   317,   318,     0,   319,    14,     0,     0,     0,
     345,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      16,   320,    17,     0,    19,     0,   321,   322,   323,    20,
       0,   324,   325,   326,    21,   327,   328,     0,    23,     0,
       0,     0,   329,   330,   331,   332,   333,    26,     0,     0,
      28,   272,     0,     0,     0,   384,     0,     0,     0,     0,
       0,   336,     0,     0,   337,     0,     0,     0,     0,     0,
       0,     0,   338,   339,   340,     0,     0,     0,     0,     0,
     341,   342,   343,     0,     0,  1673,   344,   271,     8,     9,
      10,     0,    12,   504,   316,   317,   318,     0,   319,    14,
       0,     0,     0,   345,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    16,   320,    17,     0,    19,     0,   321,
     322,   323,    20,     0,   324,   325,   326,    21,   327,   328,
       0,    23,     0,     0,     0,   329,   330,   331,   332,   333,
      26,     0,     0,    28,   272,     0,     0,     0,   384,     0,
       0,     0,     0,     0,   336,     0,     0,   337,     0,     0,
       0,     0,     0,     0,     0,   338,   339,   340,     0,     0,
       0,     0,     0,   341,   342,   343,     0,     0,     0,   344,
     271,     8,     9,    10,     0,    12,   504,   316,   317,   318,
       0,   319,    14,     0,     0,     0,   345,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    16,   320,    17,     0,
      19,     0,   321,   322,   323,    20,     0,   324,   325,   326,
      21,   327,   328,     0,    23,     0,     0,     0,   329,   330,
     331,   332,   333,    26,     0,     0,    28,   272,     0,     0,
       0,   384,     0,     0,     0,     0,     0,   336,     0,     0,
     337,     0,     0,     0,     0,     0,     0,     0,   338,   339,
     340,     0,     0,     0,     0,     0,   341,   342,   343,     0,
       0,     0,   344,   271,     8,     9,    10,     0,    12,   504,
     316,   317,   318,     0,   319,    14,     0,     0,     0,   345,
     505,     0,     0,     0,     0,     0,     0,     0,     0,    16,
     320,    17,     0,    19,     0,   321,   322,   323,    20,     0,
     324,   325,   326,    21,   327,   328,     0,    23,     0,     0,
       0,   329,   330,   331,   332,   333,    26,     0,     0,    28,
     272,     0,     0,     0,   384,     0,     0,     0,     0,     0,
     336,     0,     0,   337,     0,     0,     0,     0,     0,     0,
       0,   338,   339,   340,     0,     0,     0,     0,     0,   341,
     342,   343,     0,     0,     0,   344,   271,     8,     9,    10,
       0,    12,   504,   316,   317,   318,     0,   319,    14,     0,
       0,     0,   345,   876,     0,     0,     0,     0,     0,     0,
       0,     0,    16,   320,    17,     0,    19,     0,   321,   322,
     323,    20,     0,   324,   325,   326,    21,   327,   328,     0,
      23,     0,     0,     0,   329,   330,   331,   332,   333,    26,
       0,     0,    28,   272,     0,     0,     0,   384,     0,     0,
       0,     0,     0,   336,     0,     0,   337,     0,     0,     0,
       0,     0,     0,     0,   338,   339,   340,     0,     0,     0,
       0,     0,   341,   342,   343,     0,     0,     0,   344,   271,
       8,     9,    10,     0,    12,   504,   316,   317,   318,     0,
     319,    14,     0,     0,     0,   345,   994,     0,     0,     0,
       0,     0,     0,     0,     0,    16,   320,    17,     0,    19,
       0,   321,   322,   323,    20,     0,   324,   325,   326,    21,
     327,   328,     0,    23,     0,     0,     0,   329,   330,   331,
     332,   333,    26,     0,     0,    28,   272,     0,     0,     0,
     384,     0,     0,     0,     0,     0,   336,     0,     0,   337,
       0,     0,     0,     0,     0,     0,     0,   338,   339,   340,
       0,     0,     0,     0,     0,   341,   342,   343,     0,     0,
       0,   344,   271,     8,     9,    10,     0,    12,   504,   316,
     317,   318,     0,   319,    14,     0,     0,     0,   345,  1014,
       0,     0,     0,     0,     0,     0,     0,     0,    16,   320,
      17,     0,    19,     0,   321,   322,   323,    20,     0,   324,
     325,   326,    21,   327,   328,     0,    23,     0,     0,     0,
     329,   330,   331,   332,   333,    26,     0,     0,    28,   272,
       0,     0,     0,   384,     0,     0,     0,     0,     0,   336,
       0,     0,   337,     0,     0,     0,     0,     0,     0,     0,
     338,   339,   340,     0,     0,     0,     0,     0,   341,   342,
     343,     0,     0,     0,   344,   750,   751,   752,   753,   754,
     755,   756,   757,   758,   759,   760,   761,   762,   763,   764,
       0,   345,  1248,  1577,  1578,  1579,    10,   173,    12,   315,
     316,   317,   318,     0,   319,    14,  1580,     0,  1581,  1582,
    1583,  1584,  1585,  1586,  1587,  1588,  1589,  1590,    15,    16,
     320,    17,    18,    19,     0,   321,   322,   323,    20,     0,
     324,   325,   326,    21,   327,   328,  1591,    23,  1592,     0,
       0,   329,   330,   331,   332,   333,    26,     0,     0,  1593,
     272,  1204,     0,  1594,   384,     0,     0,     0,     0,     0,
     336,     0,     0,   337,     0,     0,     0,     0,     0,     0,
       0,   338,   339,   340,     0,     0,     0,     0,     0,   341,
     342,   343,     0,     0,     0,   344,     0,  1595,  1577,  1578,
    1579,    10,   173,    12,   315,   316,   317,   318,     0,   319,
      14,  1580,   345,  1581,  1582,  1583,  1584,  1585,  1586,  1587,
    1588,  1589,  1590,    15,    16,   320,    17,    18,    19,     0,
     321,   322,   323,    20,     0,   324,   325,   326,    21,   327,
     328,  1591,    23,  1592,     0,     0,   329,   330,   331,   332,
     333,    26,     0,     0,  1593,   272,     0,     0,  1594,   384,
       0,     0,     0,     0,     0,   336,     0,     0,   337,     0,
       0,     0,     0,     0,     0,     0,   338,   339,   340,     0,
       0,     0,     0,     0,   341,   342,   343,     0,     0,     0,
     344,     0,  1595,   271,     8,     9,    10,   173,    12,   315,
     316,   317,   318,   488,   319,    14,     0,   345,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    16,
     320,    17,    18,    19,     0,   321,   322,   323,    20,     0,
     324,   325,   326,    21,   327,   328,     0,    23,     0,   691,
       0,   329,   330,   331,   332,   333,    26,     0,     0,    28,
     272,     0,     0,     0,   384,     0,     0,     0,     0,     0,
     336,     0,     0,  1026,     0,     0,     0,     0,     0,     0,
       0,   338,   339,  1027,     0,     0,     0,     0,     0,   341,
     342,   343,     0,     0,     0,  1028,   695,   145,     8,     9,
      10,   173,    12,   315,   316,   317,   318,   488,   319,    14,
       0,     0,   345,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    16,   320,    17,    18,    19,     0,   321,
     322,   323,    20,     0,   324,   325,   326,    21,   327,   328,
       0,    23,     0,   691,     0,   329,   330,   331,   332,   333,
      26,     0,     0,    28,    29,     0,     0,     0,   384,     0,
       0,     0,     0,     0,   336,     0,     0,  1130,     0,     0,
       0,     0,     0,     0,     0,   338,   339,  1131,     0,     0,
       0,     0,     0,   341,   342,   343,     0,     0,     0,  1132,
     695,   271,     8,     9,    10,     0,    12,   315,   316,   317,
     318,     0,   319,    14,     0,     0,   345,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    16,   320,    17,
      18,    19,     0,   321,   322,   323,    20,     0,   324,   325,
     326,    21,   327,   328,     0,    23,     0,     0,     0,   329,
     330,   331,   332,   333,    26,     0,     0,   334,   272,     0,
       0,     0,   335,     0,     0,     0,     0,     0,   336,     0,
       0,   337,     0,     0,     0,     0,     0,     0,     0,   338,
     339,   340,     0,     0,     0,     0,     0,   341,   342,   343,
       0,     0,     0,   344,   271,     8,     9,    10,     0,    12,
     315,   316,   317,   318,     0,   319,    14,     0,     0,     0,
     345,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      16,   320,    17,    18,    19,     0,   321,   322,   323,    20,
       0,   324,   325,   326,    21,   327,   328,     0,    23,     0,
       0,     0,   329,   330,   331,   332,   333,    26,     0,     0,
      28,   272,     0,     0,     0,   384,     0,     0,     0,     0,
       0,   336,     0,     0,   337,     0,     0,     0,     0,     0,
       0,     0,   338,   339,   340,     0,     0,     0,     0,     0,
     341,   342,   343,     0,     0,     0,   344,   271,     8,     9,
      10,     0,    12,   504,   316,   317,   318,     0,   319,    14,
       0,     0,     0,   345,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    16,   320,    17,    18,    19,     0,   321,
     322,   323,    20,     0,   324,   325,   326,    21,   327,   328,
       0,    23,     0,     0,     0,   329,   330,   331,   332,   333,
      26,     0,     0,    28,   272,     0,     0,     0,   384,     0,
       0,     0,     0,     0,   336,     0,     0,   628,     0,     0,
       0,     0,     0,     0,     0,   338,   339,   629,     0,     0,
       0,     0,     0,   341,   342,   343,     0,     0,     0,   630,
     271,     8,     9,    10,     0,    12,   504,   316,   317,   318,
       0,   319,    14,     0,     0,     0,   345,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    16,   320,    17,     0,
      19,     0,   321,   322,   323,    20,     0,   324,   325,   326,
      21,   327,   328,     0,    23,     0,     0,     0,   329,   330,
     331,   332,   333,    26,     0,     0,    28,   272,     0,     0,
    1640,   384,     0,     0,     0,     0,     0,   336,     0,     0,
     337,     0,     0,     0,     0,     0,     0,     0,   338,   339,
     340,     0,     0,     0,     0,     0,   341,   342,   343,     0,
       0,     0,   344,   271,     8,     9,    10,   173,    12,   315,
     316,   317,   318,     0,   319,    14,     0,     0,     0,   345,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    16,
     320,    17,    18,    19,     0,   321,   322,   323,    20,     0,
     324,   325,   326,    21,   327,   328,     0,    23,     0,     0,
       0,   329,   330,   331,   332,   333,    26,     0,     0,    28,
     272,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     336,     0,     0,   337,     0,     0,     0,     0,     0,     0,
       0,   338,   339,   340,     0,     0,     0,     0,     0,   341,
     342,   343,     0,     0,     0,   344,   145,     8,     9,    10,
       0,    12,   504,   316,   317,   318,     0,   319,    14,     0,
       0,     0,   345,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    16,   320,    17,    18,    19,     0,   321,   322,
     323,    20,     0,   324,   325,   326,    21,   327,   328,     0,
      23,     0,     0,     0,   329,   330,   331,   332,   333,    26,
       0,     0,    28,    29,     0,     0,     0,   384,     0,     0,
       0,     0,     0,   336,     0,     0,  1701,     0,     0,     0,
       0,     0,     0,     0,   338,   339,  1702,     0,     0,     0,
       0,     0,   341,   342,   343,     0,     0,     0,  1703,   271,
       8,     9,    10,     0,    12,   504,   316,   317,   318,     0,
     319,    14,     0,     0,     0,   345,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    16,   320,    17,     0,    19,
       0,   321,   322,   323,    20,     0,   324,   325,   326,    21,
     327,   328,     0,    23,     0,     0,     0,   329,   330,   331,
     332,   333,    26,     0,     0,    28,   272,     0,     0,     0,
     335,     0,     0,     0,     0,     0,   336,     0,     0,   337,
       0,     0,     0,     0,     0,     0,     0,   338,   339,   340,
       0,     0,     0,     0,     0,   341,   342,   343,     0,     0,
       0,   344,   271,     8,     9,    10,     0,    12,   504,   316,
     317,   318,     0,   319,    14,     0,     0,     0,   345,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    16,   320,
      17,     0,    19,     0,   321,   322,   323,    20,     0,   324,
     325,   326,    21,   327,   328,     0,    23,     0,     0,     0,
     329,   330,   331,   332,   333,    26,     0,     0,    28,   272,
     642,     0,     0,     0,     0,     0,     0,     0,     0,   336,
       0,     0,   337,     0,     0,     0,     0,     0,     0,     0,
     338,   339,   340,     0,     0,     0,     0,     0,   341,   342,
     343,     0,     0,     0,   643,   271,     8,     9,    10,     0,
      12,   504,   316,   317,   318,     0,   319,    14,     0,     0,
       0,   345,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    16,   320,    17,     0,    19,     0,   321,   322,   323,
      20,     0,   324,   325,   326,    21,   327,   328,     0,    23,
       0,     0,     0,   329,   330,   331,   332,   333,    26,     0,
       0,    28,   272,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   336,     0,     0,   337,     0,     0,     0,     0,
       0,     0,     0,   338,   339,   340,     0,     0,     0,     0,
       0,   341,   342,   343,     0,     0,     0,   344,   680,   271,
       8,     9,    10,     0,    12,   504,   316,   317,   318,     0,
     319,    14,     0,     0,   345,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    16,   320,    17,     0,    19,
       0,   321,   322,   323,    20,     0,   324,   325,   326,    21,
     327,   328,     0,    23,     0,     0,     0,   329,   330,   331,
     332,   333,    26,     0,     0,    28,   272,     0,     0,     0,
     384,     0,     0,     0,     0,     0,   336,     0,     0,   337,
       0,     0,     0,     0,     0,     0,     0,   338,   339,   340,
       0,     0,     0,     0,     0,   341,   342,   343,     0,     0,
       0,   344,   271,     8,     9,    10,     0,    12,   504,   316,
     317,   318,     0,   319,    14,     0,     0,     0,   345,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    16,   320,
      17,    18,    19,     0,   321,   322,   323,    20,     0,   324,
     325,   326,    21,   327,   328,     0,    23,     0,     0,     0,
     329,   330,   331,   332,   333,    26,     0,     0,    28,   272,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   336,
       0,     0,   628,     0,     0,     0,     0,     0,     0,     0,
     338,   339,   629,     0,     0,     0,     0,     0,   341,   342,
     343,     0,     0,     0,   630,  1269,     8,     9,    10,     0,
      12,   504,   316,   317,   318,     0,   319,    14,     0,     0,
       0,   345,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    16,   320,    17,     0,    19,     0,   321,   322,   323,
      20,     0,   324,   325,   326,    21,   327,   328,     0,    23,
       0,     0,     0,   329,   330,   331,   332,   333,    26,     0,
       0,    28,   272,     0,     0,     0,   384,     0,     0,     0,
       0,     0,   336,     0,     0,   337,     0,     0,     0,     0,
       0,     0,     0,   338,   339,   340,     0,     0,     0,     0,
       0,   341,   342,   343,     0,     0,     0,   344,   145,     8,
       9,    10,     0,    12,   315,   316,   317,   318,     0,   319,
      14,     0,     0,     0,   345,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    16,   320,    17,    18,    19,     0,
     321,   322,   323,    20,     0,   324,   325,   326,    21,   327,
     328,     0,    23,     0,     0,     0,   329,   330,   331,   332,
     333,    26,     0,     0,    28,    29,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   336,     0,     0,  1701,     0,
       0,     0,     0,     0,     0,     0,   338,   339,  1702,     0,
       0,     0,     0,     0,   341,   342,   343,     0,     0,     0,
    1703,   271,     8,     9,    10,     0,    12,   504,   316,   317,
     318,     0,   319,    14,     0,     0,     0,   345,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    16,   320,    17,
       0,    19,     0,   321,   322,   323,    20,     0,   324,   325,
     326,    21,   327,   328,     0,    23,     0,     0,     0,   329,
     330,   331,   332,   333,    26,     0,     0,    28,   272,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   336,     0,
       0,   337,     0,     0,     0,     0,     0,     0,     0,   338,
     339,   340,     0,     0,     0,     0,     0,   341,   342,   343,
       0,     0,     0,   344,   271,     8,     9,    10,     0,    12,
     504,   316,   317,   318,     0,   319,    14,     0,     0,     0,
     345,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      16,   320,    17,     0,    19,     0,   321,   322,   323,    20,
       0,   324,   325,   326,    21,   327,   328,     0,    23,     0,
       0,     0,   329,   330,   331,   332,   333,    26,     0,     0,
      28,   272,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   336,     0,     0,   337,     0,     0,     0,     0,     0,
       0,     0,   338,   339,   340,     0,     0,     0,     0,     0,
     341,   342,   343,     0,     0,     0,   701,   271,     8,     9,
      10,     0,    12,   504,   316,   317,   318,     0,   319,    14,
       0,     0,     0,   345,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    16,   320,    17,     0,    19,     0,   321,
     322,   323,    20,     0,   324,   325,   326,    21,   327,   328,
       0,    23,     0,     0,     0,   329,   330,   331,   332,   333,
      26,     0,     0,    28,   272,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   336,     0,     0,   337,     0,     8,
       9,     0,   173,    12,    13,   338,   339,   340,  1610,     0,
      14,     0,     0,   341,   342,   343,     0,     0,     0,   703,
       0,     0,     0,     0,    16,     0,    17,    18,     0,     0,
       0,     0,     0,    20,     8,     9,   345,   212,    12,   213,
       0,     0,    23,     0,     0,    14,     0,     0,     0,     0,
       0,    26,     0,     0,   134,   135,     0,     0,     0,    16,
       0,    17,    18,     0,     0,     0,     0,     0,    20,     8,
       9,     0,     0,    12,    13,     0,     0,    23,     0,     0,
      14,     0,     0,     0,     0,     0,    26,     0,     0,   134,
     135,     0,     0,     0,    16,     0,    17,    18,     0,     0,
       0,     0,     0,    20,     0,     0,     0,     0,     0,     0,
       0,     0,    23,     0,     0,     0,     0,     0,     0,     0,
       0,    26,     0,     0,   134,   135,   743,   744,   745,   746,
     747,   748,   749,   750,   751,   752,   753,   754,   755,   756,
     757,   758,   759,   760,   761,   762,   763,   764,   743,   744,
     745,   746,   747,   748,   749,   750,   751,   752,   753,   754,
     755,   756,   757,   758,   759,   760,   761,   762,   763,   764,
       0,     0,     0,  1387,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   742,     0,
       0,  1708,   743,   744,   745,   746,   747,   748,   749,   750,
     751,   752,   753,   754,   755,   756,   757,   758,   759,   760,
     761,   762,   763,   764,  1195,     0,     0,     0,   743,   744,
     745,   746,   747,   748,   749,   750,   751,   752,   753,   754,
     755,   756,   757,   758,   759,   760,   761,   762,   763,   764,
     743,   744,   745,   746,   747,   748,   749,   750,   751,   752,
     753,   754,   755,   756,   757,   758,   759,   760,   761,   762,
     763,   764,   645,   646,   647,   648,   649,   650,   651,   652,
     653,   654,   655,   656,     0,   657,   658,   659,   660,   661,
     662,   663,   664,   665
};

static const short yycheck[] =
{
      14,     4,   180,     4,   365,   181,    23,   196,    22,    82,
     745,   182,   130,   816,   423,   423,    82,     4,   216,   423,
     373,   374,   423,   551,   162,   155,   156,   137,   138,     4,
     352,   371,    87,    36,   371,    36,   725,   983,   640,   261,
     252,   363,   364,    45,    45,   393,    45,     4,     4,    36,
    1420,   391,   465,   196,   391,    69,   216,   255,    45,    60,
      14,    36,   792,     4,   246,  1426,   226,   128,  1541,    34,
      45,   483,  1541,    74,   137,     4,    45,   430,   431,    36,
      36,    34,     0,    62,   150,    61,    87,   818,    45,    45,
       3,    92,     4,   501,    95,    36,    97,   501,  1596,    39,
      87,    45,   225,   226,    45,  1536,    12,    36,  1684,   138,
     799,   112,   798,   311,   128,  1162,     7,  1164,    65,    31,
      32,     0,    65,    99,    36,  1172,    77,     9,    58,   532,
      49,    85,   111,    45,    77,   496,     4,  1443,  1444,   140,
     154,   142,    65,   144,   210,  1705,   507,    49,    39,   371,
       1,   554,    50,   140,  1460,  1715,  1716,   111,   111,    78,
      95,    45,    97,   110,    77,   140,  1742,   365,    36,   391,
     171,   111,   171,   175,   175,    87,   175,    45,  1609,    63,
      49,   182,    64,   140,   171,  1683,    13,   110,   175,    77,
      96,   156,   157,    95,     1,   196,   171,   141,    62,   140,
     175,  1761,  1781,  1509,   277,    95,   175,   142,     1,   196,
      61,    62,  1518,  1519,   171,  1521,    49,    63,   175,   175,
     221,    49,    62,    63,  1803,     4,    95,    96,   140,    34,
     171,   175,   246,   247,   175,    62,    28,   202,    65,   112,
      32,   110,   171,   155,   156,  1718,   110,   261,    62,  1718,
     360,   181,    63,  1813,    61,   905,  1687,    36,    65,   171,
      62,   911,    95,   175,    63,   111,    45,    95,    61,    13,
    1216,    63,    65,   141,    26,    67,    28,   110,    13,    58,
      63,    60,   110,   110,   196,    62,    62,    62,   200,   201,
      97,   175,  1749,    77,  1725,   484,   110,   360,   109,    56,
     111,   220,   357,   257,    97,   443,    95,   175,   110,    61,
      60,   312,   111,    65,  1620,  1621,    56,    49,    62,   111,
      77,    65,   336,    67,   197,  1782,    56,    62,   111,    95,
      65,  1762,   216,   110,   110,   110,    63,    77,     3,     4,
       5,   225,   226,   344,   405,    97,   109,    77,   221,    26,
     155,   156,   157,     3,     4,     5,   357,  1043,  1719,    63,
    1046,   140,  1092,    95,    96,   366,   380,   146,   550,   529,
     357,   255,  1022,   726,   375,   376,   785,  1747,   392,   344,
     518,    34,    49,   720,   413,   515,   516,    56,    49,   376,
     140,   405,   171,    49,    59,    60,   175,   202,   811,   812,
      50,   376,   181,   182,    49,   528,   529,    61,    77,    59,
      60,    67,  1459,    67,   537,  1101,  1102,   371,    83,   376,
      56,    49,   423,    13,   613,   426,   774,   311,    95,    96,
     553,   432,   182,    83,    95,   376,   423,   391,    28,    95,
     375,   110,    32,   110,    26,   357,    28,    40,   801,  1395,
      95,   230,     3,     4,     5,    49,     3,     4,     5,    49,
    1149,    49,   684,    56,   376,   467,   467,    95,   467,     4,
       5,    49,    62,    63,     9,    65,    56,    67,   667,    61,
     467,   365,   605,    65,   673,    65,   675,   676,    49,   454,
     455,   713,   467,   494,  1096,   425,   497,   432,    95,    50,
     501,    95,   155,   156,   157,    95,    96,    95,    59,    60,
     467,   423,    59,    60,   501,    97,   705,    95,    96,    26,
     110,    56,    56,   712,    59,    60,   467,    32,     4,    56,
     110,    65,    83,   722,    95,  1185,   550,  1187,    73,     4,
       5,   542,    65,   427,     4,     5,     4,     5,    83,   202,
      77,   516,   517,    62,    61,   467,  1612,    77,    65,    49,
      36,    96,    78,   493,    80,   495,   496,    56,    49,    78,
      65,    56,   925,   985,  1260,  1261,   110,  1633,    49,     4,
       5,     3,    77,   467,     9,  1113,    67,    49,    77,   501,
      97,    49,    77,  1649,    59,    60,    56,   376,    56,    59,
      60,    59,    60,   515,   516,    95,    96,   542,    26,    56,
      28,   612,   496,    73,    95,    73,   617,   618,   619,   620,
     621,   540,   677,    83,    95,    83,   376,  1155,   642,   630,
      77,    56,   810,    95,    59,    60,    96,    95,    96,   640,
      56,    49,   643,    61,   528,   529,   425,    65,    73,  1705,
      65,   524,   841,   537,    56,   434,   188,    49,    83,  1715,
    1716,    77,    77,    49,   629,   630,   855,    61,    61,   553,
     684,    65,   782,    49,    95,   676,   677,   612,   643,    97,
     892,   893,    49,  1333,  1093,  1093,   898,    95,   467,  1093,
     677,    49,  1093,   694,  1034,    56,  1346,  1034,   522,   713,
     701,    77,   703,    95,   705,  1761,   530,   694,  1030,    95,
     515,   516,   517,    49,   493,   494,   495,   496,   705,    95,
      96,   605,   501,    62,    56,   863,  1138,  1139,    95,    56,
     509,    67,  1085,   931,   110,    78,   701,    95,   703,    78,
     705,    80,  1473,   522,   617,    49,   775,     8,     9,    65,
      26,   530,    28,   782,    15,   709,    49,  1813,   881,    95,
      96,    77,   905,    49,    56,   677,   783,    50,   911,   783,
      77,    32,   838,    65,   647,   110,   777,    38,   792,   110,
     692,   693,   694,   901,   110,    61,    47,   566,    49,    65,
     110,    95,    96,   705,  1206,  1207,  1136,   986,   728,  1136,
    1328,   674,    95,    96,    12,  1536,   110,   680,   822,    95,
      96,  1000,  1034,  1002,   111,  1004,    63,   110,    32,     4,
       5,    97,   695,    49,   110,    46,  1179,  1180,  1181,   902,
    1222,  1223,   833,  1225,    95,    56,     3,     4,     5,    60,
     841,    99,   777,    62,    95,   729,   833,     3,    67,    61,
      63,  1501,    28,    65,   841,    77,    32,    61,    77,    78,
    1221,   791,   515,   516,   517,    49,    62,    63,   833,    95,
      96,    56,   745,    61,    59,    60,   841,    65,  1609,  1022,
      62,    63,  1294,    50,   110,   839,    62,    63,    73,    96,
     855,  1080,    59,    60,  1032,  1423,     3,    49,    83,     6,
      65,   902,   867,   868,   905,   906,   907,   791,   909,    96,
     911,    95,    96,  1325,  1136,   902,    83,    95,   905,   831,
     832,   833,    62,    63,   911,    32,   110,   902,    77,   841,
    1733,    95,  1110,   147,    62,    63,    43,    95,   152,   113,
    1152,  1153,  1154,    95,    96,    77,   902,    77,  1683,   728,
      77,  1682,    59,    60,   866,   867,  1687,    62,   110,    62,
      63,   902,    86,    87,    49,     1,    73,     3,     4,     5,
      95,   906,   907,    56,   909,  1387,    83,     3,     4,     5,
      62,   982,     4,     5,    91,   986,  1124,   201,    95,   110,
     902,  1121,  1122,   905,  1725,    86,    87,   881,    56,   911,
    1130,  1131,     4,     5,    89,    90,   110,    65,    93,    94,
      95,    96,   791,    49,    77,  1016,     3,     4,     5,    77,
      56,  1022,    56,    59,    60,  1437,    77,  1028,   833,    77,
      56,  1762,   110,    59,    60,  1022,   841,    59,    60,    62,
      63,  1028,  1185,   110,  1187,   111,    56,   931,     3,     4,
       5,  1786,  1405,    12,    56,    65,   270,    59,    60,    95,
    1126,    62,  1027,  1028,  1078,  1477,   111,    77,     3,     4,
       5,     6,    59,    60,    65,    62,    77,    78,  1092,    80,
    1034,   860,   110,    49,    67,     3,     4,     5,    67,  1162,
      56,  1164,  1093,   110,  1095,  1096,  1113,  1170,    56,  1172,
     879,    56,    62,    63,    59,    60,  1093,    65,    43,   113,
    1022,    77,    62,    63,  1026,  1027,  1028,   990,   110,    77,
     110,    56,  1123,   902,    59,    60,    49,    49,    63,    95,
      65,  1132,    50,    56,    56,   110,  1123,   110,    73,  1547,
    1141,    59,    60,  1547,    28,  1132,    62,    63,    83,    77,
    1023,    77,   902,    56,    77,    77,    91,  1122,  1123,    56,
      95,  1162,    65,  1164,    77,    83,  1131,  1132,   113,  1170,
      56,  1172,    95,    95,    77,  1162,   113,  1164,   110,    65,
     833,  1093,  1136,    56,  1185,  1172,  1187,  1162,   841,  1164,
    1333,    77,    65,  1207,  1195,   110,  1161,  1172,  1185,   110,
    1187,   110,     3,  1346,    77,    56,  1162,  1164,  1164,  1121,
    1122,  1123,     4,     5,     8,    95,  1172,    49,  1130,  1131,
    1132,  1162,    63,  1164,    28,    67,   111,  1416,    32,  1230,
     444,  1172,    62,   447,    95,   111,  1425,    56,    63,  1169,
      77,     3,     4,     5,  1605,   459,  1165,  1166,    38,    67,
    1162,    67,  1164,    67,    46,  1256,  1175,   110,    62,    63,
    1172,   110,   110,    67,    56,    63,   110,    59,    60,  1256,
      67,    67,    78,  1185,   113,  1187,    62,   110,     4,     5,
    1294,   110,     8,     9,   110,  1358,   110,    78,    50,    15,
    1255,  1256,  1358,    78,  1367,  1230,   510,    59,    60,   513,
    1301,    78,   196,    29,    78,    31,    32,   110,     3,     4,
       5,     6,    38,   527,  1301,    61,  1121,  1122,  1123,   362,
      65,    47,   365,   366,    65,  1130,  1131,  1132,    62,   110,
      56,   110,  1333,    59,    60,  1300,  1301,    65,   110,  1118,
     113,   111,  1254,  1255,  1256,  1346,  1333,   110,    43,   920,
     921,   922,  1713,  1226,   886,    50,  1161,   110,  1501,  1346,
       3,     4,     5,     6,    59,    60,  1367,    96,    91,    95,
     113,    77,    31,    32,    49,    34,   113,   110,   110,   110,
    1367,  1454,    65,  1162,  1796,  1164,  1459,  1299,  1300,  1301,
    1169,  1170,  1367,  1172,   110,   110,    91,    40,    41,   110,
      43,    60,   110,   110,    63,   110,  1423,  1337,  1320,  1321,
      69,  1367,  1162,    56,  1164,    74,    59,    60,   111,  1169,
    1170,  1333,  1172,   111,    63,    61,  1367,  1603,   110,  1605,
      67,  1350,  1433,  1604,  1346,    95,   110,  1356,  1357,   110,
      95,  1360,  1361,    95,    95,  1364,   111,   110,    91,   110,
     493,   113,   495,   496,   497,  1367,  1470,     8,  1459,     7,
       8,     9,    83,    84,    85,    86,    87,    15,  1121,  1122,
    1123,  1660,  1459,   113,     3,     4,     5,  1130,  1131,  1132,
       3,     4,     5,   110,  1459,   110,   110,   110,   147,    98,
      38,   110,  1493,   152,   110,    62,   155,   156,   157,    47,
    1501,    62,    65,  1459,    56,   110,  1493,   110,  1161,  1382,
    1383,  1384,  1385,   110,  1501,  1713,    65,  1296,  1459,   113,
    1393,    50,    49,   182,   110,    67,  1305,    50,   110,   188,
      59,    60,  1710,   110,   110,   110,    59,    60,  1541,   110,
    1541,   200,   201,   202,     8,     9,  1547,  1459,    34,   113,
     110,    15,    95,   110,  1541,  1569,   110,   216,  1337,    65,
    1547,     7,     8,     9,    65,    63,  1541,   226,    32,    15,
      63,  1701,  1702,     9,    38,    63,  1590,  1591,    17,  1491,
    1492,  1493,   110,    47,  1541,  1541,    32,  1337,  1367,  1501,
     484,   111,    38,   878,   110,  1596,   255,  1516,  1517,    61,
    1541,    47,    63,  1604,     3,     4,     5,     6,    95,  1596,
      95,   270,    63,     3,     4,     5,    56,  1367,   832,   904,
      67,  1596,     3,     4,     5,   910,     7,     8,     9,  1541,
      95,   109,  1646,  1647,   104,  1547,    18,    63,    56,  1596,
    1596,    12,   110,    63,    43,    95,    63,     3,     4,     5,
     864,   865,   311,   312,   110,  1596,    63,    56,   872,    63,
      59,    60,    62,    12,    67,   110,    56,    63,  1541,    59,
      60,    61,  1451,  1603,    63,  1605,  1677,  1456,    59,    60,
    1459,  1695,  1683,  1684,  1596,   344,   113,   110,    12,   110,
    1677,    12,    91,    95,    63,  1660,  1683,  1684,    63,    63,
     110,    63,  1703,    59,    60,    61,   365,   366,  1683,  1459,
      83,    84,    85,    86,    87,  1718,  1589,  1718,     0,   613,
       0,  1605,     0,   176,    36,     2,  1683,  1683,   775,  1093,
    1647,  1718,  1017,   175,  1019,  1709,   171,  1702,  1703,  1170,
    1659,  1742,  1683,  1718,  1423,   467,    99,   144,   791,  1632,
    1764,   822,   314,  1078,     1,  1742,     3,     4,     5,   735,
    1328,  1718,  1718,  1367,  1155,  1677,  1170,   426,   427,  1642,
    1456,  1683,  1684,   667,   737,  1049,   677,  1718,   207,   673,
     360,   675,   676,   128,  1714,   444,  1474,  1536,   447,  1701,
    1702,     7,     8,     9,   453,   454,   455,  1718,   634,    15,
     459,  1733,    49,  1730,  1677,    -1,  1718,  1339,  1340,    56,
    1683,  1684,    59,    60,    61,    62,    32,  1736,   712,  1780,
     850,  1433,    38,    -1,  1603,  1604,  1605,    -1,   722,  1713,
    1742,    47,    -1,    -1,  1366,   494,    -1,   496,   497,  1371,
      -1,    -1,    -1,    -1,    -1,  1718,    -1,    63,    95,    -1,
      -1,   510,    -1,    -1,   513,  1660,   515,   516,   517,     3,
       4,     5,   521,    -1,    -1,    -1,    -1,    -1,   527,  1742,
     529,    -1,    -1,   532,    -1,     3,     4,     5,    -1,     7,
       8,     9,    -1,  1756,    -1,    -1,    -1,    -1,   931,    -1,
      -1,     3,     4,     5,   553,   554,  1701,  1702,  1703,  1184,
      -1,  1186,    -1,  1776,    32,  1119,  1120,     3,     4,     5,
      38,     7,    56,  1786,  1128,    59,    60,  1449,  1450,    -1,
    1452,  1453,    -1,  1455,     3,     4,     5,    -1,    56,    -1,
      -1,    59,    60,    61,  1807,  1714,     3,     4,     5,     6,
      -1,    82,    58,    39,    -1,    -1,   605,    59,    60,    -1,
       9,    -1,    -1,    -1,    13,     3,     4,     5,     6,    -1,
      56,  1246,  1005,    59,    60,    -1,    -1,    -1,   109,   628,
     629,   630,    -1,    -1,  1506,  1507,    43,   105,   106,   107,
      59,    60,    -1,    50,   643,    -1,    -1,    -1,    -1,  1032,
      49,    -1,    59,    60,    -1,    43,   137,     3,     4,     5,
      -1,    -1,    50,    62,    -1,    64,    65,  1660,    67,   150,
      -1,    59,    60,     1,    -1,     3,     4,     5,     6,    78,
       8,    80,    -1,    -1,    91,    -1,    -1,    -1,  1560,  1561,
    1562,    -1,    -1,   692,   693,   694,    95,    96,    -1,    -1,
      -1,    -1,   701,    91,   703,    -1,   705,    -1,  1701,  1702,
    1703,   110,    -1,    59,    60,    43,    -1,    -1,    -1,    -1,
      -1,    -1,    50,    -1,    -1,   181,    -1,    -1,    56,   210,
     729,    59,    60,    66,    -1,  1118,    -1,    -1,    -1,    -1,
      -1,  1124,    -1,  1297,  1298,  1617,  1618,     3,     4,     5,
    1304,    -1,   986,    -1,    -1,     3,     4,     5,     6,    -1,
      -1,    -1,    -1,    91,    -1,   246,  1000,    -1,  1002,    -1,
    1004,    -1,     4,     5,   230,     7,     8,     9,    -1,    -1,
      -1,    13,    -1,    15,  1409,    -1,    -1,    -1,     3,     4,
       5,    -1,   791,   792,    -1,    43,   277,    29,    -1,    31,
      32,    49,    -1,    59,    60,    -1,    38,    -1,    56,    -1,
      -1,    59,    60,   146,  1439,    47,    -1,    49,    -1,    -1,
    1445,    -1,    -1,    -1,    56,    73,    -1,    59,    60,   162,
      -1,    -1,   831,   832,   833,    83,  1461,  1462,    -1,    -1,
      -1,    73,   841,    91,    59,    60,  1080,    95,    96,    -1,
      -1,    83,    -1,  1236,    -1,    -1,   855,    -1,    -1,  1484,
      -1,  1244,    -1,    95,    96,   864,   865,   866,   867,   868,
      -1,    -1,    -1,   872,    -1,    -1,    -1,     3,     4,     5,
       6,    -1,  1754,    -1,    -1,    -1,   219,   886,    -1,   370,
      -1,     3,     4,     5,     6,   228,    -1,     9,    -1,    -1,
      -1,    -1,  1527,  1528,    -1,    -1,    -1,    -1,     4,   390,
      -1,    -1,   245,  1296,    -1,    -1,    -1,    43,    14,    -1,
      32,   335,  1305,   256,    50,    -1,  1551,  1552,    24,  1554,
      -1,    43,   931,    59,    60,    31,    32,    49,    34,    -1,
      36,     3,     4,     5,    56,    -1,    -1,    59,    60,    45,
       7,     8,     9,    -1,    -1,   436,    -1,    83,    15,    -1,
      -1,    73,    58,    -1,    60,    91,    -1,    -1,    -1,   425,
      -1,    83,    -1,    69,    -1,    32,    -1,    -1,    74,    91,
      -1,    38,    -1,    95,    96,    -1,    -1,    -1,    -1,    85,
      47,    87,    -1,    -1,    -1,    -1,    92,    59,    60,    95,
      -1,    97,    -1,    -1,    -1,    -1,    63,  1006,    -1,    -1,
    1009,    84,    -1,    -1,    -1,   111,    -1,    -1,    -1,    -1,
      -1,  1020,    -1,    -1,    -1,    -1,    -1,  1026,  1027,  1028,
      -1,     3,     4,     5,     6,    -1,    -1,   493,    -1,   495,
     496,    -1,   138,  1668,   140,    -1,   142,    -1,   144,    -1,
     146,   147,    -1,   509,    -1,   151,   152,    -1,    -1,   155,
     156,   157,   518,    -1,    -1,    -1,   522,    -1,    -1,   550,
      -1,    43,    -1,    -1,   530,   171,    -1,    -1,    50,   175,
      -1,    -1,    -1,    -1,    -1,   181,   182,    59,    60,    -1,
      -1,    -1,   165,  1092,    81,    82,    83,    84,    85,    86,
      87,   434,    -1,    -1,   200,   201,   202,    -1,     4,     5,
     443,  1494,  1495,     3,     4,     5,     6,    -1,    -1,    91,
    1119,  1120,  1121,  1122,  1123,   198,    -1,   608,    -1,  1128,
      -1,  1130,  1131,  1132,   230,    -1,    32,    -1,   211,    -1,
      -1,    -1,   475,  1142,  1143,  1144,   692,   693,    -1,    -1,
      -1,   247,    -1,    43,     3,     4,     5,     6,    -1,    -1,
      56,   257,  1161,    59,    60,    -1,    56,  1550,    -1,    59,
      60,  1170,    -1,    63,   270,    -1,   509,    73,    -1,    -1,
      -1,    -1,  1416,    73,    -1,   518,    -1,    83,    -1,    -1,
      -1,  1425,    -1,    83,    43,    -1,    -1,    -1,    -1,    95,
      -1,    91,    -1,    -1,    -1,    95,   539,    -1,   689,    -1,
      59,    60,    -1,    -1,    -1,    -1,   312,   313,     3,     4,
       5,     6,    -1,    -1,    -1,    -1,    -1,   708,    -1,    -1,
      -1,   645,   646,   566,   648,   649,   650,   651,   652,   653,
     654,   655,   656,   657,   658,   659,   660,   661,   662,   663,
     664,   665,    -1,    -1,    -1,  1254,  1255,  1256,    43,    -1,
      -1,   357,    -1,    -1,   360,    -1,   362,    -1,    -1,   365,
     366,    -1,   728,    -1,    59,    60,    -1,    -1,    -1,   375,
     376,    -1,    -1,    -1,    -1,   831,   832,     4,     5,    -1,
      -1,    -1,     9,     3,     4,     5,     6,    -1,  1297,  1298,
    1299,  1300,  1301,    -1,    -1,  1304,    91,    81,    82,    83,
      84,    85,    86,    87,    -1,    32,    -1,   413,    -1,    -1,
      -1,  1320,  1321,  1322,    -1,    -1,    -1,   423,    -1,   425,
     426,    -1,    49,    43,    -1,   791,   432,    -1,   434,    56,
    1339,  1340,    59,    60,    -1,    -1,    -1,    -1,   444,    59,
      60,   447,    -1,    -1,    -1,    -1,    73,   838,    -1,    -1,
      -1,    -1,    -1,   459,    -1,    -1,    83,  1366,    -1,    -1,
      -1,   467,  1371,    -1,    -1,    -1,    -1,    -1,    95,    96,
      -1,    91,    -1,    -1,     3,     4,     5,     6,   869,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   493,   494,   495,
     496,   497,    -1,    -1,   860,   501,    -1,   863,    -1,     3,
       4,     5,     6,   509,   510,     9,    -1,   513,    -1,   515,
     516,   517,   518,   879,    43,    -1,   522,    -1,    -1,  1428,
    1429,   527,  1431,    -1,   530,    -1,    -1,    -1,    32,    -1,
      59,    60,   923,    -1,    -1,    -1,   542,   520,    -1,    43,
    1449,  1450,   525,  1452,  1453,    49,  1455,    -1,    -1,    -1,
    1006,    -1,    56,  1009,    -1,    59,    60,    -1,    -1,    -1,
     566,    -1,    91,    -1,  1020,    -1,     4,     5,    -1,    73,
    1026,  1027,    -1,   556,    -1,    -1,    -1,    -1,    -1,    83,
     563,    -1,  1491,  1492,  1493,    -1,    -1,    91,    -1,    -1,
      -1,    95,    96,    -1,    32,    -1,    -1,  1506,  1507,    -1,
      -1,    -1,    -1,    -1,   610,    -1,   612,    -1,    -1,    -1,
      -1,    49,   618,   619,   620,   621,    -1,   860,    56,    -1,
     863,    59,    60,   606,   607,    -1,   609,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   640,    73,   879,    -1,    -1,    -1,
      -1,    -1,  1033,    -1,  1035,    83,    -1,    -1,    -1,    -1,
      -1,  1560,  1561,  1562,    -1,    -1,    -1,    95,    96,    -1,
      -1,    -1,    -1,  1119,  1120,  1121,  1122,    -1,    -1,    -1,
      -1,   677,  1128,   679,  1130,  1131,    -1,    -1,    -1,    -1,
       3,     4,     5,     6,   690,    -1,   692,   693,   694,    -1,
      -1,    -1,    -1,    -1,    -1,  1604,  1605,    -1,    -1,   705,
      -1,    -1,    -1,   709,    -1,    -1,    -1,    -1,  1617,  1618,
      -1,     4,     5,    -1,   697,   698,     9,    40,    41,    -1,
      43,    -1,   728,   706,    -1,     3,     4,     5,     6,    -1,
      -1,     9,    -1,    56,    -1,  1126,    59,    60,  1129,    32,
      -1,    -1,     1,    -1,     3,     4,     5,     6,     7,     8,
       9,  1660,  1118,    -1,    32,    -1,    15,    -1,  1124,    -1,
      -1,    -1,  1005,    56,    -1,    43,    59,    60,    -1,   775,
      29,   777,    31,    32,    33,  1099,   782,    -1,    56,    38,
      73,    59,    60,    -1,    43,   791,   792,    -1,    47,  1032,
      83,    50,  1701,  1702,  1703,    73,    -1,    56,  1254,  1255,
      59,    60,    95,  1169,  1713,    83,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    91,    73,    -1,    -1,    95,    -1,    -1,
      -1,    -1,    -1,    -1,    83,   831,   832,   833,    -1,    -1,
      -1,    -1,    91,   839,    -1,   841,    95,    -1,    -1,    -1,
      99,  1297,  1298,  1299,  1300,  1754,    -1,    -1,  1304,    -1,
      -1,    -1,   835,    -1,   860,    -1,    -1,   863,   864,   865,
     866,   867,   868,    -1,    -1,    -1,   872,     3,     4,     5,
       6,    -1,    -1,   879,    -1,  1118,    -1,    -1,    -1,    -1,
      -1,  1124,    -1,    -1,    -1,    -1,  1210,   870,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   902,    -1,    -1,   905,
     906,   907,    -1,   909,    -1,   911,    -1,    43,    -1,     3,
       4,     5,     6,    -1,   920,   921,   922,    -1,    -1,    -1,
      56,    -1,    -1,    59,    60,   931,    -1,    63,    -1,   912,
    1296,   914,    -1,    -1,    -1,    -1,    -1,    73,    -1,  1305,
       4,     5,    -1,    -1,    -1,     9,    -1,    83,    -1,    43,
      -1,    -1,    -1,    -1,    -1,    91,    50,  1323,  1324,    95,
      -1,    -1,    -1,    -1,    -1,    59,    60,  1358,    32,    -1,
      -1,  1337,  1428,  1429,    -1,  1431,   982,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,     3,     4,     5,     6,    -1,    83,
       9,    -1,    56,  1236,    -1,    59,    60,    91,    -1,  1005,
    1006,  1244,    -1,  1009,    -1,   988,   989,    -1,   991,    73,
    1016,    -1,    -1,    32,  1020,    -1,  1022,    -1,    -1,    83,
    1026,  1027,  1028,    -1,    43,    -1,  1032,    -1,  1034,    -1,
      49,    95,    -1,    -1,    -1,  1491,  1492,    56,  1021,  1430,
      59,    60,     4,     5,     3,     4,     5,     9,     7,     8,
       9,    -1,    -1,  1296,    73,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1305,  1454,    83,    -1,    -1,    -1,    -1,  1435,
      32,    -1,    91,    32,    -1,    -1,    95,    96,    -1,    38,
    1323,  1324,    -1,    -1,    -1,  1451,    -1,  1093,    -1,  1095,
    1096,    -1,    -1,    -1,    56,    -1,    -1,    59,    60,    -1,
      59,    60,    79,    80,    81,    82,    83,    84,    85,    86,
      87,    73,  1118,  1119,  1120,  1121,  1122,  1123,  1124,    -1,
      -1,    83,  1128,    -1,  1130,  1131,  1132,    -1,  1494,  1495,
    1136,    -1,    -1,    95,    -1,  1141,  1142,  1143,  1144,    -1,
       3,     4,     5,     6,  1127,    -1,     9,     3,     4,     5,
       6,    -1,  1158,    -1,    -1,  1161,  1162,    -1,  1164,    -1,
      -1,    -1,    -1,  1169,  1170,    -1,  1172,    76,    77,    32,
      79,    80,    81,    82,    83,    84,    85,    86,    87,  1185,
      43,  1187,    -1,    -1,  1550,    -1,    49,    43,    -1,  1195,
      -1,    -1,  1435,    56,    50,    -1,    59,    60,    -1,    -1,
      -1,    -1,    -1,    59,    60,    -1,    -1,    -1,    -1,    -1,
      73,    -1,    -1,    -1,    -1,    -1,  1222,  1223,    -1,  1225,
      83,    -1,    -1,    -1,  1230,    -1,    -1,    83,    91,    -1,
    1236,    -1,    95,    96,    -1,    91,    -1,  1603,  1244,  1605,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1254,  1255,
    1256,  1494,  1495,    -1,    -1,    -1,    -1,  1240,    -1,   279,
     280,   281,   282,   283,   284,    -1,   286,   287,   288,   289,
     290,   291,   292,   293,   294,   295,   296,   297,   298,   299,
     300,   301,   302,   303,   304,   305,   306,   307,    -1,   309,
    1296,  1297,  1298,  1299,  1300,  1301,    -1,    -1,  1304,  1305,
      -1,    -1,     3,     4,     5,     6,    -1,  1550,    -1,    -1,
      -1,    -1,    -1,    -1,  1320,  1321,  1322,  1323,  1324,  1302,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,  1333,    -1,    -1,
      -1,  1337,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    1346,    -1,    43,    -1,    -1,    -1,    -1,    -1,  1714,  1332,
      -1,    -1,    -1,  1359,    -1,    56,     4,    -1,    59,    60,
      -1,  1367,  1345,    -1,    65,    -1,    14,    -1,    -1,    -1,
      -1,    -1,    73,    -1,    -1,    23,    24,    -1,     3,     4,
       5,     6,    83,    31,    32,    -1,    34,    -1,    36,  1372,
      91,    -1,    -1,  1376,    95,    -1,    -1,    45,    -1,    -1,
      -1,    -1,    -1,     3,     4,     5,     6,    32,    -1,    -1,
      58,    -1,    60,    -1,    -1,    -1,    -1,    -1,    43,    -1,
      -1,    69,  1428,  1429,    49,  1431,    74,  1433,  1411,  1435,
      -1,    56,    -1,    -1,    59,    60,    -1,    -1,    -1,    87,
      40,    41,    -1,    43,    92,  1451,    -1,    95,    73,    97,
    1456,    -1,    -1,  1459,    -1,    -1,    56,    -1,    83,    59,
      60,    -1,    -1,    -1,    -1,    -1,    91,    -1,    -1,    -1,
      95,    96,    -1,    -1,    -1,     3,     4,     5,     6,    -1,
    1463,  1464,    -1,    -1,    -1,  1491,  1492,  1493,  1494,  1495,
      -1,    -1,   140,    -1,   142,  1501,   144,    -1,   146,   147,
       3,     4,     5,     6,   152,    -1,    -1,   155,   156,   157,
      -1,    -1,    -1,    -1,    -1,    43,  1499,  1500,    -1,    -1,
      -1,    -1,  1505,   171,    -1,    -1,    -1,   175,    56,    -1,
      -1,    59,    60,   181,   182,    -1,    -1,    65,    -1,    -1,
      43,  1547,    -1,    -1,  1550,    73,    -1,    50,    -1,    -1,
      -1,    -1,   200,   201,   202,    83,    59,    60,    -1,    -1,
     580,    -1,    -1,    91,    75,    76,    77,    95,    79,    80,
      81,    82,    83,    84,    85,    86,    87,    -1,    -1,    -1,
      83,    -1,   230,   603,    -1,    -1,    -1,    -1,    91,    -1,
      -1,   611,    -1,    -1,    -1,    -1,    -1,  1603,  1604,  1605,
      -1,    -1,    -1,    -1,    -1,    -1,     3,     4,     5,     6,
      -1,     1,     9,     3,     4,     5,     6,     7,     8,     9,
      -1,    -1,   270,    -1,    -1,    15,    -1,    -1,    -1,    -1,
      -1,    -1,  1615,    -1,    -1,    32,    -1,    -1,    -1,    29,
      -1,    31,    32,    33,    -1,    -1,    43,    -1,    38,    39,
      -1,    -1,    49,    43,  1660,    -1,    -1,    47,    48,    56,
      50,    -1,    59,    60,   312,   313,    56,    -1,    -1,    59,
      60,    -1,    -1,    63,    -1,    65,    73,    -1,    -1,    -1,
      -1,    -1,    -1,    73,    -1,    -1,    83,    -1,    -1,    -1,
      -1,    -1,    -1,    83,    91,  1701,  1702,  1703,    95,    96,
      -1,    91,    -1,    -1,    -1,    95,    -1,    -1,  1714,   357,
      -1,    -1,   360,    -1,   362,    -1,    -1,   365,   366,    -1,
      -1,   111,    -1,   371,    -1,    -1,    -1,   375,   376,    -1,
      -1,    -1,     3,     4,     5,     6,     7,     8,     9,    -1,
      -1,    -1,    -1,   391,    15,    -1,    -1,    -1,    -1,    -1,
      -1,     3,     4,     5,     6,    -1,    -1,     9,    29,    -1,
      31,    32,    33,    -1,    -1,   413,    -1,    38,    -1,    -1,
      -1,    -1,    43,    -1,    -1,   423,    47,   425,   426,    50,
      32,     4,     5,    -1,   432,    56,   434,    -1,    59,    60,
      -1,    43,    -1,    -1,    -1,    -1,   444,    49,    -1,   447,
      -1,    -1,    73,    -1,    56,    -1,    -1,    59,    60,    32,
      -1,   459,    83,    -1,    -1,    -1,    -1,    -1,    -1,   467,
      91,    73,    -1,    -1,    95,    -1,    49,    -1,    99,    -1,
      -1,    83,    -1,    56,    -1,    -1,    59,    60,    -1,    91,
      -1,    -1,    -1,    95,    96,   493,   494,   495,   496,   497,
      73,    -1,    -1,   501,    -1,    -1,    -1,    -1,    -1,    -1,
      83,   509,   510,    -1,    -1,   513,    -1,   515,   516,   517,
     518,    -1,    95,    96,   522,    -1,    -1,    -1,    -1,   527,
      -1,    -1,   530,    -1,     1,    -1,     3,     4,     5,     6,
       7,     8,     9,    -1,   542,    -1,   916,   917,    15,    -1,
      -1,    -1,    -1,   551,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    29,    -1,    31,    32,    33,    -1,   566,    -1,
      -1,    38,    39,    -1,    -1,    -1,    43,    -1,    -1,    -1,
      47,    48,    -1,    50,    -1,    -1,    -1,    -1,    -1,    56,
      -1,    -1,    59,    60,    -1,    -1,    63,    -1,    65,    -1,
      -1,    -1,    -1,    58,    -1,    -1,    73,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   612,    -1,    83,    -1,    -1,    -1,
     618,   619,   620,   621,    91,    -1,    -1,    82,    95,     1,
      85,     3,     4,     5,     6,     7,     8,     9,    -1,    -1,
      -1,    -1,   640,    15,   111,    79,    80,    81,    82,    83,
      84,    85,    86,    87,   109,    -1,   111,    29,    -1,    31,
      32,    33,    -1,    -1,    -1,    -1,    38,    39,    -1,    -1,
      -1,    43,    -1,    -1,    -1,    47,    48,    -1,    50,   677,
      -1,   679,    -1,    -1,    56,    -1,    -1,    59,    60,    -1,
      -1,    63,    -1,    65,   692,   693,   694,    -1,    -1,    -1,
      -1,    73,    -1,    -1,    -1,    -1,    -1,   705,    -1,    -1,
      -1,    83,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    91,
      -1,    -1,   720,    95,    -1,    -1,   181,    -1,    -1,    -1,
     728,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   111,
      -1,    -1,    -1,    -1,    -1,   200,   201,   202,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   210,    -1,    -1,    -1,     1,
      -1,     3,     4,     5,     6,     7,     8,     9,    -1,    -1,
      -1,    -1,    -1,    15,    -1,   230,    -1,   775,    -1,   777,
      -1,    -1,    -1,    -1,    -1,   783,    28,    29,    -1,    31,
      32,    33,    -1,   791,   792,    -1,    38,    -1,    -1,    -1,
      -1,    43,   257,    -1,    46,    47,    48,    -1,    50,    -1,
      -1,    -1,    -1,    -1,    56,    57,    -1,    59,    60,    -1,
      -1,    63,   277,    -1,    -1,    -1,    -1,     4,     5,    -1,
      -1,    73,     9,   831,   832,   833,    -1,     3,     4,     5,
       6,    83,    -1,   841,    -1,    -1,    -1,    -1,    -1,    91,
      -1,    -1,    -1,    95,    -1,    32,    -1,    99,    -1,    -1,
      -1,    -1,   860,    -1,    -1,   863,   864,   865,   866,   867,
     868,    -1,    49,    -1,   872,    -1,    -1,    43,    -1,    56,
      -1,   879,    59,    60,    50,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    59,    60,    -1,    73,     3,     4,     5,
       6,    -1,    -1,     9,   902,    -1,    83,   905,   906,   907,
      -1,   909,    -1,   911,    -1,   370,   371,    83,    95,    96,
      -1,    -1,   920,   921,   922,    91,    32,    -1,    -1,    -1,
      -1,    -1,    -1,   931,    -1,   390,   391,    43,    -1,    -1,
      -1,     1,    -1,     3,     4,     5,     6,     7,     8,     9,
      56,    -1,    -1,    59,    60,    15,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    73,    -1,    29,
     425,    31,    32,    33,    -1,    -1,    -1,    83,    38,    39,
      -1,    -1,    -1,    43,   982,    91,    -1,    47,    48,    95,
      50,    -1,    -1,    -1,    -1,    -1,    56,    -1,    -1,    59,
      60,    -1,    -1,    63,    -1,    65,    -1,  1005,  1006,    -1,
      -1,  1009,    -1,    73,    -1,    -1,    -1,    -1,  1016,    -1,
      -1,    -1,  1020,    83,  1022,    -1,    -1,    -1,  1026,  1027,
    1028,    91,    -1,    -1,  1032,    95,  1034,    -1,   493,    -1,
     495,   496,    -1,    -1,    -1,    -1,    -1,     3,     4,     5,
       6,   111,    -1,    -1,   509,   510,    -1,    -1,   513,    -1,
     515,   516,   517,   518,    -1,    -1,    -1,   522,    -1,    -1,
      -1,    -1,   527,    -1,    -1,   530,    32,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    43,    -1,    -1,
      -1,    -1,    -1,    49,    -1,  1093,    -1,  1095,  1096,    -1,
      56,    -1,    -1,    59,    60,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,     4,     5,  1113,    -1,    73,     9,    -1,
    1118,  1119,  1120,  1121,  1122,  1123,  1124,    83,    -1,    -1,
    1128,    -1,  1130,  1131,  1132,    91,    -1,    -1,  1136,    95,
      96,    32,    -1,  1141,  1142,  1143,  1144,    -1,     1,    -1,
      -1,     4,     5,    -1,    -1,     8,     9,  1155,    49,    -1,
    1158,    -1,    15,  1161,  1162,    56,  1164,    -1,    59,    60,
      -1,  1169,  1170,    -1,  1172,    -1,    29,    -1,    31,    32,
      -1,    -1,    73,    -1,    -1,    38,    -1,  1185,    -1,  1187,
      -1,    -1,    83,    -1,    47,    -1,    -1,  1195,    -1,    -1,
      -1,    -1,    -1,    56,    95,    96,    59,    60,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    86,    87,  1222,  1223,    -1,  1225,    -1,    -1,
      -1,    -1,  1230,    -1,    -1,    -1,    -1,    -1,  1236,     3,
       4,     5,     6,     7,     8,     9,  1244,    -1,    -1,    13,
      -1,    15,    -1,   708,   709,    -1,  1254,  1255,  1256,    -1,
      -1,    -1,    -1,    -1,    -1,    29,    -1,    31,    32,    -1,
      -1,    -1,    -1,   728,    38,    -1,    -1,    -1,    -1,    43,
      -1,    -1,    -1,    47,    -1,    49,    -1,    -1,    -1,    -1,
      -1,    -1,    56,    -1,    -1,    59,    60,    -1,  1296,  1297,
    1298,  1299,  1300,  1301,    -1,    -1,  1304,  1305,    -1,    73,
      -1,     3,     4,     5,     6,    -1,    -1,    -1,    -1,    83,
      -1,    -1,  1320,  1321,  1322,  1323,  1324,    91,    -1,    -1,
    1328,    95,    96,    -1,    -1,  1333,   791,    -1,    -1,  1337,
      32,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1346,    -1,
      -1,    43,    -1,    -1,    -1,    -1,    -1,    49,    -1,    -1,
      -1,    -1,    -1,    -1,    56,    -1,     4,    59,    60,  1367,
      -1,    -1,    -1,    -1,    -1,    -1,   831,   832,   833,    -1,
      -1,    73,    -1,   838,   839,    -1,   841,     4,     5,    -1,
      -1,    83,     9,    31,    32,    -1,    34,    -1,    36,    91,
      -1,    -1,    -1,    95,    96,   860,    -1,    45,   863,   864,
     865,   866,   867,   868,   869,    32,    -1,   872,    -1,    -1,
      58,    -1,    60,    -1,   879,  1423,    -1,    -1,    -1,    -1,
    1428,  1429,    49,  1431,    -1,  1433,    -1,  1435,    -1,    56,
      -1,    -1,    59,    60,    82,    -1,   901,    85,    -1,    -1,
      -1,    -1,    -1,  1451,    -1,    -1,    73,    -1,  1456,    -1,
      -1,  1459,    74,    75,    76,    77,    83,    79,    80,    81,
      82,    83,    84,    85,    86,    87,    -1,    -1,    95,    96,
      -1,    -1,    -1,    -1,    -1,     3,     4,     5,     6,     3,
       4,     5,     6,  1491,  1492,  1493,  1494,  1495,    -1,   137,
     138,    -1,   140,  1501,    -1,    -1,    -1,    -1,   146,   147,
      -1,    -1,   150,   151,   152,    -1,    -1,   155,   156,   157,
      -1,    -1,    -1,    -1,   162,    43,    -1,    -1,    -1,    43,
      -1,    -1,    50,   171,    -1,    -1,    50,   175,    -1,    -1,
      -1,    59,    60,   181,   182,    59,    60,    -1,    -1,  1547,
      -1,    -1,  1550,     1,    -1,     3,     4,     5,     6,     7,
       8,     9,   200,   201,   202,    83,    -1,    15,    -1,    83,
      -1,    -1,   210,    91,    -1,    -1,    -1,    91,  1033,  1034,
    1035,    29,    -1,    31,    32,    33,    -1,    -1,    -1,    -1,
      38,    -1,   230,    -1,  1592,    43,    -1,    -1,    -1,    47,
      48,    -1,    50,    -1,    -1,  1603,  1604,  1605,    56,    -1,
      -1,    59,    60,    -1,    -1,    63,    -1,    65,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    73,    -1,    -1,    -1,    -1,
      -1,    -1,   270,    -1,    -1,    83,    -1,    -1,    -1,   277,
      -1,    -1,    -1,    91,    -1,    -1,    -1,    95,    -1,    -1,
      -1,     3,     4,     5,     6,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1660,  1118,  1119,  1120,  1121,  1122,  1123,  1124,
      -1,  1126,    -1,  1128,  1129,  1130,  1131,  1132,    -1,    -1,
      -1,  1136,    -1,    -1,    -1,     4,     5,  1142,  1143,  1144,
       9,    43,    -1,    -1,    -1,    -1,    -1,    -1,    50,    -1,
      -1,    -1,    -1,  1701,  1702,  1703,   344,    59,    60,    -1,
      -1,    -1,    -1,    32,  1169,    -1,  1714,    -1,    -1,    -1,
      -1,    -1,   360,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      49,    83,   370,    -1,    -1,    -1,    -1,    56,   376,    91,
      59,    60,     1,    -1,     3,     4,     5,     6,     7,     8,
       9,    -1,   390,    -1,    73,    -1,    15,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    83,    -1,    -1,    -1,    -1,    -1,
      29,    -1,    31,    32,    -1,   413,    95,    96,    -1,    38,
      -1,    -1,    -1,    -1,    43,    -1,    -1,   425,    47,    -1,
      -1,    50,    -1,    -1,    -1,    -1,   434,    56,   436,    -1,
      59,    60,    -1,    -1,    63,   443,   444,    -1,    -1,   447,
      -1,    -1,    -1,    -1,    73,   453,   454,   455,    -1,    -1,
      -1,   459,    -1,    -1,    83,    -1,    -1,    -1,    -1,   467,
      -1,    -1,    91,    -1,    -1,    -1,    95,    -1,    -1,    -1,
      -1,  1296,  1297,  1298,  1299,  1300,  1301,    -1,    -1,  1304,
    1305,    -1,    -1,    -1,    -1,   493,   494,   495,   496,    -1,
      -1,    -1,    -1,   501,    -1,  1320,  1321,  1322,  1323,  1324,
      -1,   509,   510,    -1,    -1,   513,    -1,   515,   516,   517,
     518,    -1,  1337,    -1,   522,    -1,    -1,    -1,    -1,   527,
      -1,    -1,   530,    -1,    -1,    70,    71,    72,    73,    74,
      75,    76,    77,  1358,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    -1,    -1,     3,     4,     5,     6,    -1,
       8,     9,    10,    11,    12,    -1,    14,    15,   566,    -1,
       3,     4,     5,     6,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    29,    30,    31,    32,    33,    -1,    35,    36,    37,
      38,    -1,    40,    41,    42,    43,    44,    45,    -1,    47,
      -1,    49,    -1,    51,    52,    53,    54,    55,    56,    -1,
      43,    59,    60,  1428,  1429,  1430,  1431,    -1,    -1,    -1,
    1435,    -1,    70,    56,    -1,    73,    59,    60,    -1,    -1,
     628,   629,   630,    81,    82,    83,  1451,    -1,    -1,    -1,
      73,    89,    90,    91,    -1,   643,    -1,    95,    96,    -1,
      83,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    91,    -1,
      -1,    -1,    95,    -1,   112,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1491,  1492,  1493,  1494,
    1495,     1,    -1,    -1,     4,     5,    -1,    -1,     8,     9,
      -1,   689,    -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   701,    -1,   703,    -1,   705,    -1,    29,
      -1,    31,    32,    -1,    -1,    -1,    -1,    -1,    38,    -1,
      40,    41,    -1,    -1,    -1,    -1,    -1,    47,    -1,    49,
     728,    -1,    -1,    -1,    -1,  1550,    56,    -1,    -1,    59,
      60,    -1,    62,    -1,    -1,    -1,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    76,    77,    78,    79,
      80,    81,    82,    83,    84,    85,    86,    -1,    -1,    89,
      90,    91,    -1,    93,    -1,    -1,    96,   775,    -1,    -1,
      -1,    -1,    -1,    -1,   782,    -1,    -1,    -1,  1603,    -1,
    1605,    -1,   112,   791,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,     3,     4,     5,     6,     7,     8,     9,    -1,
      -1,    -1,    13,    -1,    15,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,     4,    -1,    -1,    -1,    -1,    -1,    29,    -1,
      31,    32,    -1,   831,   832,   833,    -1,    38,    -1,    -1,
     838,   839,    43,   841,    -1,  1660,    47,    -1,    49,    31,
      32,    -1,    34,    -1,    36,    56,    -1,   855,    59,    60,
      -1,    -1,   860,    45,    -1,   863,   864,   865,   866,   867,
     868,    -1,    73,    -1,   872,    -1,    58,    -1,    60,    -1,
      -1,   879,    83,    -1,    -1,    -1,  1701,  1702,  1703,    -1,
      91,    -1,    -1,    -1,    95,    96,    -1,    -1,    -1,  1714,
      -1,    -1,    -1,    85,   902,   200,   201,    -1,    -1,    -1,
       3,     4,     5,     6,     7,     8,     9,    -1,    -1,    -1,
      13,    -1,    15,    75,    76,    77,    78,    79,    80,    81,
      82,    83,    84,    85,    86,    87,    29,    -1,    31,    32,
      -1,    -1,    -1,    -1,    -1,    38,    -1,    -1,    -1,    -1,
      43,    -1,    -1,    -1,    47,    -1,    49,    -1,   140,    -1,
      -1,    -1,    -1,    56,   146,   147,    59,    60,    -1,   151,
     152,    -1,    -1,   155,   156,   157,    -1,    -1,    -1,    -1,
      73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   171,
      83,    -1,    -1,   175,    -1,    -1,    -1,    -1,    91,   181,
     182,    -1,    95,    96,     3,     4,     5,     6,    -1,    -1,
       3,     4,     5,     6,     7,     8,     9,    -1,   200,   201,
     202,    -1,    15,    -1,    -1,    -1,    -1,    -1,  1026,  1027,
    1028,    -1,    -1,    32,  1032,  1033,    29,    -1,    31,    32,
      -1,    -1,    -1,    -1,    43,    38,    -1,    -1,   230,    -1,
      43,    -1,    -1,    -1,    47,    -1,    49,    56,    -1,    -1,
      59,    60,    -1,    56,    -1,    -1,    59,    60,    -1,    -1,
      -1,    -1,    -1,    -1,    73,    -1,    -1,    -1,    -1,    -1,
      73,    -1,    -1,    -1,    83,    -1,    -1,    -1,   270,    -1,
      83,    -1,    91,    -1,    -1,    -1,    95,    -1,    91,    -1,
      -1,    -1,    95,    96,    72,    73,    74,    75,    76,    77,
      -1,    79,    80,    81,    82,    83,    84,    85,    86,    87,
    1118,  1119,  1120,  1121,  1122,  1123,  1124,    -1,  1126,    -1,
    1128,  1129,  1130,  1131,  1132,    -1,    -1,    -1,  1136,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,     3,     4,     5,     6,
       7,     8,     9,    -1,    -1,    -1,     4,     5,    15,    -1,
      -1,     9,    -1,  1161,  1162,    -1,  1164,    -1,    -1,    -1,
      -1,  1169,  1170,    -1,  1172,    32,    -1,    -1,    -1,    -1,
      -1,    38,    -1,    -1,    32,    -1,    43,    -1,    -1,   371,
      47,    -1,    49,    -1,   376,    -1,    -1,    -1,    -1,    56,
      -1,    49,    59,    60,    -1,    -1,    -1,    -1,    56,   391,
      -1,    59,    60,    -1,    -1,   510,    73,    -1,   513,    -1,
     515,   516,    -1,    -1,    -1,    73,    83,    -1,    -1,    -1,
      -1,    -1,   527,    -1,    91,    83,    -1,    -1,    95,    96,
      -1,    92,    -1,   425,    95,    -1,    97,    95,    96,    -1,
      -1,    -1,   434,    -1,    -1,    -1,  1254,  1255,  1256,    -1,
      -1,    -1,   444,    -1,    34,   447,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   459,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   467,    -1,    -1,    58,    -1,
      -1,   142,    -1,   144,    -1,    -1,    -1,    -1,  1296,  1297,
    1298,  1299,  1300,  1301,    -1,    -1,  1304,  1305,    -1,    -1,
      -1,   493,   494,   495,   496,    -1,    -1,    -1,    -1,   501,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   509,   510,    -1,
      -1,   513,    -1,   515,   516,   517,    -1,    -1,    -1,  1337,
     522,    -1,    -1,    -1,    -1,   527,    -1,    -1,   530,    -1,
      -1,    -1,    -1,     3,     4,     5,     6,     7,     8,     9,
    1358,  1359,    -1,    -1,    -1,    15,    -1,    -1,    -1,  1367,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      86,    87,    32,    -1,   566,   155,   156,   157,    38,    -1,
      -1,    -1,    -1,    43,    -1,    -1,    -1,    47,    -1,    49,
      -1,    -1,    -1,    -1,    -1,    -1,    56,    -1,    -1,    59,
      60,   181,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    73,    -1,    -1,    -1,    -1,    -1,    -1,
     200,   201,   202,    83,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    91,    -1,    -1,    -1,    95,    96,     3,     4,     5,
       6,    -1,    -1,  1451,    -1,    -1,  1454,    -1,  1456,    -1,
     230,  1459,     3,     4,     5,     6,     7,     8,     9,    -1,
     321,   322,    -1,    -1,    15,    -1,    32,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   335,    -1,   337,    43,    29,   340,
      31,    32,   343,    -1,    -1,   346,    -1,    38,    -1,   350,
      56,    -1,    43,    59,    60,    -1,    47,   358,   690,    -1,
      -1,    -1,    -1,    -1,    -1,    56,    -1,    73,    59,    60,
      -1,    -1,    63,    -1,   375,    -1,    -1,    83,    -1,    -1,
      -1,    -1,    73,    -1,    -1,    91,   831,   832,    -1,    95,
      -1,    -1,    83,   313,    -1,    -1,   728,    -1,     4,     5,
      91,     7,     8,     9,    95,    -1,    -1,    13,    -1,    15,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   864,
     865,   866,   867,    29,    -1,    31,    32,   872,    -1,    -1,
      -1,   432,    38,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    47,   362,    49,    -1,   365,   366,    -1,    -1,    -1,
      56,    -1,    -1,    59,    60,  1603,  1604,  1605,    -1,   791,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    73,    -1,    -1,
       4,     5,    -1,    -1,     8,     9,    -1,    83,    -1,    -1,
      -1,    15,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    95,
      96,    -1,    -1,    -1,    -1,    29,    -1,    31,    32,   831,
     832,   833,    -1,    -1,    38,   425,    -1,   839,    -1,   841,
      -1,    -1,  1660,    47,    -1,    49,    -1,    -1,    -1,    -1,
      -1,    -1,    56,    -1,    -1,    59,    60,    -1,   860,    -1,
      -1,    -1,   864,   865,    -1,    -1,    -1,    -1,    -1,    73,
     872,   542,    -1,    -1,    -1,    -1,    -1,   879,    -1,    83,
      -1,    -1,    -1,  1701,  1702,  1703,    -1,    -1,    -1,    -1,
      -1,    95,    96,    -1,    -1,    -1,  1714,    -1,    -1,    -1,
     902,    -1,    -1,   493,    -1,   495,   496,   497,    -1,    -1,
      -1,     4,     5,    -1,    -1,     8,     9,    -1,    -1,   509,
     510,    -1,    15,   513,    -1,   515,   516,   517,   518,    -1,
      -1,    -1,   522,    -1,    -1,    -1,    29,   527,    31,    32,
     530,   612,    -1,    -1,    -1,    38,    -1,    -1,    -1,    -1,
      -1,    -1,   196,    -1,    47,    -1,    -1,   628,   629,    -1,
      -1,    -1,    -1,    56,    -1,    -1,    59,    60,    61,   640,
      -1,    -1,    -1,    -1,   645,   646,    -1,   648,   649,   650,
     651,   652,   653,   654,   655,   656,   657,   658,   659,   660,
     661,   662,   663,   664,   665,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    95,    -1,  1119,  1120,  1121,  1122,    -1,    -1,
      -1,    -1,    -1,  1128,    -1,  1130,  1131,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,  1142,  1143,  1144,
      -1,    -1,  1034,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,     3,     4,     5,     6,     7,     8,     9,
      -1,    -1,    -1,    13,    -1,    15,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,
      -1,    31,    32,    -1,    -1,    -1,    -1,    -1,    38,    -1,
      -1,    -1,    -1,    43,    -1,    -1,    -1,    47,    -1,   679,
      -1,    -1,    -1,    -1,    -1,    -1,    56,    -1,    -1,    59,
      60,    -1,   692,   693,   694,    -1,   777,    -1,    -1,    -1,
      -1,    -1,    -1,    73,    -1,   705,  1118,  1119,  1120,  1121,
    1122,  1123,    -1,    83,    -1,    -1,  1128,    -1,  1130,  1131,
    1132,    91,    -1,    -1,  1136,    95,    -1,    -1,   728,    -1,
     384,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    83,    84,    85,    86,    87,  1161,
    1162,    -1,  1164,    -1,    -1,    -1,    -1,  1169,  1170,    -1,
    1172,    -1,    -1,    -1,     3,     4,     5,     6,     7,     8,
       9,    -1,  1297,  1298,  1299,  1300,    15,    -1,    -1,  1304,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      29,   791,    31,    32,    -1,  1320,  1321,    -1,    -1,    38,
      -1,    -1,    -1,    -1,    43,    -1,    -1,    -1,    47,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    56,    -1,    -1,
      59,    60,    -1,    -1,    63,   906,   907,    -1,   909,   483,
     484,   831,   832,   833,    73,    -1,    -1,    -1,    -1,    -1,
      -1,   841,    -1,    -1,    83,    -1,    -1,    -1,    -1,    -1,
      -1,   112,    91,    -1,    -1,    -1,    95,    -1,    -1,    -1,
     860,    -1,    -1,   863,   864,   865,   866,   867,   868,    -1,
      -1,    -1,   872,    -1,    -1,    -1,    -1,    -1,    -1,   879,
      -1,    -1,    -1,    -1,  1296,  1297,  1298,    -1,    -1,    -1,
      -1,    -1,  1304,  1305,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,  1428,  1429,    -1,  1431,    -1,    -1,    -1,
      -1,    -1,    -1,   994,    -1,    -1,     3,     4,     5,     6,
     920,   921,   922,    -1,    -1,  1337,    -1,    -1,    -1,    -1,
      -1,   931,    -1,    -1,    -1,   196,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  1026,  1027,  1359,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  1367,    43,    -1,    -1,   613,
     221,    -1,   616,    -1,    -1,    -1,  1491,  1492,    -1,    56,
      -1,    -1,    59,    60,    -1,    -1,    -1,    -1,    65,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    73,    -1,   642,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    83,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    91,  1005,  1006,    -1,    95,  1009,
      -1,    -1,    -1,   667,    -1,  1096,    -1,    -1,  1099,   673,
    1020,   675,   676,    -1,    -1,    -1,  1026,  1027,  1028,     4,
       5,    -1,  1032,     8,     9,    -1,    -1,    -1,    -1,  1451,
      15,    -1,    -1,    -1,  1456,    -1,    -1,  1459,    -1,  1130,
    1131,   705,    -1,    -1,    29,    -1,    31,    32,   712,    -1,
      -1,    -1,    -1,    38,    -1,    -1,    -1,    -1,   722,    -1,
      -1,    -1,    47,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    56,    -1,   344,    59,    60,    -1,   741,   742,   743,
     744,    -1,   746,   747,   748,   749,   750,   751,   752,   753,
     754,   755,   756,   757,   758,   759,   760,   761,   762,   763,
     764,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1118,  1119,
    1120,  1121,  1122,  1123,  1124,    -1,    -1,    -1,  1128,  1210,
    1130,  1131,  1132,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1142,  1143,  1144,    -1,    -1,  1228,    -1,  1230,
      -1,    -1,    -1,    -1,     3,     4,     5,     6,     7,     8,
       9,  1161,   423,    -1,    -1,    -1,    15,    -1,   822,  1169,
      -1,    -1,    -1,    -1,     4,     5,  1701,  1702,     8,     9,
      29,    -1,    31,    32,    -1,    15,    -1,   841,    -1,    38,
      -1,  1603,  1604,  1605,    43,    -1,    -1,    -1,    47,    -1,
      -1,   855,    32,    -1,    -1,    -1,    -1,    56,    38,    -1,
      59,    60,    -1,    -1,    -1,    -1,    65,    47,    -1,    49,
      -1,    -1,  1222,  1223,    73,  1225,    56,    -1,    -1,    59,
      60,    -1,    -1,    32,    83,    -1,  1236,    -1,    -1,    -1,
     501,    -1,    91,    73,  1244,    -1,    95,    -1,  1660,    -1,
      -1,    -1,    -1,    83,  1254,  1255,  1256,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    95,    96,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    83,    84,    85,    86,    87,  1701,
    1702,  1703,    -1,    -1,   948,    -1,  1296,  1297,  1298,  1299,
    1300,  1301,  1714,    -1,  1304,  1305,    -1,    -1,    -1,     3,
       4,     5,     6,    -1,    -1,     9,    -1,    -1,    -1,    -1,
    1320,  1321,  1322,  1323,  1324,    -1,    -1,    -1,    -1,    -1,
      -1,   985,   986,    -1,    -1,    -1,    -1,  1337,    32,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1000,    -1,  1002,    43,
    1004,    -1,    -1,    -1,    -1,    -1,   617,   618,   619,   620,
     621,    -1,    56,    -1,    -1,    59,    60,    -1,    -1,   630,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    73,
      -1,    -1,   643,    -1,    -1,    -1,    14,    -1,    -1,    83,
      -1,    -1,    -1,  1047,    -1,    23,    24,    91,    -1,    -1,
      -1,    95,    -1,    31,    32,    -1,    34,    -1,    -1,     3,
       4,     5,     6,    -1,    -1,   676,     3,     4,     5,     6,
      -1,    -1,     9,    -1,    -1,    -1,  1080,    -1,  1428,  1429,
      -1,  1431,    -1,   694,    -1,  1435,    -1,    -1,    32,    -1,
     701,    69,   703,    -1,   705,    32,    -1,    -1,    -1,    43,
      -1,  1451,    -1,    -1,    -1,    -1,    43,    -1,    -1,    -1,
      -1,    -1,    56,    -1,    -1,    59,    60,    -1,    -1,    56,
      -1,    -1,    59,    60,    -1,    -1,    -1,    -1,    -1,    73,
      -1,    -1,    -1,    -1,  1138,  1139,    73,    -1,    -1,    83,
      -1,  1491,  1492,  1493,  1494,  1495,    83,    91,    -1,    -1,
     128,    95,   130,    -1,    91,    -1,  1160,    -1,    95,   137,
     138,    -1,    -1,    -1,    -1,  1596,    -1,    -1,   146,   147,
      -1,    -1,   150,   151,   152,    -1,   154,   155,   156,   157,
      -1,    -1,    -1,    -1,     3,     4,     5,     6,     7,     8,
       9,    -1,    -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,
    1550,    -1,  1206,  1207,    -1,   362,    -1,    -1,   365,   366,
      29,    -1,    31,    32,    -1,    -1,    -1,    -1,    -1,    38,
      -1,    -1,   833,    -1,    43,    -1,    -1,    -1,    47,    -1,
     841,    -1,    -1,    -1,    -1,    -1,    -1,    56,    -1,    -1,
      59,    60,    -1,    -1,    -1,     3,     4,     5,     6,     7,
       8,     9,    -1,  1603,    73,  1605,    -1,    15,    -1,    -1,
      -1,    -1,  1266,    -1,    83,    -1,    -1,    -1,   246,   247,
    1701,  1702,    91,    -1,    32,    -1,    95,    -1,    -1,    -1,
      38,    -1,    -1,    -1,    -1,    43,    -1,    -1,    -1,    47,
    1294,    49,   270,    -1,   905,    -1,    -1,    -1,    56,    -1,
     911,    59,    60,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    1660,    -1,    -1,    -1,    -1,    73,    -1,    -1,    -1,    -1,
      -1,  1325,    -1,    -1,    -1,    83,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    91,    -1,   313,   493,    95,   495,   496,
     497,    -1,    -1,    -1,    -1,  1349,    -1,    -1,    -1,    -1,
      -1,  1701,  1702,  1703,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,  1714,    -1,    73,    74,    75,    76,
      77,   982,    79,    80,    81,    82,    83,    84,    85,    86,
      87,    -1,   360,  1387,   362,    -1,    -1,   365,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,     3,     4,     5,
       6,     7,     8,     9,    -1,  1016,    -1,    -1,    -1,    15,
      -1,  1022,  1416,    -1,    -1,    -1,    -1,  1028,    -1,    -1,
      -1,  1425,    -1,    29,    -1,    31,    32,    -1,    -1,    -1,
      -1,    -1,    38,  1437,    -1,   413,    -1,    43,    -1,    -1,
      -1,    47,    -1,  1447,  1448,    -1,    -1,    -1,    -1,    -1,
      56,    -1,    -1,    59,    60,    -1,   434,    -1,   436,     4,
       5,    -1,    -1,     8,     9,    -1,   444,    73,    -1,   447,
      15,    -1,    -1,  1477,    -1,    -1,    -1,    83,    -1,    -1,
      -1,   459,  1093,    -1,  1095,    91,    -1,    32,    -1,    95,
      -1,    -1,    -1,    38,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    47,    -1,    49,    -1,    -1,    -1,  1512,    -1,
      -1,    56,  1123,    -1,    59,    60,    -1,    -1,    -1,    -1,
      -1,  1132,    -1,    -1,    -1,    -1,    -1,    -1,    73,    -1,
    1141,    -1,    -1,    -1,    -1,   692,   693,   694,    83,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   705,    -1,
      95,    96,    -1,    -1,  1558,  1559,     3,     4,     5,     6,
      -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   550,   551,  1185,    -1,  1187,    -1,    -1,    -1,
      -1,  1585,    -1,    -1,  1195,    32,    -1,    -1,   566,    71,
      72,    73,    74,    75,    76,    77,    43,    79,    80,    81,
      82,    83,    84,    85,    86,    87,    -1,    -1,    -1,    56,
      -1,    -1,    59,    60,    -1,    -1,    -1,    -1,    -1,  1623,
      -1,    -1,    -1,    -1,    -1,    -1,    73,    -1,    -1,    -1,
     608,    -1,   610,    -1,   791,    -1,    83,    -1,     3,     4,
       5,     6,    -1,    -1,    91,  1256,    -1,    -1,    95,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1660,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    32,    -1,    -1,
      -1,    -1,    -1,    -1,   831,   832,   833,    -1,    43,    -1,
      -1,  1685,    -1,    -1,   841,    -1,    -1,    -1,    -1,    -1,
    1301,    56,    -1,    -1,    59,    60,    -1,    -1,    -1,    -1,
      -1,   679,    -1,    -1,    -1,    -1,    -1,    -1,    73,    -1,
      -1,   689,   690,    -1,   692,   693,    -1,    -1,    83,    -1,
      -1,    -1,  1333,    -1,    -1,    -1,    91,    -1,    -1,    -1,
      95,     3,     4,     5,     6,  1346,     8,     9,    10,    11,
      12,    -1,    14,    15,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,    30,    31,
      32,    33,    -1,    35,    36,    37,    38,    -1,    40,    41,
      42,    43,    44,    45,   931,    47,    -1,    49,    -1,    51,
      52,    53,    54,    55,    56,    -1,    -1,    59,    60,    -1,
      -1,    -1,  1796,    -1,    -1,    -1,    -1,   775,    70,    -1,
      -1,    73,    -1,    -1,   782,   783,    -1,    -1,    -1,    81,
      82,    83,    -1,    -1,   792,    -1,    -1,    89,    90,    91,
      -1,    -1,  1433,    95,    96,    -1,    -1,     3,     4,     5,
       6,    -1,    -1,     9,    -1,    -1,     3,     4,     5,     6,
     112,    -1,     9,    -1,    -1,    -1,    -1,    -1,  1005,  1006,
      -1,    -1,  1009,    -1,    -1,    -1,    32,    -1,    -1,    -1,
      -1,    -1,    -1,  1020,    -1,    32,    -1,    43,    -1,  1026,
    1027,  1028,    -1,    -1,    -1,  1032,    43,    -1,    -1,    -1,
      56,    -1,  1493,    59,    60,    -1,    -1,    -1,    -1,    56,
    1501,    -1,    59,    60,    -1,    -1,    -1,    73,     3,     4,
       5,     6,    -1,    -1,     9,    -1,    73,    83,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    91,    83,    -1,    -1,    95,
      -1,    -1,    -1,   901,    91,    -1,    -1,    32,    95,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1547,    -1,    43,    -1,
      -1,    -1,   920,   921,   922,   923,    -1,    -1,    -1,    -1,
      -1,    56,    -1,   931,    59,    60,    -1,    -1,    -1,    -1,
      -1,  1118,  1119,  1120,  1121,  1122,  1123,  1124,    73,    -1,
      -1,  1128,    -1,  1130,  1131,  1132,    -1,    -1,    83,     3,
       4,     5,     6,    -1,    -1,     9,    91,    -1,    -1,    -1,
      95,    -1,    -1,    -1,     3,     4,     5,     6,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    32,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    43,
      -1,    -1,    -1,    32,    -1,    -1,    -1,  1005,  1006,    -1,
      -1,  1009,    56,    -1,    43,    59,    60,     3,     4,     5,
       6,    -1,  1020,    -1,    -1,    -1,    -1,    56,    -1,    73,
      59,    60,    -1,    -1,  1032,    -1,    -1,    -1,    -1,    83,
      -1,    -1,    -1,    -1,    73,    -1,    32,    91,    -1,    -1,
      -1,    95,    -1,    -1,    83,    -1,    -1,    43,    -1,  1236,
      -1,    -1,    91,    -1,    -1,    -1,    95,  1244,    -1,    -1,
      56,    -1,  1703,    59,    60,    -1,    -1,  1254,  1255,  1256,
      13,    -1,    -1,    -1,    -1,    -1,    -1,    73,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    83,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    91,    -1,    -1,    -1,    95,
      -1,    -1,    -1,    -1,    -1,  1113,    -1,    -1,    -1,  1296,
    1297,  1298,  1299,  1300,  1301,    -1,    -1,  1304,  1305,    -1,
      -1,    -1,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    79,    80,    81,    82,
      83,    84,    85,    86,    87,    -1,    -1,  1155,    -1,    -1,
    1158,     4,     5,  1161,     7,     8,     9,    -1,    -1,    -1,
      -1,    -1,    15,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    29,    -1,    31,    32,
      -1,    -1,    -1,    -1,    -1,    38,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    47,    -1,    -1,    50,    -1,    -1,
      -1,    -1,    -1,    56,    -1,    -1,    59,    60,    -1,    -1,
      -1,    -1,    -1,    -1,  1222,  1223,    -1,  1225,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,     4,     5,  1236,     7,
       8,     9,    -1,    -1,    -1,    13,  1244,    15,    -1,    -1,
      -1,  1428,  1429,    -1,  1431,    -1,  1254,  1255,    -1,    -1,
      -1,    29,    -1,    31,    32,    -1,    -1,    -1,    -1,    -1,
      38,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    47,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    56,    -1,
      -1,    59,    60,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    83,    84,    85,    86,    87,
      -1,    -1,    -1,    -1,  1491,  1492,  1493,  1494,  1495,    -1,
       1,    -1,     3,     4,     5,     6,     7,     8,     9,    -1,
    1328,    -1,    13,    -1,    15,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    26,    -1,    28,    -1,    -1,
      -1,    32,    -1,    -1,    -1,    -1,    -1,    38,    -1,    -1,
      -1,  1359,    43,    -1,    -1,    -1,    47,    -1,    49,    -1,
      -1,    -1,    -1,  1550,    -1,    56,    -1,    -1,    59,    60,
      61,    62,    63,    -1,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
      81,    82,    83,    84,    85,    86,    87,    -1,    89,    90,
      91,    -1,    93,    94,    95,    96,    97,    -1,    -1,    -1,
      -1,    -1,   103,   104,    -1,  1423,    -1,    -1,   109,   110,
     111,    -1,   113,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    75,    76,    77,    78,    79,    80,    81,
      82,    83,    84,    85,    86,    87,  1454,     1,  1456,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    -1,
      14,    15,    16,    -1,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      -1,    35,    36,    37,    38,    -1,    40,    41,    42,    43,
      44,    45,    46,    47,    48,    -1,    -1,    51,    52,    53,
      54,    55,    56,    -1,    -1,    59,    60,    61,    -1,    63,
      64,    -1,    -1,    -1,    -1,    -1,    70,    -1,    -1,    73,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    83,
      -1,    -1,    -1,    -1,    -1,    89,    90,    91,    -1,    -1,
      -1,    95,    -1,    97,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   111,   112,     1,
      -1,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    -1,    14,    15,    16,    -1,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    -1,    35,    36,    37,    38,    -1,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    -1,    -1,    51,
      52,    53,    54,    55,    56,    -1,    -1,    59,    60,    61,
      -1,    63,    64,    -1,    -1,    -1,    -1,    -1,    70,    -1,
      -1,    73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,
      82,    83,    -1,    -1,    -1,    -1,    -1,    89,    90,    91,
      -1,    -1,    -1,    95,     1,    97,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    -1,
     112,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    29,    30,    31,    32,    33,    -1,    35,    36,
      37,    38,    -1,    40,    41,    42,    43,    44,    45,    -1,
      47,    -1,    49,    -1,    51,    52,    53,    54,    55,    56,
      -1,    -1,    59,    60,    61,    -1,    -1,    64,    -1,    -1,
      -1,    -1,    -1,    70,    -1,    -1,    73,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    82,    83,    -1,    -1,    -1,
      -1,    -1,    89,    90,    91,    -1,    -1,    -1,    95,    96,
       1,    -1,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,   112,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,    30,
      31,    32,    33,    -1,    35,    36,    37,    38,    -1,    40,
      41,    42,    43,    44,    45,    -1,    47,    -1,    49,    -1,
      51,    52,    53,    54,    55,    56,    -1,    -1,    59,    60,
      61,    -1,    -1,    64,    -1,    -1,    -1,    -1,    -1,    70,
      -1,    -1,    73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      81,    82,    83,    -1,    -1,    -1,    -1,    -1,    89,    90,
      91,    -1,    -1,    -1,    95,    96,     1,    -1,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,   112,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    29,    30,    31,    32,    33,    -1,
      35,    36,    37,    38,    -1,    40,    41,    42,    43,    44,
      45,    -1,    47,    -1,    -1,    -1,    51,    52,    53,    54,
      55,    56,    -1,    -1,    59,    60,    -1,    -1,    -1,    64,
      -1,    -1,    -1,    -1,    -1,    70,    -1,    -1,    73,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    83,    -1,
      -1,    -1,    -1,    -1,    89,    90,    91,    -1,    -1,     1,
      95,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    -1,    14,    15,    -1,   110,    -1,   112,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,    30,    31,
      32,    33,    -1,    35,    36,    37,    38,    -1,    40,    41,
      42,    43,    44,    45,    -1,    47,    -1,    -1,    -1,    51,
      52,    53,    54,    55,    56,    -1,    -1,    59,    60,    61,
      -1,    63,    64,    -1,    -1,    -1,    -1,    -1,    70,    -1,
      -1,    73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,
      82,    83,    -1,    -1,    -1,    -1,    -1,    89,    90,    91,
      -1,    -1,     1,    95,     3,     4,     5,     6,    -1,     8,
       9,    10,    11,    12,    -1,    14,    15,    -1,    -1,    -1,
     112,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      29,    30,    31,    -1,    33,    -1,    35,    36,    37,    38,
      -1,    40,    41,    42,    43,    44,    45,    -1,    47,    -1,
      -1,    -1,    51,    52,    53,    54,    55,    56,    -1,    -1,
      59,    60,    61,    -1,    -1,    64,    -1,    -1,    -1,    -1,
      -1,    70,    -1,    -1,    73,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    81,    82,    83,    -1,    -1,    -1,    -1,    -1,
      89,    90,    91,    -1,    -1,    -1,    95,    96,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      86,    87,   111,   112,     1,    -1,     3,     4,     5,     6,
      -1,     8,     9,    10,    11,    12,    -1,    14,    15,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    29,    30,    31,    32,    33,    -1,    35,    36,
      37,    38,    -1,    40,    41,    42,    43,    44,    45,    -1,
      47,    -1,    -1,    -1,    51,    52,    53,    54,    55,    56,
      -1,    -1,    59,    60,    61,    -1,    -1,    64,    -1,    -1,
      -1,    -1,    -1,    70,    -1,    -1,    73,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    82,    83,    -1,    -1,    -1,
      -1,    -1,    89,    90,    91,    -1,    -1,     1,    95,     3,
       4,     5,     6,    -1,     8,     9,    10,    11,    12,    -1,
      14,    15,    -1,    -1,    -1,   112,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    29,    30,    31,    -1,    33,
      -1,    35,    36,    37,    38,    -1,    40,    41,    42,    43,
      44,    45,    -1,    47,    -1,    -1,    -1,    51,    52,    53,
      54,    55,    56,    -1,    -1,    59,    60,    61,    -1,    -1,
      64,    -1,    -1,    -1,    -1,    -1,    70,    -1,    -1,    73,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    83,
      -1,    -1,    -1,    -1,    -1,    89,    90,    91,    -1,    -1,
      -1,    95,    96,     1,    -1,     3,     4,     5,     6,    -1,
       8,     9,    10,    11,    12,    -1,    14,    15,   112,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    29,    30,    31,    -1,    33,    -1,    35,    36,    37,
      38,    -1,    40,    41,    42,    43,    44,    45,    -1,    47,
      -1,    -1,    -1,    51,    52,    53,    54,    55,    56,    -1,
      -1,    59,    60,    61,    -1,    -1,    64,    -1,    -1,    -1,
      -1,    -1,    70,    -1,    -1,    73,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    81,    82,    83,    -1,    -1,    -1,    -1,
      -1,    89,    90,    91,    -1,    -1,    -1,    95,     1,    -1,
       3,     4,     5,     6,   102,     8,     9,    10,    11,    12,
      -1,    14,    15,    -1,   112,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    29,    30,    31,    -1,
      33,    -1,    35,    36,    37,    38,    -1,    40,    41,    42,
      43,    44,    45,    -1,    47,    -1,    -1,    -1,    51,    52,
      53,    54,    55,    56,    -1,    -1,    59,    60,    61,    -1,
      -1,    64,    -1,    -1,    -1,    -1,    -1,    70,    -1,    -1,
      73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    82,
      83,    -1,    -1,    -1,    -1,    -1,    89,    90,    91,    -1,
      -1,     1,    95,     3,     4,     5,     6,    -1,     8,     9,
      10,    11,    12,    -1,    14,    15,    -1,    -1,   111,   112,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,
      30,    31,    -1,    33,    -1,    35,    36,    37,    38,    -1,
      40,    41,    42,    43,    44,    45,    -1,    47,    -1,    -1,
      -1,    51,    52,    53,    54,    55,    56,    -1,    -1,    59,
      60,    61,    -1,    -1,    64,    -1,    -1,    -1,    -1,    -1,
      70,    -1,    -1,    73,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    81,    82,    83,    -1,    -1,    -1,    -1,    -1,    89,
      90,    91,    -1,    -1,     1,    95,     3,     4,     5,     6,
      -1,     8,     9,    10,    11,    12,    -1,    14,    15,    -1,
      -1,   111,   112,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    29,    30,    31,    32,    33,    -1,    35,    36,
      37,    38,    -1,    40,    41,    42,    43,    44,    45,    -1,
      47,    -1,    -1,    -1,    51,    52,    53,    54,    55,    56,
      -1,    -1,    59,    60,    61,    -1,    -1,    64,    -1,    -1,
      -1,    -1,    -1,    70,    -1,    -1,    73,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    82,    83,    -1,    -1,    -1,
      -1,    -1,    89,    90,    91,    -1,    -1,     1,    95,     3,
       4,     5,     6,    -1,     8,     9,    10,    11,    12,    -1,
      14,    15,    -1,    -1,    -1,   112,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    29,    30,    31,    32,    33,
      -1,    35,    36,    37,    38,    -1,    40,    41,    42,    43,
      44,    45,    -1,    47,    -1,    -1,    -1,    51,    52,    53,
      54,    55,    56,    -1,    -1,    59,    60,    -1,    -1,    63,
      64,    -1,    -1,    -1,    -1,    -1,    70,    -1,    -1,    73,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    83,
      -1,    -1,    -1,    -1,    -1,    89,    90,    91,    -1,    -1,
       1,    95,     3,     4,     5,     6,    -1,     8,     9,    10,
      11,    12,    -1,    14,    15,    -1,    -1,    -1,   112,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,    30,
      31,    -1,    33,    -1,    35,    36,    37,    38,    -1,    40,
      41,    42,    43,    44,    45,    -1,    47,    -1,    -1,    -1,
      51,    52,    53,    54,    55,    56,    -1,    -1,    59,    60,
      61,    -1,    -1,    64,    -1,    -1,    -1,    -1,    -1,    70,
      -1,    -1,    73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      81,    82,    83,    -1,    -1,    -1,    -1,    -1,    89,    90,
      91,    -1,    -1,     1,    95,     3,     4,     5,     6,    -1,
       8,     9,    10,    11,    12,    -1,    14,    15,    -1,    -1,
      -1,   112,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    29,    30,    31,    -1,    33,    -1,    35,    36,    37,
      38,    -1,    40,    41,    42,    43,    44,    45,    -1,    47,
      -1,    -1,    -1,    51,    52,    53,    54,    55,    56,    -1,
      -1,    59,    60,    -1,    -1,    -1,    64,    65,    -1,    -1,
      -1,    -1,    70,    -1,    -1,    73,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    81,    82,    83,    -1,    -1,    -1,    -1,
      -1,    89,    90,    91,    -1,    -1,     1,    95,     3,     4,
       5,     6,    -1,     8,     9,    10,    11,    12,    -1,    14,
      15,    -1,    -1,    -1,   112,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    29,    30,    31,    -1,    33,    -1,
      35,    36,    37,    38,    -1,    40,    41,    42,    43,    44,
      45,    -1,    47,    -1,    -1,    -1,    51,    52,    53,    54,
      55,    56,    -1,    -1,    59,    60,    -1,    -1,    -1,    64,
      -1,    -1,    -1,    -1,    -1,    70,    -1,    -1,    73,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    83,    -1,
      -1,    -1,    -1,    -1,    89,    90,    91,    -1,    -1,     1,
      95,     3,     4,     5,     6,    -1,     8,     9,    10,    11,
      12,    -1,    14,    15,    -1,   110,    -1,   112,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,    30,    31,
      -1,    33,    -1,    35,    36,    37,    38,    -1,    40,    41,
      42,    43,    44,    45,    -1,    47,    -1,    -1,    -1,    51,
      52,    53,    54,    55,    56,    -1,    -1,    59,    60,    -1,
      -1,    -1,    64,    -1,    -1,    -1,    -1,    -1,    70,    -1,
      -1,    73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,
      82,    83,    -1,    -1,    -1,    -1,    -1,    89,    90,    91,
      -1,    -1,     1,    95,     3,     4,     5,     6,    -1,     8,
       9,    10,    11,    12,    -1,    14,    15,    -1,    -1,    -1,
     112,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      29,    30,    31,    -1,    33,    -1,    35,    36,    37,    38,
      -1,    40,    41,    42,    43,    44,    45,    -1,    47,    -1,
      -1,    -1,    51,    52,    53,    54,    55,    56,    -1,    -1,
      59,    60,    -1,    -1,    -1,    64,    -1,    -1,    -1,    -1,
      -1,    70,    -1,    -1,    73,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    81,    82,    83,    -1,    -1,    -1,    -1,    -1,
      89,    90,    91,    -1,    -1,     1,    95,     3,     4,     5,
       6,    -1,     8,     9,    10,    11,    12,    -1,    14,    15,
      -1,    -1,    -1,   112,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    29,    30,    31,    -1,    33,    -1,    35,
      36,    37,    38,    -1,    40,    41,    42,    43,    44,    45,
      -1,    47,    -1,    -1,    -1,    51,    52,    53,    54,    55,
      56,    -1,    -1,    59,    60,    -1,    -1,    -1,    64,    -1,
      -1,    -1,    -1,    -1,    70,    -1,    -1,    73,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    81,    82,    83,    -1,    -1,
      -1,    -1,    -1,    89,    90,    91,    -1,    -1,    -1,    95,
       3,     4,     5,     6,    -1,     8,     9,    10,    11,    12,
      -1,    14,    15,    -1,    -1,    -1,   112,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    29,    30,    31,    -1,
      33,    -1,    35,    36,    37,    38,    -1,    40,    41,    42,
      43,    44,    45,    -1,    47,    -1,    -1,    -1,    51,    52,
      53,    54,    55,    56,    -1,    -1,    59,    60,    -1,    -1,
      -1,    64,    -1,    -1,    -1,    -1,    -1,    70,    -1,    -1,
      73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    82,
      83,    -1,    -1,    -1,    -1,    -1,    89,    90,    91,    -1,
      -1,    -1,    95,     3,     4,     5,     6,    -1,     8,     9,
      10,    11,    12,    -1,    14,    15,    -1,    -1,    -1,   112,
     113,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,
      30,    31,    -1,    33,    -1,    35,    36,    37,    38,    -1,
      40,    41,    42,    43,    44,    45,    -1,    47,    -1,    -1,
      -1,    51,    52,    53,    54,    55,    56,    -1,    -1,    59,
      60,    -1,    -1,    -1,    64,    -1,    -1,    -1,    -1,    -1,
      70,    -1,    -1,    73,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    81,    82,    83,    -1,    -1,    -1,    -1,    -1,    89,
      90,    91,    -1,    -1,    -1,    95,     3,     4,     5,     6,
      -1,     8,     9,    10,    11,    12,    -1,    14,    15,    -1,
      -1,    -1,   112,   113,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    29,    30,    31,    -1,    33,    -1,    35,    36,
      37,    38,    -1,    40,    41,    42,    43,    44,    45,    -1,
      47,    -1,    -1,    -1,    51,    52,    53,    54,    55,    56,
      -1,    -1,    59,    60,    -1,    -1,    -1,    64,    -1,    -1,
      -1,    -1,    -1,    70,    -1,    -1,    73,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    82,    83,    -1,    -1,    -1,
      -1,    -1,    89,    90,    91,    -1,    -1,    -1,    95,     3,
       4,     5,     6,    -1,     8,     9,    10,    11,    12,    -1,
      14,    15,    -1,    -1,    -1,   112,   113,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    29,    30,    31,    -1,    33,
      -1,    35,    36,    37,    38,    -1,    40,    41,    42,    43,
      44,    45,    -1,    47,    -1,    -1,    -1,    51,    52,    53,
      54,    55,    56,    -1,    -1,    59,    60,    -1,    -1,    -1,
      64,    -1,    -1,    -1,    -1,    -1,    70,    -1,    -1,    73,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    83,
      -1,    -1,    -1,    -1,    -1,    89,    90,    91,    -1,    -1,
      -1,    95,     3,     4,     5,     6,    -1,     8,     9,    10,
      11,    12,    -1,    14,    15,    -1,    -1,    -1,   112,   113,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,    30,
      31,    -1,    33,    -1,    35,    36,    37,    38,    -1,    40,
      41,    42,    43,    44,    45,    -1,    47,    -1,    -1,    -1,
      51,    52,    53,    54,    55,    56,    -1,    -1,    59,    60,
      -1,    -1,    -1,    64,    -1,    -1,    -1,    -1,    -1,    70,
      -1,    -1,    73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      81,    82,    83,    -1,    -1,    -1,    -1,    -1,    89,    90,
      91,    -1,    -1,    -1,    95,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    83,    84,    85,    86,    87,
      -1,   112,   113,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    -1,    14,    15,    16,    -1,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    -1,    35,    36,    37,    38,    -1,
      40,    41,    42,    43,    44,    45,    46,    47,    48,    -1,
      -1,    51,    52,    53,    54,    55,    56,    -1,    -1,    59,
      60,    61,    -1,    63,    64,    -1,    -1,    -1,    -1,    -1,
      70,    -1,    -1,    73,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    81,    82,    83,    -1,    -1,    -1,    -1,    -1,    89,
      90,    91,    -1,    -1,    -1,    95,    -1,    97,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    -1,    14,
      15,    16,   112,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    -1,
      35,    36,    37,    38,    -1,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    -1,    -1,    51,    52,    53,    54,
      55,    56,    -1,    -1,    59,    60,    -1,    -1,    63,    64,
      -1,    -1,    -1,    -1,    -1,    70,    -1,    -1,    73,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    83,    -1,
      -1,    -1,    -1,    -1,    89,    90,    91,    -1,    -1,    -1,
      95,    -1,    97,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    15,    -1,   112,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,
      30,    31,    32,    33,    -1,    35,    36,    37,    38,    -1,
      40,    41,    42,    43,    44,    45,    -1,    47,    -1,    49,
      -1,    51,    52,    53,    54,    55,    56,    -1,    -1,    59,
      60,    -1,    -1,    -1,    64,    -1,    -1,    -1,    -1,    -1,
      70,    -1,    -1,    73,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    81,    82,    83,    -1,    -1,    -1,    -1,    -1,    89,
      90,    91,    -1,    -1,    -1,    95,    96,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      -1,    -1,   112,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    29,    30,    31,    32,    33,    -1,    35,
      36,    37,    38,    -1,    40,    41,    42,    43,    44,    45,
      -1,    47,    -1,    49,    -1,    51,    52,    53,    54,    55,
      56,    -1,    -1,    59,    60,    -1,    -1,    -1,    64,    -1,
      -1,    -1,    -1,    -1,    70,    -1,    -1,    73,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    81,    82,    83,    -1,    -1,
      -1,    -1,    -1,    89,    90,    91,    -1,    -1,    -1,    95,
      96,     3,     4,     5,     6,    -1,     8,     9,    10,    11,
      12,    -1,    14,    15,    -1,    -1,   112,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,    30,    31,
      32,    33,    -1,    35,    36,    37,    38,    -1,    40,    41,
      42,    43,    44,    45,    -1,    47,    -1,    -1,    -1,    51,
      52,    53,    54,    55,    56,    -1,    -1,    59,    60,    -1,
      -1,    -1,    64,    -1,    -1,    -1,    -1,    -1,    70,    -1,
      -1,    73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,
      82,    83,    -1,    -1,    -1,    -1,    -1,    89,    90,    91,
      -1,    -1,    -1,    95,     3,     4,     5,     6,    -1,     8,
       9,    10,    11,    12,    -1,    14,    15,    -1,    -1,    -1,
     112,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      29,    30,    31,    32,    33,    -1,    35,    36,    37,    38,
      -1,    40,    41,    42,    43,    44,    45,    -1,    47,    -1,
      -1,    -1,    51,    52,    53,    54,    55,    56,    -1,    -1,
      59,    60,    -1,    -1,    -1,    64,    -1,    -1,    -1,    -1,
      -1,    70,    -1,    -1,    73,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    81,    82,    83,    -1,    -1,    -1,    -1,    -1,
      89,    90,    91,    -1,    -1,    -1,    95,     3,     4,     5,
       6,    -1,     8,     9,    10,    11,    12,    -1,    14,    15,
      -1,    -1,    -1,   112,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    29,    30,    31,    32,    33,    -1,    35,
      36,    37,    38,    -1,    40,    41,    42,    43,    44,    45,
      -1,    47,    -1,    -1,    -1,    51,    52,    53,    54,    55,
      56,    -1,    -1,    59,    60,    -1,    -1,    -1,    64,    -1,
      -1,    -1,    -1,    -1,    70,    -1,    -1,    73,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    81,    82,    83,    -1,    -1,
      -1,    -1,    -1,    89,    90,    91,    -1,    -1,    -1,    95,
       3,     4,     5,     6,    -1,     8,     9,    10,    11,    12,
      -1,    14,    15,    -1,    -1,    -1,   112,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    29,    30,    31,    -1,
      33,    -1,    35,    36,    37,    38,    -1,    40,    41,    42,
      43,    44,    45,    -1,    47,    -1,    -1,    -1,    51,    52,
      53,    54,    55,    56,    -1,    -1,    59,    60,    -1,    -1,
      63,    64,    -1,    -1,    -1,    -1,    -1,    70,    -1,    -1,
      73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    82,
      83,    -1,    -1,    -1,    -1,    -1,    89,    90,    91,    -1,
      -1,    -1,    95,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    -1,    14,    15,    -1,    -1,    -1,   112,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,
      30,    31,    32,    33,    -1,    35,    36,    37,    38,    -1,
      40,    41,    42,    43,    44,    45,    -1,    47,    -1,    -1,
      -1,    51,    52,    53,    54,    55,    56,    -1,    -1,    59,
      60,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      70,    -1,    -1,    73,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    81,    82,    83,    -1,    -1,    -1,    -1,    -1,    89,
      90,    91,    -1,    -1,    -1,    95,     3,     4,     5,     6,
      -1,     8,     9,    10,    11,    12,    -1,    14,    15,    -1,
      -1,    -1,   112,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    29,    30,    31,    32,    33,    -1,    35,    36,
      37,    38,    -1,    40,    41,    42,    43,    44,    45,    -1,
      47,    -1,    -1,    -1,    51,    52,    53,    54,    55,    56,
      -1,    -1,    59,    60,    -1,    -1,    -1,    64,    -1,    -1,
      -1,    -1,    -1,    70,    -1,    -1,    73,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    82,    83,    -1,    -1,    -1,
      -1,    -1,    89,    90,    91,    -1,    -1,    -1,    95,     3,
       4,     5,     6,    -1,     8,     9,    10,    11,    12,    -1,
      14,    15,    -1,    -1,    -1,   112,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    29,    30,    31,    -1,    33,
      -1,    35,    36,    37,    38,    -1,    40,    41,    42,    43,
      44,    45,    -1,    47,    -1,    -1,    -1,    51,    52,    53,
      54,    55,    56,    -1,    -1,    59,    60,    -1,    -1,    -1,
      64,    -1,    -1,    -1,    -1,    -1,    70,    -1,    -1,    73,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    83,
      -1,    -1,    -1,    -1,    -1,    89,    90,    91,    -1,    -1,
      -1,    95,     3,     4,     5,     6,    -1,     8,     9,    10,
      11,    12,    -1,    14,    15,    -1,    -1,    -1,   112,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,    30,
      31,    -1,    33,    -1,    35,    36,    37,    38,    -1,    40,
      41,    42,    43,    44,    45,    -1,    47,    -1,    -1,    -1,
      51,    52,    53,    54,    55,    56,    -1,    -1,    59,    60,
      61,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    70,
      -1,    -1,    73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      81,    82,    83,    -1,    -1,    -1,    -1,    -1,    89,    90,
      91,    -1,    -1,    -1,    95,     3,     4,     5,     6,    -1,
       8,     9,    10,    11,    12,    -1,    14,    15,    -1,    -1,
      -1,   112,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    29,    30,    31,    -1,    33,    -1,    35,    36,    37,
      38,    -1,    40,    41,    42,    43,    44,    45,    -1,    47,
      -1,    -1,    -1,    51,    52,    53,    54,    55,    56,    -1,
      -1,    59,    60,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    70,    -1,    -1,    73,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    81,    82,    83,    -1,    -1,    -1,    -1,
      -1,    89,    90,    91,    -1,    -1,    -1,    95,    96,     3,
       4,     5,     6,    -1,     8,     9,    10,    11,    12,    -1,
      14,    15,    -1,    -1,   112,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    29,    30,    31,    -1,    33,
      -1,    35,    36,    37,    38,    -1,    40,    41,    42,    43,
      44,    45,    -1,    47,    -1,    -1,    -1,    51,    52,    53,
      54,    55,    56,    -1,    -1,    59,    60,    -1,    -1,    -1,
      64,    -1,    -1,    -1,    -1,    -1,    70,    -1,    -1,    73,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    83,
      -1,    -1,    -1,    -1,    -1,    89,    90,    91,    -1,    -1,
      -1,    95,     3,     4,     5,     6,    -1,     8,     9,    10,
      11,    12,    -1,    14,    15,    -1,    -1,    -1,   112,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,    30,
      31,    32,    33,    -1,    35,    36,    37,    38,    -1,    40,
      41,    42,    43,    44,    45,    -1,    47,    -1,    -1,    -1,
      51,    52,    53,    54,    55,    56,    -1,    -1,    59,    60,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    70,
      -1,    -1,    73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      81,    82,    83,    -1,    -1,    -1,    -1,    -1,    89,    90,
      91,    -1,    -1,    -1,    95,     3,     4,     5,     6,    -1,
       8,     9,    10,    11,    12,    -1,    14,    15,    -1,    -1,
      -1,   112,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    29,    30,    31,    -1,    33,    -1,    35,    36,    37,
      38,    -1,    40,    41,    42,    43,    44,    45,    -1,    47,
      -1,    -1,    -1,    51,    52,    53,    54,    55,    56,    -1,
      -1,    59,    60,    -1,    -1,    -1,    64,    -1,    -1,    -1,
      -1,    -1,    70,    -1,    -1,    73,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    81,    82,    83,    -1,    -1,    -1,    -1,
      -1,    89,    90,    91,    -1,    -1,    -1,    95,     3,     4,
       5,     6,    -1,     8,     9,    10,    11,    12,    -1,    14,
      15,    -1,    -1,    -1,   112,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    29,    30,    31,    32,    33,    -1,
      35,    36,    37,    38,    -1,    40,    41,    42,    43,    44,
      45,    -1,    47,    -1,    -1,    -1,    51,    52,    53,    54,
      55,    56,    -1,    -1,    59,    60,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    70,    -1,    -1,    73,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    83,    -1,
      -1,    -1,    -1,    -1,    89,    90,    91,    -1,    -1,    -1,
      95,     3,     4,     5,     6,    -1,     8,     9,    10,    11,
      12,    -1,    14,    15,    -1,    -1,    -1,   112,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,    30,    31,
      -1,    33,    -1,    35,    36,    37,    38,    -1,    40,    41,
      42,    43,    44,    45,    -1,    47,    -1,    -1,    -1,    51,
      52,    53,    54,    55,    56,    -1,    -1,    59,    60,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    70,    -1,
      -1,    73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,
      82,    83,    -1,    -1,    -1,    -1,    -1,    89,    90,    91,
      -1,    -1,    -1,    95,     3,     4,     5,     6,    -1,     8,
       9,    10,    11,    12,    -1,    14,    15,    -1,    -1,    -1,
     112,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      29,    30,    31,    -1,    33,    -1,    35,    36,    37,    38,
      -1,    40,    41,    42,    43,    44,    45,    -1,    47,    -1,
      -1,    -1,    51,    52,    53,    54,    55,    56,    -1,    -1,
      59,    60,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    70,    -1,    -1,    73,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    81,    82,    83,    -1,    -1,    -1,    -1,    -1,
      89,    90,    91,    -1,    -1,    -1,    95,     3,     4,     5,
       6,    -1,     8,     9,    10,    11,    12,    -1,    14,    15,
      -1,    -1,    -1,   112,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    29,    30,    31,    -1,    33,    -1,    35,
      36,    37,    38,    -1,    40,    41,    42,    43,    44,    45,
      -1,    47,    -1,    -1,    -1,    51,    52,    53,    54,    55,
      56,    -1,    -1,    59,    60,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    70,    -1,    -1,    73,    -1,     4,
       5,    -1,     7,     8,     9,    81,    82,    83,    13,    -1,
      15,    -1,    -1,    89,    90,    91,    -1,    -1,    -1,    95,
      -1,    -1,    -1,    -1,    29,    -1,    31,    32,    -1,    -1,
      -1,    -1,    -1,    38,     4,     5,   112,     7,     8,     9,
      -1,    -1,    47,    -1,    -1,    15,    -1,    -1,    -1,    -1,
      -1,    56,    -1,    -1,    59,    60,    -1,    -1,    -1,    29,
      -1,    31,    32,    -1,    -1,    -1,    -1,    -1,    38,     4,
       5,    -1,    -1,     8,     9,    -1,    -1,    47,    -1,    -1,
      15,    -1,    -1,    -1,    -1,    -1,    56,    -1,    -1,    59,
      60,    -1,    -1,    -1,    29,    -1,    31,    32,    -1,    -1,
      -1,    -1,    -1,    38,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    47,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    56,    -1,    -1,    59,    60,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    76,    77,    78,    79,
      80,    81,    82,    83,    84,    85,    86,    87,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    83,    84,    85,    86,    87,
      -1,    -1,    -1,   113,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    62,    -1,
      -1,   109,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    86,    87,    62,    -1,    -1,    -1,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    83,    84,    85,    86,    87,
      66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      86,    87,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    -1,    79,    80,    81,    82,    83,
      84,    85,    86,    87
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/share/bison/bison.simple"

/* Skeleton output parser for bison,

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software
   Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* This is the parser code that is written into each bison parser when
   the %semantic_parser declaration is not specified in the grammar.
   It was written by Richard Stallman by simplifying the hairy parser
   used when %semantic_parser is specified.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

#if ! defined (yyoverflow) || defined (YYERROR_VERBOSE)

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# if YYSTACK_USE_ALLOCA
#  define YYSTACK_ALLOC alloca
# else
#  ifndef YYSTACK_USE_ALLOCA
#   if defined (alloca) || defined (_ALLOCA_H)
#    define YYSTACK_ALLOC alloca
#   else
#    ifdef __GNUC__
#     define YYSTACK_ALLOC __builtin_alloca
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC malloc
#  define YYSTACK_FREE free
# endif
#endif /* ! defined (yyoverflow) || defined (YYERROR_VERBOSE) */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (YYLTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
# if YYLSP_NEEDED
  YYLTYPE yyls;
# endif
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAX (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# if YYLSP_NEEDED
#  define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE) + sizeof (YYLTYPE))	\
      + 2 * YYSTACK_GAP_MAX)
# else
#  define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE))				\
      + YYSTACK_GAP_MAX)
# endif

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAX;	\
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif


#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	goto yyacceptlab
#define YYABORT 	goto yyabortlab
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");			\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).

   When YYLLOC_DEFAULT is run, CURRENT is set the location of the
   first token.  By default, to implement support for ranges, extend
   its range to the last symbol.  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)       	\
   Current.last_line   = Rhs[N].last_line;	\
   Current.last_column = Rhs[N].last_column;
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#if YYPURE
# if YYLSP_NEEDED
#  ifdef YYLEX_PARAM
#   define YYLEX		yylex (&yylval, &yylloc, YYLEX_PARAM)
#  else
#   define YYLEX		yylex (&yylval, &yylloc)
#  endif
# else /* !YYLSP_NEEDED */
#  ifdef YYLEX_PARAM
#   define YYLEX		yylex (&yylval, YYLEX_PARAM)
#  else
#   define YYLEX		yylex (&yylval)
#  endif
# endif /* !YYLSP_NEEDED */
#else /* !YYPURE */
# define YYLEX			yylex ()
#endif /* !YYPURE */


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)
/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
#endif /* !YYDEBUG */

/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif

#ifdef YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif
#endif

#line 315 "/usr/share/bison/bison.simple"


/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
#  define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#  define YYPARSE_PARAM_DECL
# else
#  define YYPARSE_PARAM_ARG YYPARSE_PARAM
#  define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
# endif
#else /* !YYPARSE_PARAM */
# define YYPARSE_PARAM_ARG
# define YYPARSE_PARAM_DECL
#endif /* !YYPARSE_PARAM */

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
# ifdef YYPARSE_PARAM
int yyparse (void *);
# else
int yyparse (void);
# endif
#endif

/* YY_DECL_VARIABLES -- depending whether we use a pure parser,
   variables are global, or local to YYPARSE.  */

#define YY_DECL_NON_LSP_VARIABLES			\
/* The lookahead symbol.  */				\
int yychar;						\
							\
/* The semantic value of the lookahead symbol. */	\
YYSTYPE yylval;						\
							\
/* Number of parse errors so far.  */			\
int yynerrs;

#if YYLSP_NEEDED
# define YY_DECL_VARIABLES			\
YY_DECL_NON_LSP_VARIABLES			\
						\
/* Location data for the lookahead symbol.  */	\
YYLTYPE yylloc;
#else
# define YY_DECL_VARIABLES			\
YY_DECL_NON_LSP_VARIABLES
#endif


/* If nonreentrant, generate the variables here. */

#if !YYPURE
YY_DECL_VARIABLES
#endif  /* !YYPURE */

int
yyparse (YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  /* If reentrant, generate the variables here. */
#if YYPURE
  YY_DECL_VARIABLES
#endif  /* !YYPURE */

  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yychar1 = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack. */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;

#if YYLSP_NEEDED
  /* The location stack.  */
  YYLTYPE yylsa[YYINITDEPTH];
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;
#endif

#if YYLSP_NEEDED
# define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
# define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  YYSIZE_T yystacksize = YYINITDEPTH;


  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
#if YYLSP_NEEDED
  YYLTYPE yyloc;
#endif

  /* When reducing, the number of symbols on the RHS of the reduced
     rule. */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;
#if YYLSP_NEEDED
  yylsp = yyls;
#endif
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  */
# if YYLSP_NEEDED
	YYLTYPE *yyls1 = yyls;
	/* This used to be a conditional around just the two extra args,
	   but that might be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yyls1, yysize * sizeof (*yylsp),
		    &yystacksize);
	yyls = yyls1;
# else
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yystacksize);
# endif
	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);
# if YYLSP_NEEDED
	YYSTACK_RELOCATE (yyls);
# endif
# undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
#if YYLSP_NEEDED
      yylsp = yyls + yysize - 1;
#endif

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yychar1 = YYTRANSLATE (yychar);

#if YYDEBUG
     /* We have to keep this `#if YYDEBUG', since we use variables
	which are defined only if `YYDEBUG' is set.  */
      if (yydebug)
	{
	  YYFPRINTF (stderr, "Next token is %d (%s",
		     yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise
	     meaning of a token, for further debugging info.  */
# ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
# endif
	  YYFPRINTF (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %d (%s), ",
	      yychar, yytname[yychar1]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#if YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to the semantic value of
     the lookahead token.  This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

#if YYLSP_NEEDED
  /* Similarly for the default location.  Let the user run additional
     commands if for instance locations are ranges.  */
  yyloc = yylsp[1-yylen];
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
#endif

#if YYDEBUG
  /* We have to keep this `#if YYDEBUG', since we use variables which
     are defined only if `YYDEBUG' is set.  */
  if (yydebug)
    {
      int yyi;

      YYFPRINTF (stderr, "Reducing via rule %d (line %d), ",
		 yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (yyi = yyprhs[yyn]; yyrhs[yyi] > 0; yyi++)
	YYFPRINTF (stderr, "%s ", yytname[yyrhs[yyi]]);
      YYFPRINTF (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif

  switch (yyn) {

case 1:
#line 486 "parse.y"
{ finish_translation_unit (); ;
    break;}
case 2:
#line 488 "parse.y"
{ finish_translation_unit (); ;
    break;}
case 3:
#line 496 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 4:
#line 498 "parse.y"
{ yyval.ttype = NULL_TREE; ggc_collect (); ;
    break;}
case 5:
#line 500 "parse.y"
{ yyval.ttype = NULL_TREE; ggc_collect (); ;
    break;}
case 8:
#line 509 "parse.y"
{ have_extern_spec = true;
		  yyval.ttype = NULL_TREE; ;
    break;}
case 9:
#line 513 "parse.y"
{ have_extern_spec = false; ;
    break;}
case 10:
#line 518 "parse.y"
{ yyval.itype = pedantic;
		  pedantic = 0; ;
    break;}
case 12:
#line 527 "parse.y"
{ if (pending_lang_change) do_pending_lang_change();
		  type_lookups = NULL_TREE; ;
    break;}
case 13:
#line 530 "parse.y"
{ if (! toplevel_bindings_p ())
		  pop_everything (); ;
    break;}
case 14:
#line 536 "parse.y"
{ do_pending_inlines (); ;
    break;}
case 15:
#line 538 "parse.y"
{ do_pending_inlines (); ;
    break;}
case 16:
#line 541 "parse.y"
{ warning ("keyword `export' not implemented, and will be ignored"); ;
    break;}
case 17:
#line 543 "parse.y"
{ do_pending_inlines (); ;
    break;}
case 18:
#line 545 "parse.y"
{ do_pending_inlines (); ;
    break;}
case 19:
#line 547 "parse.y"
{ assemble_asm (yyvsp[-2].ttype); ;
    break;}
case 20:
#line 549 "parse.y"
{ pop_lang_context (); ;
    break;}
case 21:
#line 551 "parse.y"
{ do_pending_inlines (); pop_lang_context (); ;
    break;}
case 22:
#line 553 "parse.y"
{ do_pending_inlines (); pop_lang_context (); ;
    break;}
case 23:
#line 555 "parse.y"
{ push_namespace (yyvsp[-1].ttype); ;
    break;}
case 24:
#line 557 "parse.y"
{ pop_namespace (); ;
    break;}
case 25:
#line 559 "parse.y"
{ push_namespace (NULL_TREE); ;
    break;}
case 26:
#line 561 "parse.y"
{ pop_namespace (); ;
    break;}
case 28:
#line 564 "parse.y"
{ do_toplevel_using_decl (yyvsp[-1].ttype); ;
    break;}
case 30:
#line 567 "parse.y"
{ pedantic = yyvsp[-1].itype; ;
    break;}
case 31:
#line 572 "parse.y"
{ begin_only_namespace_names (); ;
    break;}
case 32:
#line 574 "parse.y"
{
		  end_only_namespace_names ();
		  if (lastiddecl)
		    yyvsp[-1].ttype = lastiddecl;
		  do_namespace_alias (yyvsp[-4].ttype, yyvsp[-1].ttype);
		;
    break;}
case 33:
#line 584 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 34:
#line 586 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 35:
#line 588 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 36:
#line 593 "parse.y"
{ yyval.ttype = build_nt (SCOPE_REF, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 37:
#line 595 "parse.y"
{ yyval.ttype = build_nt (SCOPE_REF, global_namespace, yyvsp[0].ttype); ;
    break;}
case 38:
#line 597 "parse.y"
{ yyval.ttype = build_nt (SCOPE_REF, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 39:
#line 602 "parse.y"
{ begin_only_namespace_names (); ;
    break;}
case 40:
#line 604 "parse.y"
{
		  end_only_namespace_names ();
		  /* If no declaration was found, the using-directive is
		     invalid. Since that was not reported, we need the
		     identifier for the error message. */
		  if (TREE_CODE (yyvsp[-1].ttype) == IDENTIFIER_NODE && lastiddecl)
		    yyvsp[-1].ttype = lastiddecl;
		  do_using_directive (yyvsp[-1].ttype);
		;
    break;}
case 41:
#line 617 "parse.y"
{
		  if (TREE_CODE (yyval.ttype) == IDENTIFIER_NODE)
		    yyval.ttype = lastiddecl;
		  got_scope = yyval.ttype;
		;
    break;}
case 42:
#line 623 "parse.y"
{
		  yyval.ttype = yyvsp[-1].ttype;
		  if (TREE_CODE (yyval.ttype) == IDENTIFIER_NODE)
		    yyval.ttype = lastiddecl;
		  got_scope = yyval.ttype;
		;
    break;}
case 45:
#line 635 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 46:
#line 637 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 47:
#line 642 "parse.y"
{ push_lang_context (yyvsp[0].ttype); ;
    break;}
case 48:
#line 644 "parse.y"
{ if (current_lang_name != yyvsp[0].ttype)
		    error ("use of linkage spec `%D' is different from previous spec `%D'", yyvsp[0].ttype, current_lang_name);
		  pop_lang_context (); push_lang_context (yyvsp[0].ttype); ;
    break;}
case 49:
#line 651 "parse.y"
{ begin_template_parm_list (); ;
    break;}
case 50:
#line 653 "parse.y"
{ yyval.ttype = end_template_parm_list (yyvsp[-1].ttype); ;
    break;}
case 51:
#line 658 "parse.y"
{ begin_specialization();
		  yyval.ttype = NULL_TREE; ;
    break;}
case 54:
#line 669 "parse.y"
{ yyval.ttype = process_template_parm (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 55:
#line 671 "parse.y"
{ yyval.ttype = process_template_parm (yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 56:
#line 676 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 57:
#line 678 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 58:
#line 683 "parse.y"
{ yyval.ttype = finish_template_type_parm (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 59:
#line 685 "parse.y"
{ yyval.ttype = finish_template_type_parm (class_type_node, yyvsp[0].ttype); ;
    break;}
case 60:
#line 690 "parse.y"
{ yyval.ttype = finish_template_template_parm (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 61:
#line 702 "parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 62:
#line 704 "parse.y"
{ yyval.ttype = build_tree_list (groktypename (yyvsp[0].ftype.t), yyvsp[-2].ttype); ;
    break;}
case 63:
#line 706 "parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, yyvsp[0].ftype.t); ;
    break;}
case 64:
#line 708 "parse.y"
{ yyval.ttype = build_tree_list (yyvsp[0].ttype, yyvsp[-2].ftype.t); ;
    break;}
case 65:
#line 710 "parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 66:
#line 712 "parse.y"
{
		  yyvsp[0].ttype = check_template_template_default_arg (yyvsp[0].ttype);
		  yyval.ttype = build_tree_list (yyvsp[0].ttype, yyvsp[-2].ttype);
		;
    break;}
case 67:
#line 720 "parse.y"
{ finish_template_decl (yyvsp[-1].ttype); ;
    break;}
case 68:
#line 722 "parse.y"
{ finish_template_decl (yyvsp[-1].ttype); ;
    break;}
case 69:
#line 727 "parse.y"
{ do_pending_inlines (); ;
    break;}
case 70:
#line 729 "parse.y"
{ do_pending_inlines (); ;
    break;}
case 71:
#line 731 "parse.y"
{ do_pending_inlines (); ;
    break;}
case 72:
#line 733 "parse.y"
{ do_pending_inlines ();
		  pop_lang_context (); ;
    break;}
case 73:
#line 736 "parse.y"
{ do_pending_inlines ();
		  pop_lang_context (); ;
    break;}
case 74:
#line 739 "parse.y"
{ pedantic = yyvsp[-1].itype; ;
    break;}
case 76:
#line 745 "parse.y"
{;
    break;}
case 77:
#line 747 "parse.y"
{ note_list_got_semicolon (yyvsp[-2].ftype.t); ;
    break;}
case 78:
#line 749 "parse.y"
{
		  if (yyvsp[-1].ftype.t != error_mark_node)
                    {
		      maybe_process_partial_specialization (yyvsp[-1].ftype.t);
		      note_got_semicolon (yyvsp[-1].ftype.t);
	            }
                ;
    break;}
case 80:
#line 761 "parse.y"
{;
    break;}
case 81:
#line 763 "parse.y"
{ note_list_got_semicolon (yyvsp[-2].ftype.t); ;
    break;}
case 82:
#line 765 "parse.y"
{ pedwarn ("empty declaration"); ;
    break;}
case 84:
#line 768 "parse.y"
{
		  tree t, attrs;
		  split_specs_attrs (yyvsp[-1].ftype.t, &t, &attrs);
		  shadow_tag (t);
		  note_list_got_semicolon (yyvsp[-1].ftype.t);
		;
    break;}
case 87:
#line 777 "parse.y"
{ end_input (); ;
    break;}
case 97:
#line 803 "parse.y"
{ yyval.ttype = begin_compound_stmt (/*has_no_scope=*/1); ;
    break;}
case 98:
#line 805 "parse.y"
{
		  STMT_LINENO (yyvsp[-1].ttype) = yyvsp[-3].itype;
		  finish_compound_stmt (/*has_no_scope=*/1, yyvsp[-1].ttype);
		  finish_function_body (yyvsp[-5].ttype);
		;
    break;}
case 99:
#line 814 "parse.y"
{ expand_body (finish_function (0)); ;
    break;}
case 100:
#line 816 "parse.y"
{ expand_body (finish_function (0)); ;
    break;}
case 101:
#line 818 "parse.y"
{ ;
    break;}
case 102:
#line 823 "parse.y"
{ yyval.ttype = begin_constructor_declarator (yyvsp[-2].ttype, yyvsp[-1].ttype); ;
    break;}
case 103:
#line 825 "parse.y"
{ yyval.ttype = make_call_declarator (yyvsp[-4].ttype, yyvsp[-3].ttype, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 104:
#line 827 "parse.y"
{ yyval.ttype = begin_constructor_declarator (yyvsp[-4].ttype, yyvsp[-3].ttype);
		  yyval.ttype = make_call_declarator (yyval.ttype, empty_parms (), yyvsp[-1].ttype, yyvsp[0].ttype);
		;
    break;}
case 105:
#line 831 "parse.y"
{ yyval.ttype = begin_constructor_declarator (yyvsp[-2].ttype, yyvsp[-1].ttype); ;
    break;}
case 106:
#line 833 "parse.y"
{ yyval.ttype = make_call_declarator (yyvsp[-4].ttype, yyvsp[-3].ttype, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 107:
#line 835 "parse.y"
{ yyval.ttype = begin_constructor_declarator (yyvsp[-4].ttype, yyvsp[-3].ttype);
		  yyval.ttype = make_call_declarator (yyval.ttype, empty_parms (), yyvsp[-1].ttype, yyvsp[0].ttype);
		;
    break;}
case 108:
#line 839 "parse.y"
{ yyval.ttype = begin_constructor_declarator (yyvsp[-2].ttype, yyvsp[-1].ttype); ;
    break;}
case 109:
#line 841 "parse.y"
{ yyval.ttype = make_call_declarator (yyvsp[-4].ttype, yyvsp[-3].ttype, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 110:
#line 843 "parse.y"
{ yyval.ttype = begin_constructor_declarator (yyvsp[-4].ttype, yyvsp[-3].ttype);
		  yyval.ttype = make_call_declarator (yyval.ttype, empty_parms (), yyvsp[-1].ttype, yyvsp[0].ttype);
		;
    break;}
case 111:
#line 847 "parse.y"
{ yyval.ttype = begin_constructor_declarator (yyvsp[-2].ttype, yyvsp[-1].ttype); ;
    break;}
case 112:
#line 849 "parse.y"
{ yyval.ttype = make_call_declarator (yyvsp[-4].ttype, yyvsp[-3].ttype, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 113:
#line 851 "parse.y"
{ yyval.ttype = begin_constructor_declarator (yyvsp[-4].ttype, yyvsp[-3].ttype);
		  yyval.ttype = make_call_declarator (yyval.ttype, empty_parms (), yyvsp[-1].ttype, yyvsp[0].ttype);
		;
    break;}
case 114:
#line 858 "parse.y"
{ check_for_new_type ("return type", yyvsp[-1].ftype);
		  if (!parse_begin_function_definition (yyvsp[-1].ftype.t, yyvsp[0].ttype))
		    YYERROR1; ;
    break;}
case 115:
#line 862 "parse.y"
{ if (!parse_begin_function_definition (yyvsp[-1].ftype.t, yyvsp[0].ttype))
		    YYERROR1; ;
    break;}
case 116:
#line 865 "parse.y"
{ if (!parse_begin_function_definition (NULL_TREE, yyvsp[0].ttype))
		    YYERROR1; ;
    break;}
case 117:
#line 868 "parse.y"
{ if (!parse_begin_function_definition (yyvsp[-1].ftype.t, yyvsp[0].ttype))
		    YYERROR1; ;
    break;}
case 118:
#line 871 "parse.y"
{ if (!parse_begin_function_definition (NULL_TREE, yyvsp[0].ttype))
		    YYERROR1; ;
    break;}
case 119:
#line 880 "parse.y"
{ yyval.ttype = make_call_declarator (yyvsp[-5].ttype, yyvsp[-3].ttype, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 120:
#line 883 "parse.y"
{ yyval.ttype = make_call_declarator (yyvsp[-6].ttype, yyvsp[-3].ttype, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 121:
#line 885 "parse.y"
{ yyval.ttype = make_call_declarator (yyvsp[-3].ttype, empty_parms (), yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 122:
#line 887 "parse.y"
{ yyval.ttype = make_call_declarator (yyvsp[-4].ttype, empty_parms (), yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 123:
#line 889 "parse.y"
{ yyval.ttype = make_call_declarator (yyvsp[-5].ttype, yyvsp[-3].ttype, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 124:
#line 891 "parse.y"
{ yyval.ttype = make_call_declarator (yyvsp[-3].ttype, empty_parms (), yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 125:
#line 898 "parse.y"
{ yyval.ttype = parse_method (yyvsp[0].ttype, yyvsp[-1].ftype.t, yyvsp[-1].ftype.lookups);
		 rest_of_mdef:
		  if (! yyval.ttype)
		    YYERROR1;
		  if (yychar == YYEMPTY)
		    yychar = YYLEX;
		  snarf_method (yyval.ttype); ;
    break;}
case 126:
#line 906 "parse.y"
{ yyval.ttype = parse_method (yyvsp[0].ttype, NULL_TREE, NULL_TREE);
		  goto rest_of_mdef; ;
    break;}
case 127:
#line 909 "parse.y"
{ yyval.ttype = parse_method (yyvsp[0].ttype, yyvsp[-1].ftype.t, yyvsp[-1].ftype.lookups); goto rest_of_mdef;;
    break;}
case 128:
#line 911 "parse.y"
{ yyval.ttype = parse_method (yyvsp[0].ttype, yyvsp[-1].ftype.t, yyvsp[-1].ftype.lookups); goto rest_of_mdef;;
    break;}
case 129:
#line 913 "parse.y"
{ yyval.ttype = parse_method (yyvsp[0].ttype, NULL_TREE, NULL_TREE);
		  goto rest_of_mdef; ;
    break;}
case 130:
#line 916 "parse.y"
{ yyval.ttype = parse_method (yyvsp[0].ttype, yyvsp[-1].ftype.t, yyvsp[-1].ftype.lookups); goto rest_of_mdef;;
    break;}
case 131:
#line 918 "parse.y"
{ yyval.ttype = parse_method (yyvsp[0].ttype, NULL_TREE, NULL_TREE);
		  goto rest_of_mdef; ;
    break;}
case 132:
#line 924 "parse.y"
{
		  yyval.ttype = yyvsp[0].ttype;
		;
    break;}
case 133:
#line 931 "parse.y"
{ finish_named_return_value (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 134:
#line 933 "parse.y"
{ finish_named_return_value (yyval.ttype, yyvsp[-1].ttype); ;
    break;}
case 135:
#line 935 "parse.y"
{ finish_named_return_value (yyval.ttype, NULL_TREE); ;
    break;}
case 136:
#line 939 "parse.y"
{ begin_mem_initializers (); ;
    break;}
case 137:
#line 940 "parse.y"
{
		  if (yyvsp[0].ftype.new_type_flag == 0)
		    error ("no base or member initializers given following ':'");
		  finish_mem_initializers (yyvsp[0].ftype.t);
		;
    break;}
case 138:
#line 949 "parse.y"
{
		  yyval.ttype = begin_function_body ();
		;
    break;}
case 139:
#line 956 "parse.y"
{
		  yyval.ftype.new_type_flag = 0;
		  yyval.ftype.t = NULL_TREE;
		;
    break;}
case 140:
#line 961 "parse.y"
{
		  yyval.ftype.new_type_flag = 1;
		  yyval.ftype.t = yyvsp[0].ttype;
		;
    break;}
case 141:
#line 966 "parse.y"
{
		  if (yyvsp[0].ttype)
		    {
		      yyval.ftype.new_type_flag = 1;
		      TREE_CHAIN (yyvsp[0].ttype) = yyvsp[-2].ftype.t;
		      yyval.ftype.t = yyvsp[0].ttype;
		    }
		  else
		    yyval.ftype = yyvsp[-2].ftype;
		;
    break;}
case 143:
#line 981 "parse.y"
{
 		  if (current_class_name)
		    pedwarn ("anachronistic old style base class initializer");
		  yyval.ttype = expand_member_init (NULL_TREE);
		  in_base_initializer = yyval.ttype && !DECL_P (yyval.ttype);
		;
    break;}
case 144:
#line 988 "parse.y"
{ yyval.ttype = expand_member_init (yyvsp[0].ttype);
		  in_base_initializer = yyval.ttype && !DECL_P (yyval.ttype); ;
    break;}
case 145:
#line 991 "parse.y"
{ yyval.ttype = expand_member_init (yyvsp[0].ttype);
		  in_base_initializer = yyval.ttype && !DECL_P (yyval.ttype); ;
    break;}
case 146:
#line 994 "parse.y"
{ yyval.ttype = expand_member_init (yyvsp[0].ttype);
		  in_base_initializer = yyval.ttype && !DECL_P (yyval.ttype); ;
    break;}
case 147:
#line 1000 "parse.y"
{ in_base_initializer = 0;
		  yyval.ttype = yyvsp[-3].ttype ? build_tree_list (yyvsp[-3].ttype, yyvsp[-1].ttype) : NULL_TREE; ;
    break;}
case 148:
#line 1003 "parse.y"
{ in_base_initializer = 0;
		  yyval.ttype = yyvsp[-1].ttype ? build_tree_list (yyvsp[-1].ttype, void_type_node) : NULL_TREE; ;
    break;}
case 149:
#line 1006 "parse.y"
{ in_base_initializer = 0;
		  yyval.ttype = NULL_TREE; ;
    break;}
case 161:
#line 1032 "parse.y"
{ do_type_instantiation (yyvsp[-1].ftype.t, NULL_TREE, 1);
		  yyungetc (';', 1); ;
    break;}
case 163:
#line 1036 "parse.y"
{ tree specs = strip_attrs (yyvsp[-1].ftype.t);
		  parse_decl_instantiation (specs, yyvsp[0].ttype, NULL_TREE); ;
    break;}
case 165:
#line 1040 "parse.y"
{ parse_decl_instantiation (NULL_TREE, yyvsp[0].ttype, NULL_TREE); ;
    break;}
case 167:
#line 1043 "parse.y"
{ parse_decl_instantiation (NULL_TREE, yyvsp[0].ttype, NULL_TREE); ;
    break;}
case 169:
#line 1046 "parse.y"
{ do_type_instantiation (yyvsp[-1].ftype.t, yyvsp[-4].ttype, 1);
		  yyungetc (';', 1); ;
    break;}
case 170:
#line 1049 "parse.y"
{;
    break;}
case 171:
#line 1052 "parse.y"
{ tree specs = strip_attrs (yyvsp[-1].ftype.t);
		  parse_decl_instantiation (specs, yyvsp[0].ttype, yyvsp[-4].ttype); ;
    break;}
case 172:
#line 1055 "parse.y"
{;
    break;}
case 173:
#line 1057 "parse.y"
{ parse_decl_instantiation (NULL_TREE, yyvsp[0].ttype, yyvsp[-3].ttype); ;
    break;}
case 174:
#line 1059 "parse.y"
{;
    break;}
case 175:
#line 1061 "parse.y"
{ parse_decl_instantiation (NULL_TREE, yyvsp[0].ttype, yyvsp[-3].ttype); ;
    break;}
case 176:
#line 1063 "parse.y"
{;
    break;}
case 177:
#line 1067 "parse.y"
{ begin_explicit_instantiation(); ;
    break;}
case 178:
#line 1071 "parse.y"
{ end_explicit_instantiation(); ;
    break;}
case 179:
#line 1081 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 180:
#line 1084 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 183:
#line 1092 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 184:
#line 1098 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 185:
#line 1102 "parse.y"
{
		  if (yychar == YYEMPTY)
		    yychar = YYLEX;

		  yyval.ttype = finish_template_type (yyvsp[-3].ttype, yyvsp[-1].ttype,
					     yychar == SCOPE);
		;
    break;}
case 187:
#line 1114 "parse.y"
{
		  /* Handle `Class<Class<Type>>' without space in the `>>' */
		  pedwarn ("`>>' should be `> >' in template class name");
		  yyungetc ('>', 1);
		;
    break;}
case 188:
#line 1123 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 190:
#line 1129 "parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, yyval.ttype); ;
    break;}
case 191:
#line 1131 "parse.y"
{ yyval.ttype = chainon (yyval.ttype, build_tree_list (NULL_TREE, yyvsp[0].ttype)); ;
    break;}
case 192:
#line 1136 "parse.y"
{ yyval.ttype = groktypename (yyvsp[0].ftype.t); ;
    break;}
case 193:
#line 1138 "parse.y"
{
		  yyval.ttype = lastiddecl;
		  if (DECL_TEMPLATE_TEMPLATE_PARM_P (yyval.ttype))
		    yyval.ttype = TREE_TYPE (yyval.ttype);
		;
    break;}
case 194:
#line 1144 "parse.y"
{
		  yyval.ttype = lastiddecl;
		  if (DECL_TEMPLATE_TEMPLATE_PARM_P (yyval.ttype))
		    yyval.ttype = TREE_TYPE (yyval.ttype);
		;
    break;}
case 196:
#line 1151 "parse.y"
{
		  if (!processing_template_decl)
		    {
		      error ("use of template qualifier outside template");
		      yyval.ttype = error_mark_node;
		    }
		  else
		    yyval.ttype = make_unbound_class_template (yyvsp[-2].ttype, yyvsp[0].ttype, tf_error | tf_parsing);
		;
    break;}
case 197:
#line 1164 "parse.y"
{ yyval.code = NEGATE_EXPR; ;
    break;}
case 198:
#line 1166 "parse.y"
{ yyval.code = CONVERT_EXPR; ;
    break;}
case 199:
#line 1168 "parse.y"
{ yyval.code = PREINCREMENT_EXPR; ;
    break;}
case 200:
#line 1170 "parse.y"
{ yyval.code = PREDECREMENT_EXPR; ;
    break;}
case 201:
#line 1172 "parse.y"
{ yyval.code = TRUTH_NOT_EXPR; ;
    break;}
case 202:
#line 1177 "parse.y"
{ yyval.ttype = build_x_compound_expr (yyval.ttype); ;
    break;}
case 204:
#line 1183 "parse.y"
{ error ("ISO C++ forbids an empty condition for `%s'",
			 cond_stmt_keyword);
		  yyval.ttype = integer_zero_node; ;
    break;}
case 205:
#line 1187 "parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 206:
#line 1192 "parse.y"
{ error ("ISO C++ forbids an empty condition for `%s'",
			 cond_stmt_keyword);
		  yyval.ttype = integer_zero_node; ;
    break;}
case 207:
#line 1196 "parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 208:
#line 1201 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 210:
#line 1204 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 211:
#line 1209 "parse.y"
{ {
		  tree d;
		  for (d = getdecls (); d; d = TREE_CHAIN (d))
		    if (TREE_CODE (d) == TYPE_DECL) {
		      tree s = TREE_TYPE (d);
		      if (TREE_CODE (s) == RECORD_TYPE)
			error ("definition of class `%T' in condition", s);
		      else if (TREE_CODE (s) == ENUMERAL_TYPE)
			error ("definition of enum `%T' in condition", s);
		    }
		  }
		  current_declspecs = yyvsp[-4].ftype.t;
		  yyval.ttype = parse_decl (yyvsp[-3].ttype, yyvsp[-1].ttype, 1);
		;
    break;}
case 212:
#line 1224 "parse.y"
{
		  parse_end_decl (yyvsp[-1].ttype, yyvsp[0].ttype, yyvsp[-3].ttype);
		  yyval.ttype = convert_from_reference (yyvsp[-1].ttype);
		  if (TREE_CODE (TREE_TYPE (yyval.ttype)) == ARRAY_TYPE)
		    error ("definition of array `%#D' in condition", yyval.ttype);
		;
    break;}
case 218:
#line 1242 "parse.y"
{ yyval.ttype = tree_cons (NULL_TREE, yyval.ttype,
		                  build_tree_list (NULL_TREE, yyvsp[0].ttype)); ;
    break;}
case 219:
#line 1245 "parse.y"
{ yyval.ttype = tree_cons (NULL_TREE, yyval.ttype,
		                  build_tree_list (NULL_TREE, error_mark_node)); ;
    break;}
case 220:
#line 1248 "parse.y"
{ chainon (yyval.ttype, build_tree_list (NULL_TREE, yyvsp[0].ttype)); ;
    break;}
case 221:
#line 1250 "parse.y"
{ chainon (yyval.ttype, build_tree_list (NULL_TREE, error_mark_node)); ;
    break;}
case 222:
#line 1255 "parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, yyval.ttype); ;
    break;}
case 224:
#line 1261 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 225:
#line 1264 "parse.y"
{ yyval.ttype = yyvsp[0].ttype;
		  pedantic = yyvsp[-1].itype; ;
    break;}
case 226:
#line 1267 "parse.y"
{ yyval.ttype = build_x_indirect_ref (yyvsp[0].ttype, "unary *"); ;
    break;}
case 227:
#line 1269 "parse.y"
{ yyval.ttype = build_x_unary_op (ADDR_EXPR, yyvsp[0].ttype); ;
    break;}
case 228:
#line 1271 "parse.y"
{ yyval.ttype = build_x_unary_op (BIT_NOT_EXPR, yyvsp[0].ttype); ;
    break;}
case 229:
#line 1273 "parse.y"
{ yyval.ttype = finish_unary_op_expr (yyvsp[-1].code, yyvsp[0].ttype); ;
    break;}
case 230:
#line 1276 "parse.y"
{ yyval.ttype = finish_label_address_expr (yyvsp[0].ttype); ;
    break;}
case 231:
#line 1278 "parse.y"
{ yyval.ttype = finish_sizeof (yyvsp[0].ttype);
		  skip_evaluation--; ;
    break;}
case 232:
#line 1281 "parse.y"
{ yyval.ttype = finish_sizeof (groktypename (yyvsp[-1].ftype.t));
		  check_for_new_type ("sizeof", yyvsp[-1].ftype);
		  skip_evaluation--; ;
    break;}
case 233:
#line 1285 "parse.y"
{ yyval.ttype = finish_alignof (yyvsp[0].ttype);
		  skip_evaluation--; ;
    break;}
case 234:
#line 1288 "parse.y"
{ yyval.ttype = finish_alignof (groktypename (yyvsp[-1].ftype.t));
		  check_for_new_type ("alignof", yyvsp[-1].ftype);
		  skip_evaluation--; ;
    break;}
case 235:
#line 1295 "parse.y"
{ yyval.ttype = build_new (NULL_TREE, yyvsp[0].ftype.t, NULL_TREE, yyvsp[-1].itype);
		  check_for_new_type ("new", yyvsp[0].ftype); ;
    break;}
case 236:
#line 1298 "parse.y"
{ yyval.ttype = build_new (NULL_TREE, yyvsp[-1].ftype.t, yyvsp[0].ttype, yyvsp[-2].itype);
		  check_for_new_type ("new", yyvsp[-1].ftype); ;
    break;}
case 237:
#line 1301 "parse.y"
{ yyval.ttype = build_new (yyvsp[-1].ttype, yyvsp[0].ftype.t, NULL_TREE, yyvsp[-2].itype);
		  check_for_new_type ("new", yyvsp[0].ftype); ;
    break;}
case 238:
#line 1304 "parse.y"
{ yyval.ttype = build_new (yyvsp[-2].ttype, yyvsp[-1].ftype.t, yyvsp[0].ttype, yyvsp[-3].itype);
		  check_for_new_type ("new", yyvsp[-1].ftype); ;
    break;}
case 239:
#line 1308 "parse.y"
{ yyval.ttype = build_new (NULL_TREE, groktypename(yyvsp[-1].ftype.t),
				  NULL_TREE, yyvsp[-3].itype);
		  check_for_new_type ("new", yyvsp[-1].ftype); ;
    break;}
case 240:
#line 1312 "parse.y"
{ yyval.ttype = build_new (NULL_TREE, groktypename(yyvsp[-2].ftype.t), yyvsp[0].ttype, yyvsp[-4].itype);
		  check_for_new_type ("new", yyvsp[-2].ftype); ;
    break;}
case 241:
#line 1315 "parse.y"
{ yyval.ttype = build_new (yyvsp[-3].ttype, groktypename(yyvsp[-1].ftype.t), NULL_TREE, yyvsp[-4].itype);
		  check_for_new_type ("new", yyvsp[-1].ftype); ;
    break;}
case 242:
#line 1318 "parse.y"
{ yyval.ttype = build_new (yyvsp[-4].ttype, groktypename(yyvsp[-2].ftype.t), yyvsp[0].ttype, yyvsp[-5].itype);
		  check_for_new_type ("new", yyvsp[-2].ftype); ;
    break;}
case 243:
#line 1322 "parse.y"
{ yyval.ttype = delete_sanity (yyvsp[0].ttype, NULL_TREE, 0, yyvsp[-1].itype); ;
    break;}
case 244:
#line 1324 "parse.y"
{ yyval.ttype = delete_sanity (yyvsp[0].ttype, NULL_TREE, 1, yyvsp[-3].itype);
		  if (yychar == YYEMPTY)
		    yychar = YYLEX; ;
    break;}
case 245:
#line 1328 "parse.y"
{ yyval.ttype = delete_sanity (yyvsp[0].ttype, yyvsp[-2].ttype, 2, yyvsp[-4].itype);
		  if (yychar == YYEMPTY)
		    yychar = YYLEX; ;
    break;}
case 246:
#line 1332 "parse.y"
{ yyval.ttype = build_x_unary_op (REALPART_EXPR, yyvsp[0].ttype); ;
    break;}
case 247:
#line 1334 "parse.y"
{ yyval.ttype = build_x_unary_op (IMAGPART_EXPR, yyvsp[0].ttype); ;
    break;}
case 248:
#line 1339 "parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 249:
#line 1341 "parse.y"
{ pedwarn ("old style placement syntax, use () instead");
		  yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 250:
#line 1347 "parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 251:
#line 1349 "parse.y"
{ yyval.ttype = void_zero_node; ;
    break;}
case 252:
#line 1351 "parse.y"
{
		  error ("`%T' is not a valid expression", yyvsp[-1].ftype.t);
		  yyval.ttype = error_mark_node;
		;
    break;}
case 253:
#line 1356 "parse.y"
{
		  /* This was previously allowed as an extension, but
		     was removed in G++ 3.3.  */
		  error ("initialization of new expression with `='");
		  yyval.ttype = error_mark_node;
		;
    break;}
case 254:
#line 1367 "parse.y"
{ yyvsp[-1].ftype.t = finish_parmlist (build_tree_list (NULL_TREE, yyvsp[-1].ftype.t), 0);
		  yyval.ttype = make_call_declarator (NULL_TREE, yyvsp[-1].ftype.t, NULL_TREE, NULL_TREE);
		  check_for_new_type ("cast", yyvsp[-1].ftype); ;
    break;}
case 255:
#line 1371 "parse.y"
{ yyvsp[-1].ftype.t = finish_parmlist (build_tree_list (NULL_TREE, yyvsp[-1].ftype.t), 0);
		  yyval.ttype = make_call_declarator (yyval.ttype, yyvsp[-1].ftype.t, NULL_TREE, NULL_TREE);
		  check_for_new_type ("cast", yyvsp[-1].ftype); ;
    break;}
case 257:
#line 1379 "parse.y"
{ yyval.ttype = reparse_absdcl_as_casts (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 258:
#line 1381 "parse.y"
{
		  tree init = build_nt (CONSTRUCTOR, NULL_TREE,
					nreverse (yyvsp[-2].ttype));
		  if (pedantic)
		    pedwarn ("ISO C++ forbids compound literals");
		  /* Indicate that this was a C99 compound literal.  */
		  TREE_HAS_CONSTRUCTOR (init) = 1;

		  yyval.ttype = reparse_absdcl_as_casts (yyval.ttype, init);
		;
    break;}
case 260:
#line 1397 "parse.y"
{ yyval.ttype = build_x_binary_op (MEMBER_REF, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 261:
#line 1399 "parse.y"
{ yyval.ttype = build_m_component_ref (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 262:
#line 1401 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 263:
#line 1403 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 264:
#line 1405 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 265:
#line 1407 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 266:
#line 1409 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 267:
#line 1411 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 268:
#line 1413 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 269:
#line 1415 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 270:
#line 1417 "parse.y"
{ yyval.ttype = build_x_binary_op (LT_EXPR, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 271:
#line 1419 "parse.y"
{ yyval.ttype = build_x_binary_op (GT_EXPR, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 272:
#line 1421 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 273:
#line 1423 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 274:
#line 1425 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 275:
#line 1427 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 276:
#line 1429 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 277:
#line 1431 "parse.y"
{ yyval.ttype = build_x_binary_op (TRUTH_ANDIF_EXPR, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 278:
#line 1433 "parse.y"
{ yyval.ttype = build_x_binary_op (TRUTH_ORIF_EXPR, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 279:
#line 1435 "parse.y"
{ yyval.ttype = build_x_conditional_expr (yyval.ttype, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 280:
#line 1437 "parse.y"
{ yyval.ttype = build_x_modify_expr (yyval.ttype, NOP_EXPR, yyvsp[0].ttype);
		  if (yyval.ttype != error_mark_node)
                    C_SET_EXP_ORIGINAL_CODE (yyval.ttype, MODIFY_EXPR); ;
    break;}
case 281:
#line 1441 "parse.y"
{ yyval.ttype = build_x_modify_expr (yyval.ttype, yyvsp[-1].code, yyvsp[0].ttype); ;
    break;}
case 282:
#line 1443 "parse.y"
{ yyval.ttype = build_throw (NULL_TREE); ;
    break;}
case 283:
#line 1445 "parse.y"
{ yyval.ttype = build_throw (yyvsp[0].ttype); ;
    break;}
case 285:
#line 1452 "parse.y"
{ yyval.ttype = build_x_binary_op (MEMBER_REF, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 286:
#line 1454 "parse.y"
{ yyval.ttype = build_m_component_ref (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 287:
#line 1456 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 288:
#line 1458 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 289:
#line 1460 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 290:
#line 1462 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 291:
#line 1464 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 292:
#line 1466 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 293:
#line 1468 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 294:
#line 1470 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 295:
#line 1472 "parse.y"
{ yyval.ttype = build_x_binary_op (LT_EXPR, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 296:
#line 1474 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 297:
#line 1476 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 298:
#line 1478 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 299:
#line 1480 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 300:
#line 1482 "parse.y"
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 301:
#line 1484 "parse.y"
{ yyval.ttype = build_x_binary_op (TRUTH_ANDIF_EXPR, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 302:
#line 1486 "parse.y"
{ yyval.ttype = build_x_binary_op (TRUTH_ORIF_EXPR, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 303:
#line 1488 "parse.y"
{ yyval.ttype = build_x_conditional_expr (yyval.ttype, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 304:
#line 1490 "parse.y"
{ yyval.ttype = build_x_modify_expr (yyval.ttype, NOP_EXPR, yyvsp[0].ttype);
		  if (yyval.ttype != error_mark_node)
                    C_SET_EXP_ORIGINAL_CODE (yyval.ttype, MODIFY_EXPR); ;
    break;}
case 305:
#line 1494 "parse.y"
{ yyval.ttype = build_x_modify_expr (yyval.ttype, yyvsp[-1].code, yyvsp[0].ttype); ;
    break;}
case 306:
#line 1496 "parse.y"
{ yyval.ttype = build_throw (NULL_TREE); ;
    break;}
case 307:
#line 1498 "parse.y"
{ yyval.ttype = build_throw (yyvsp[0].ttype); ;
    break;}
case 308:
#line 1503 "parse.y"
{ yyval.ttype = build_nt (BIT_NOT_EXPR, yyvsp[0].ttype); ;
    break;}
case 309:
#line 1505 "parse.y"
{ yyval.ttype = build_nt (BIT_NOT_EXPR, yyvsp[0].ttype); ;
    break;}
case 315:
#line 1514 "parse.y"
{
		  /* If lastiddecl is a BASELINK we're in an
		     expression like S::f<int>, so don't
		     do_identifier; we only do that for unqualified
		     identifiers.  */
	          if (!lastiddecl || !BASELINK_P (lastiddecl))
		    yyval.ttype = do_identifier (yyvsp[-1].ttype, 3, NULL_TREE);
		  else
		    yyval.ttype = yyvsp[-1].ttype;
		;
    break;}
case 316:
#line 1528 "parse.y"
{ 
		  tree template_name = yyvsp[-2].ttype;
		  if (TREE_CODE (template_name) == COMPONENT_REF)
		    template_name = TREE_OPERAND (template_name, 1);
		  yyval.ttype = lookup_template_function (template_name, yyvsp[-1].ttype); 
		;
    break;}
case 317:
#line 1535 "parse.y"
{ 
		  tree template_name = yyvsp[-2].ttype;
		  if (TREE_CODE (template_name) == COMPONENT_REF)
		    template_name = TREE_OPERAND (template_name, 1);
		  yyval.ttype = lookup_template_function (template_name, yyvsp[-1].ttype); 
		;
    break;}
case 318:
#line 1545 "parse.y"
{ yyval.ttype = lookup_template_function (yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 319:
#line 1547 "parse.y"
{ yyval.ttype = lookup_template_function (yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 320:
#line 1550 "parse.y"
{ yyval.ttype = lookup_template_function (yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 325:
#line 1562 "parse.y"
{
		  /* Provide support for '(' attributes '*' declarator ')'
		     etc */
		  yyval.ttype = tree_cons (yyvsp[-1].ttype, yyvsp[0].ttype, NULL_TREE);
		;
    break;}
case 327:
#line 1572 "parse.y"
{ yyval.ttype = build_nt (INDIRECT_REF, yyvsp[0].ttype); ;
    break;}
case 328:
#line 1574 "parse.y"
{ yyval.ttype = build_nt (ADDR_EXPR, yyvsp[0].ttype); ;
    break;}
case 329:
#line 1576 "parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 330:
#line 1581 "parse.y"
{ yyval.ttype = lookup_template_function (yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 331:
#line 1583 "parse.y"
{ yyval.ttype = lookup_template_function (yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 335:
#line 1593 "parse.y"
{ yyval.ttype = finish_decl_parsing (yyvsp[-1].ttype); ;
    break;}
case 336:
#line 1598 "parse.y"
{
		  if (TREE_CODE (yyvsp[0].ttype) == BIT_NOT_EXPR)
		    yyval.ttype = build_x_unary_op (BIT_NOT_EXPR, TREE_OPERAND (yyvsp[0].ttype, 0));
		  else
		    yyval.ttype = finish_id_expr (yyvsp[0].ttype);
		;
    break;}
case 339:
#line 1607 "parse.y"
{
		  yyval.ttype = fix_string_type (yyval.ttype);
		  /* fix_string_type doesn't set up TYPE_MAIN_VARIANT of
		     a const array the way we want, so fix it.  */
		  if (flag_const_strings)
		    TREE_TYPE (yyval.ttype) = build_cplus_array_type
		      (TREE_TYPE (TREE_TYPE (yyval.ttype)),
		       TYPE_DOMAIN (TREE_TYPE (yyval.ttype)));
		;
    break;}
case 340:
#line 1617 "parse.y"
{ yyval.ttype = finish_fname (yyvsp[0].ttype); ;
    break;}
case 341:
#line 1619 "parse.y"
{ yyval.ttype = finish_parenthesized_expr (yyvsp[-1].ttype); ;
    break;}
case 342:
#line 1621 "parse.y"
{ yyvsp[-1].ttype = reparse_decl_as_expr (NULL_TREE, yyvsp[-1].ttype);
		  yyval.ttype = finish_parenthesized_expr (yyvsp[-1].ttype); ;
    break;}
case 343:
#line 1624 "parse.y"
{ yyval.ttype = error_mark_node; ;
    break;}
case 344:
#line 1626 "parse.y"
{ if (!at_function_scope_p ())
		    {
		      error ("braced-group within expression allowed only inside a function");
		      YYERROR;
		    }
		  if (pedantic)
		    pedwarn ("ISO C++ forbids braced-groups within expressions");
		  yyval.ttype = begin_stmt_expr ();
		;
    break;}
case 345:
#line 1636 "parse.y"
{ yyval.ttype = finish_stmt_expr (yyvsp[-2].ttype); ;
    break;}
case 346:
#line 1641 "parse.y"
{ yyval.ttype = parse_finish_call_expr (yyvsp[-3].ttype, yyvsp[-1].ttype, 1); ;
    break;}
case 347:
#line 1643 "parse.y"
{ yyval.ttype = parse_finish_call_expr (yyvsp[-1].ttype, NULL_TREE, 1); ;
    break;}
case 348:
#line 1645 "parse.y"
{ yyval.ttype = parse_finish_call_expr (yyvsp[-3].ttype, yyvsp[-1].ttype, 0); ;
    break;}
case 349:
#line 1647 "parse.y"
{ yyval.ttype = parse_finish_call_expr (yyvsp[-1].ttype, NULL_TREE, 0); ;
    break;}
case 350:
#line 1649 "parse.y"
{ yyval.ttype = build_x_va_arg (yyvsp[-3].ttype, groktypename (yyvsp[-1].ftype.t));
		  check_for_new_type ("__builtin_va_arg", yyvsp[-1].ftype); ;
    break;}
case 351:
#line 1652 "parse.y"
{ yyval.ttype = grok_array_decl (yyval.ttype, yyvsp[-1].ttype); ;
    break;}
case 352:
#line 1654 "parse.y"
{ yyval.ttype = finish_increment_expr (yyvsp[-1].ttype, POSTINCREMENT_EXPR); ;
    break;}
case 353:
#line 1656 "parse.y"
{ yyval.ttype = finish_increment_expr (yyvsp[-1].ttype, POSTDECREMENT_EXPR); ;
    break;}
case 354:
#line 1659 "parse.y"
{ yyval.ttype = finish_this_expr (); ;
    break;}
case 355:
#line 1661 "parse.y"
{
		  /* This is a C cast in C++'s `functional' notation
		     using the "implicit int" extension so that:
		     `const (3)' is equivalent to `const int (3)'.  */
		  tree type;

		  type = hash_tree_cons (NULL_TREE, yyvsp[-3].ttype, NULL_TREE);
		  type = groktypename (build_tree_list (type, NULL_TREE));
		  yyval.ttype = build_functional_cast (type, yyvsp[-1].ttype);
		;
    break;}
case 357:
#line 1673 "parse.y"
{ tree type = groktypename (yyvsp[-4].ftype.t);
		  check_for_new_type ("dynamic_cast", yyvsp[-4].ftype);
		  yyval.ttype = build_dynamic_cast (type, yyvsp[-1].ttype); ;
    break;}
case 358:
#line 1677 "parse.y"
{ tree type = groktypename (yyvsp[-4].ftype.t);
		  check_for_new_type ("static_cast", yyvsp[-4].ftype);
		  yyval.ttype = build_static_cast (type, yyvsp[-1].ttype); ;
    break;}
case 359:
#line 1681 "parse.y"
{ tree type = groktypename (yyvsp[-4].ftype.t);
		  check_for_new_type ("reinterpret_cast", yyvsp[-4].ftype);
		  yyval.ttype = build_reinterpret_cast (type, yyvsp[-1].ttype); ;
    break;}
case 360:
#line 1685 "parse.y"
{ tree type = groktypename (yyvsp[-4].ftype.t);
		  check_for_new_type ("const_cast", yyvsp[-4].ftype);
		  yyval.ttype = build_const_cast (type, yyvsp[-1].ttype); ;
    break;}
case 361:
#line 1689 "parse.y"
{ yyval.ttype = build_typeid (yyvsp[-1].ttype); ;
    break;}
case 362:
#line 1691 "parse.y"
{ tree type = groktypename (yyvsp[-1].ftype.t);
		  check_for_new_type ("typeid", yyvsp[-1].ftype);
		  yyval.ttype = get_typeid (type); ;
    break;}
case 363:
#line 1695 "parse.y"
{ yyval.ttype = parse_scoped_id (yyvsp[0].ttype); ;
    break;}
case 364:
#line 1697 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 365:
#line 1699 "parse.y"
{
		  got_scope = NULL_TREE;
		  if (TREE_CODE (yyvsp[0].ttype) == IDENTIFIER_NODE)
		    yyval.ttype = parse_scoped_id (yyvsp[0].ttype);
		  else
		    yyval.ttype = yyvsp[0].ttype;
		;
    break;}
case 366:
#line 1707 "parse.y"
{ yyval.ttype = build_offset_ref (OP0 (yyval.ttype), OP1 (yyval.ttype)); ;
    break;}
case 367:
#line 1709 "parse.y"
{ yyval.ttype = parse_finish_call_expr (yyvsp[-3].ttype, yyvsp[-1].ttype, 0); ;
    break;}
case 368:
#line 1711 "parse.y"
{ yyval.ttype = parse_finish_call_expr (yyvsp[-1].ttype, NULL_TREE, 0); ;
    break;}
case 369:
#line 1713 "parse.y"
{ yyval.ttype = finish_class_member_access_expr (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 370:
#line 1715 "parse.y"
{ yyval.ttype = finish_object_call_expr (yyvsp[-3].ttype, yyvsp[-4].ttype, yyvsp[-1].ttype); ;
    break;}
case 371:
#line 1717 "parse.y"
{ yyval.ttype = finish_object_call_expr (yyvsp[-1].ttype, yyvsp[-2].ttype, NULL_TREE); ;
    break;}
case 372:
#line 1719 "parse.y"
{ yyval.ttype = finish_class_member_access_expr (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 373:
#line 1721 "parse.y"
{ yyval.ttype = finish_class_member_access_expr (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 374:
#line 1723 "parse.y"
{ yyval.ttype = finish_object_call_expr (yyvsp[-3].ttype, yyvsp[-4].ttype, yyvsp[-1].ttype); ;
    break;}
case 375:
#line 1725 "parse.y"
{ yyval.ttype = finish_object_call_expr (yyvsp[-1].ttype, yyvsp[-2].ttype, NULL_TREE); ;
    break;}
case 376:
#line 1727 "parse.y"
{ yyval.ttype = finish_qualified_object_call_expr (yyvsp[-3].ttype, yyvsp[-4].ttype, yyvsp[-1].ttype); ;
    break;}
case 377:
#line 1729 "parse.y"
{ yyval.ttype = finish_qualified_object_call_expr (yyvsp[-1].ttype, yyvsp[-2].ttype, NULL_TREE); ;
    break;}
case 378:
#line 1732 "parse.y"
{ yyval.ttype = finish_pseudo_destructor_call_expr (yyvsp[-3].ttype, NULL_TREE, yyvsp[-1].ttype); ;
    break;}
case 379:
#line 1734 "parse.y"
{ yyval.ttype = finish_pseudo_destructor_call_expr (yyvsp[-5].ttype, yyvsp[-4].ttype, yyvsp[-1].ttype); ;
    break;}
case 380:
#line 1736 "parse.y"
{
		  yyval.ttype = error_mark_node;
		;
    break;}
case 381:
#line 1781 "parse.y"
{ yyval.itype = 0; ;
    break;}
case 382:
#line 1783 "parse.y"
{ got_scope = NULL_TREE; yyval.itype = 1; ;
    break;}
case 383:
#line 1788 "parse.y"
{ yyval.itype = 0; ;
    break;}
case 384:
#line 1790 "parse.y"
{ got_scope = NULL_TREE; yyval.itype = 1; ;
    break;}
case 385:
#line 1795 "parse.y"
{ yyval.ttype = boolean_true_node; ;
    break;}
case 386:
#line 1797 "parse.y"
{ yyval.ttype = boolean_false_node; ;
    break;}
case 387:
#line 1802 "parse.y"
{
		  if (DECL_CONSTRUCTOR_P (current_function_decl))
		    finish_mem_initializers (NULL_TREE);
		;
    break;}
case 388:
#line 1810 "parse.y"
{ got_object = TREE_TYPE (yyval.ttype); ;
    break;}
case 389:
#line 1812 "parse.y"
{
		  yyval.ttype = build_x_arrow (yyval.ttype);
		  got_object = TREE_TYPE (yyval.ttype);
		;
    break;}
case 390:
#line 1820 "parse.y"
{
		  if (yyvsp[-2].ftype.t && IS_AGGR_TYPE_CODE (TREE_CODE (yyvsp[-2].ftype.t)))
		    note_got_semicolon (yyvsp[-2].ftype.t);
		;
    break;}
case 391:
#line 1825 "parse.y"
{
		  note_list_got_semicolon (yyvsp[-2].ftype.t);
		;
    break;}
case 392:
#line 1829 "parse.y"
{;
    break;}
case 393:
#line 1831 "parse.y"
{
		  shadow_tag (yyvsp[-1].ftype.t);
		  note_list_got_semicolon (yyvsp[-1].ftype.t);
		;
    break;}
case 394:
#line 1836 "parse.y"
{ warning ("empty declaration"); ;
    break;}
case 395:
#line 1838 "parse.y"
{ pedantic = yyvsp[-1].itype; ;
    break;}
case 398:
#line 1852 "parse.y"
{ yyval.ttype = make_call_declarator (NULL_TREE, empty_parms (),
					     NULL_TREE, NULL_TREE); ;
    break;}
case 399:
#line 1855 "parse.y"
{ yyval.ttype = make_call_declarator (yyval.ttype, empty_parms (), NULL_TREE,
					     NULL_TREE); ;
    break;}
case 400:
#line 1862 "parse.y"
{ yyval.ftype.t = build_tree_list (yyvsp[-1].ftype.t, yyvsp[0].ttype);
		  yyval.ftype.new_type_flag = yyvsp[-1].ftype.new_type_flag; ;
    break;}
case 401:
#line 1865 "parse.y"
{ yyval.ftype.t = build_tree_list (yyvsp[-1].ftype.t, yyvsp[0].ttype);
		  yyval.ftype.new_type_flag = yyvsp[-1].ftype.new_type_flag; ;
    break;}
case 402:
#line 1868 "parse.y"
{ yyval.ftype.t = build_tree_list (build_tree_list (NULL_TREE, yyvsp[-1].ftype.t),
					  yyvsp[0].ttype);
		  yyval.ftype.new_type_flag = yyvsp[-1].ftype.new_type_flag; ;
    break;}
case 403:
#line 1872 "parse.y"
{ yyval.ftype.t = build_tree_list (yyvsp[0].ftype.t, NULL_TREE);
		  yyval.ftype.new_type_flag = yyvsp[0].ftype.new_type_flag;  ;
    break;}
case 404:
#line 1875 "parse.y"
{ yyval.ftype.t = build_tree_list (yyvsp[0].ftype.t, NULL_TREE);
		  yyval.ftype.new_type_flag = yyvsp[0].ftype.new_type_flag; ;
    break;}
case 405:
#line 1886 "parse.y"
{ yyval.ftype.lookups = type_lookups; ;
    break;}
case 406:
#line 1888 "parse.y"
{ yyval.ftype.lookups = type_lookups; ;
    break;}
case 407:
#line 1893 "parse.y"
{ yyval.ftype.t = tree_cons (NULL_TREE, yyvsp[0].ftype.t, yyvsp[-1].ftype.t);
		  yyval.ftype.new_type_flag = yyvsp[0].ftype.new_type_flag; ;
    break;}
case 408:
#line 1896 "parse.y"
{ yyval.ftype.t = tree_cons (NULL_TREE, yyvsp[-1].ftype.t, yyvsp[0].ttype);
		  yyval.ftype.new_type_flag = yyvsp[-1].ftype.new_type_flag; ;
    break;}
case 409:
#line 1899 "parse.y"
{ yyval.ftype.t = tree_cons (NULL_TREE, yyvsp[-2].ftype.t, chainon (yyvsp[-1].ttype, yyvsp[0].ttype));
		  yyval.ftype.new_type_flag = yyvsp[-2].ftype.new_type_flag; ;
    break;}
case 410:
#line 1902 "parse.y"
{ yyval.ftype.t = tree_cons (NULL_TREE, yyvsp[-1].ftype.t, chainon (yyvsp[0].ttype, yyvsp[-2].ftype.t));
		  yyval.ftype.new_type_flag = yyvsp[-1].ftype.new_type_flag; ;
    break;}
case 411:
#line 1905 "parse.y"
{ yyval.ftype.t = tree_cons (NULL_TREE, yyvsp[-1].ftype.t, chainon (yyvsp[0].ttype, yyvsp[-2].ftype.t));
		  yyval.ftype.new_type_flag = yyvsp[-1].ftype.new_type_flag; ;
    break;}
case 412:
#line 1908 "parse.y"
{ yyval.ftype.t = tree_cons (NULL_TREE, yyvsp[-2].ftype.t,
				    chainon (yyvsp[-1].ttype, chainon (yyvsp[0].ttype, yyvsp[-3].ftype.t)));
		  yyval.ftype.new_type_flag = yyvsp[-2].ftype.new_type_flag; ;
    break;}
case 413:
#line 1915 "parse.y"
{ if (extra_warnings)
		    warning ("`%s' is not at beginning of declaration",
			     IDENTIFIER_POINTER (yyval.ttype));
		  yyval.ttype = build_tree_list (NULL_TREE, yyval.ttype); ;
    break;}
case 414:
#line 1920 "parse.y"
{ yyval.ttype = tree_cons (NULL_TREE, yyvsp[0].ftype.t, yyval.ttype); ;
    break;}
case 415:
#line 1922 "parse.y"
{ if (extra_warnings)
		    warning ("`%s' is not at beginning of declaration",
			     IDENTIFIER_POINTER (yyvsp[0].ttype));
		  yyval.ttype = tree_cons (NULL_TREE, yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 416:
#line 1944 "parse.y"
{ yyval.ftype.lookups = NULL_TREE; TREE_STATIC (yyval.ftype.t) = 1; ;
    break;}
case 417:
#line 1946 "parse.y"
{
		  yyval.ftype.t = hash_tree_cons (NULL_TREE, yyvsp[0].ttype, NULL_TREE);
		  yyval.ftype.new_type_flag = 0; yyval.ftype.lookups = NULL_TREE;
		;
    break;}
case 418:
#line 1951 "parse.y"
{
		  yyval.ftype.t = hash_tree_cons (NULL_TREE, yyvsp[0].ttype, yyvsp[-1].ftype.t);
		  TREE_STATIC (yyval.ftype.t) = 1;
		;
    break;}
case 419:
#line 1956 "parse.y"
{
		  if (extra_warnings && TREE_STATIC (yyval.ftype.t))
		    warning ("`%s' is not at beginning of declaration",
			     IDENTIFIER_POINTER (yyvsp[0].ttype));
		  yyval.ftype.t = hash_tree_cons (NULL_TREE, yyvsp[0].ttype, yyvsp[-1].ftype.t);
		  TREE_STATIC (yyval.ftype.t) = TREE_STATIC (yyvsp[-1].ftype.t);
		;
    break;}
case 420:
#line 1964 "parse.y"
{ yyval.ftype.t = hash_tree_cons (yyvsp[0].ttype, NULL_TREE, yyvsp[-1].ftype.t); ;
    break;}
case 421:
#line 1975 "parse.y"
{ yyval.ftype.t = build_tree_list (NULL_TREE, yyvsp[0].ftype.t);
		  yyval.ftype.new_type_flag = yyvsp[0].ftype.new_type_flag; ;
    break;}
case 422:
#line 1978 "parse.y"
{ yyval.ftype.t = tree_cons (NULL_TREE, yyvsp[0].ftype.t, yyvsp[-1].ftype.t);
		  yyval.ftype.new_type_flag = yyvsp[0].ftype.new_type_flag; ;
    break;}
case 423:
#line 1981 "parse.y"
{ yyval.ftype.t = tree_cons (NULL_TREE, yyvsp[-1].ftype.t, yyvsp[0].ttype);
		  yyval.ftype.new_type_flag = yyvsp[-1].ftype.new_type_flag; ;
    break;}
case 424:
#line 1984 "parse.y"
{ yyval.ftype.t = tree_cons (NULL_TREE, yyvsp[-1].ftype.t, chainon (yyvsp[0].ttype, yyvsp[-2].ftype.t));
		  yyval.ftype.new_type_flag = yyvsp[-1].ftype.new_type_flag; ;
    break;}
case 425:
#line 1990 "parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, yyvsp[0].ftype.t); ;
    break;}
case 426:
#line 1992 "parse.y"
{ yyval.ttype = tree_cons (NULL_TREE, yyvsp[0].ftype.t, yyvsp[-1].ttype); ;
    break;}
case 427:
#line 1994 "parse.y"
{ yyval.ttype = tree_cons (yyvsp[0].ttype, NULL_TREE, yyvsp[-1].ttype); ;
    break;}
case 428:
#line 1996 "parse.y"
{ yyval.ttype = tree_cons (yyvsp[0].ttype, NULL_TREE, NULL_TREE); ;
    break;}
case 429:
#line 2000 "parse.y"
{ skip_evaluation++; ;
    break;}
case 430:
#line 2004 "parse.y"
{ skip_evaluation++; ;
    break;}
case 431:
#line 2008 "parse.y"
{ skip_evaluation++; ;
    break;}
case 432:
#line 2017 "parse.y"
{ yyval.ftype.lookups = NULL_TREE; ;
    break;}
case 433:
#line 2019 "parse.y"
{ yyval.ftype.t = yyvsp[0].ttype; yyval.ftype.new_type_flag = 0; yyval.ftype.lookups = NULL_TREE; ;
    break;}
case 434:
#line 2021 "parse.y"
{ yyval.ftype.t = yyvsp[0].ttype; yyval.ftype.new_type_flag = 0; yyval.ftype.lookups = NULL_TREE; ;
    break;}
case 435:
#line 2023 "parse.y"
{ yyval.ftype.t = finish_typeof (yyvsp[-1].ttype);
		  yyval.ftype.new_type_flag = 0; yyval.ftype.lookups = NULL_TREE;
		  skip_evaluation--; ;
    break;}
case 436:
#line 2027 "parse.y"
{ yyval.ftype.t = groktypename (yyvsp[-1].ftype.t);
		  yyval.ftype.new_type_flag = 0; yyval.ftype.lookups = NULL_TREE;
		  skip_evaluation--; ;
    break;}
case 437:
#line 2031 "parse.y"
{ tree type = TREE_TYPE (yyvsp[-1].ttype);

                  yyval.ftype.new_type_flag = 0; yyval.ftype.lookups = NULL_TREE;
		  if (IS_AGGR_TYPE (type))
		    {
		      sorry ("sigof type specifier");
		      yyval.ftype.t = type;
		    }
		  else
		    {
		      error ("`sigof' applied to non-aggregate expression");
		      yyval.ftype.t = error_mark_node;
		    }
		;
    break;}
case 438:
#line 2046 "parse.y"
{ tree type = groktypename (yyvsp[-1].ftype.t);

                  yyval.ftype.new_type_flag = 0; yyval.ftype.lookups = NULL_TREE;
		  if (IS_AGGR_TYPE (type))
		    {
		      sorry ("sigof type specifier");
		      yyval.ftype.t = type;
		    }
		  else
		    {
		      error("`sigof' applied to non-aggregate type");
		      yyval.ftype.t = error_mark_node;
		    }
		;
    break;}
case 439:
#line 2066 "parse.y"
{ yyval.ftype.t = yyvsp[0].ttype; yyval.ftype.new_type_flag = 0; ;
    break;}
case 440:
#line 2068 "parse.y"
{ yyval.ftype.t = yyvsp[0].ttype; yyval.ftype.new_type_flag = 0; ;
    break;}
case 443:
#line 2075 "parse.y"
{ check_multiple_declarators (); ;
    break;}
case 445:
#line 2081 "parse.y"
{ check_multiple_declarators (); ;
    break;}
case 447:
#line 2087 "parse.y"
{ check_multiple_declarators (); ;
    break;}
case 448:
#line 2092 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 449:
#line 2094 "parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 450:
#line 2099 "parse.y"
{ yyval.ttype = parse_decl (yyvsp[-3].ttype, yyvsp[-1].ttype, 1); ;
    break;}
case 451:
#line 2102 "parse.y"
{ parse_end_decl (yyvsp[-1].ttype, yyvsp[0].ttype, yyvsp[-4].ttype); ;
    break;}
case 452:
#line 2104 "parse.y"
{
		  yyval.ttype = parse_decl (yyvsp[-2].ttype, yyvsp[0].ttype, 0);
		  parse_end_decl (yyval.ttype, NULL_TREE, yyvsp[-1].ttype);
		;
    break;}
case 453:
#line 2118 "parse.y"
{ yyval.ttype = parse_decl0 (yyvsp[-3].ttype, yyvsp[-4].ftype.t,
					   yyvsp[-4].ftype.lookups, yyvsp[-1].ttype, 1); ;
    break;}
case 454:
#line 2123 "parse.y"
{ parse_end_decl (yyvsp[-1].ttype, yyvsp[0].ttype, yyvsp[-4].ttype); ;
    break;}
case 455:
#line 2125 "parse.y"
{ tree d = parse_decl0 (yyvsp[-2].ttype, yyvsp[-3].ftype.t,
					yyvsp[-3].ftype.lookups, yyvsp[0].ttype, 0);
		  parse_end_decl (d, NULL_TREE, yyvsp[-1].ttype); ;
    break;}
case 456:
#line 2132 "parse.y"
{;
    break;}
case 457:
#line 2137 "parse.y"
{;
    break;}
case 458:
#line 2142 "parse.y"
{ /* Set things up as initdcl0_innards expects.  */
	      yyval.ttype = yyvsp[0].ttype;
	      yyvsp[0].ttype = yyvsp[-1].ttype;
              yyvsp[-1].ftype.t = NULL_TREE;
	      yyvsp[-1].ftype.lookups = NULL_TREE; ;
    break;}
case 459:
#line 2148 "parse.y"
{;
    break;}
case 460:
#line 2150 "parse.y"
{ tree d = parse_decl0 (yyvsp[-2].ttype, NULL_TREE, NULL_TREE, yyvsp[0].ttype, 0);
		  parse_end_decl (d, NULL_TREE, yyvsp[-1].ttype); ;
    break;}
case 461:
#line 2158 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 462:
#line 2160 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 463:
#line 2165 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 464:
#line 2167 "parse.y"
{ yyval.ttype = chainon (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 465:
#line 2172 "parse.y"
{ yyval.ttype = yyvsp[-2].ttype; ;
    break;}
case 466:
#line 2177 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 467:
#line 2179 "parse.y"
{ yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 468:
#line 2184 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 469:
#line 2186 "parse.y"
{ yyval.ttype = build_tree_list (yyvsp[0].ttype, NULL_TREE); ;
    break;}
case 470:
#line 2188 "parse.y"
{ yyval.ttype = build_tree_list (yyvsp[-3].ttype, build_tree_list (NULL_TREE, yyvsp[-1].ttype)); ;
    break;}
case 471:
#line 2190 "parse.y"
{ yyval.ttype = build_tree_list (yyvsp[-5].ttype, tree_cons (NULL_TREE, yyvsp[-3].ttype, yyvsp[-1].ttype)); ;
    break;}
case 472:
#line 2192 "parse.y"
{ yyval.ttype = build_tree_list (yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 477:
#line 2208 "parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 478:
#line 2210 "parse.y"
{ yyval.ttype = chainon (yyvsp[-2].ttype, build_tree_list (NULL_TREE, yyvsp[0].ttype)); ;
    break;}
case 479:
#line 2215 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 480:
#line 2217 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 482:
#line 2226 "parse.y"
{ yyval.ttype = build_nt (CONSTRUCTOR, NULL_TREE, NULL_TREE);
		  TREE_HAS_CONSTRUCTOR (yyval.ttype) = 1; ;
    break;}
case 483:
#line 2229 "parse.y"
{ yyval.ttype = build_nt (CONSTRUCTOR, NULL_TREE, nreverse (yyvsp[-1].ttype));
		  TREE_HAS_CONSTRUCTOR (yyval.ttype) = 1; ;
    break;}
case 484:
#line 2232 "parse.y"
{ yyval.ttype = build_nt (CONSTRUCTOR, NULL_TREE, nreverse (yyvsp[-2].ttype));
		  TREE_HAS_CONSTRUCTOR (yyval.ttype) = 1; ;
    break;}
case 485:
#line 2235 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 486:
#line 2242 "parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, yyval.ttype); ;
    break;}
case 487:
#line 2244 "parse.y"
{ yyval.ttype = tree_cons (NULL_TREE, yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 488:
#line 2247 "parse.y"
{ yyval.ttype = build_tree_list (yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 489:
#line 2249 "parse.y"
{ yyval.ttype = build_tree_list (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 490:
#line 2251 "parse.y"
{ yyval.ttype = tree_cons (yyvsp[-2].ttype, yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 491:
#line 2256 "parse.y"
{
		  expand_body (finish_function (2));
		  process_next_inline (yyvsp[-2].pi);
		;
    break;}
case 492:
#line 2261 "parse.y"
{
		  expand_body (finish_function (2));
                  process_next_inline (yyvsp[-2].pi);
		;
    break;}
case 493:
#line 2266 "parse.y"
{
		  finish_function (2);
		  process_next_inline (yyvsp[-2].pi); ;
    break;}
case 496:
#line 2280 "parse.y"
{ replace_defarg (yyvsp[-2].ttype, yyvsp[-1].ttype); ;
    break;}
case 497:
#line 2282 "parse.y"
{ replace_defarg (yyvsp[-2].ttype, error_mark_node); ;
    break;}
case 499:
#line 2288 "parse.y"
{ do_pending_defargs (); ;
    break;}
case 500:
#line 2290 "parse.y"
{ do_pending_defargs (); ;
    break;}
case 501:
#line 2295 "parse.y"
{ yyval.ttype = current_enum_type;
		  current_enum_type = start_enum (yyvsp[-1].ttype); ;
    break;}
case 502:
#line 2298 "parse.y"
{ yyval.ftype.t = current_enum_type;
		  finish_enum (current_enum_type);
		  yyval.ftype.new_type_flag = 1;
		  current_enum_type = yyvsp[-2].ttype;
		  check_for_missing_semicolon (yyval.ftype.t); ;
    break;}
case 503:
#line 2304 "parse.y"
{ yyval.ttype = current_enum_type;
		  current_enum_type = start_enum (make_anon_name ()); ;
    break;}
case 504:
#line 2307 "parse.y"
{ yyval.ftype.t = current_enum_type;
		  finish_enum (current_enum_type);
		  yyval.ftype.new_type_flag = 1;
		  current_enum_type = yyvsp[-2].ttype;
		  check_for_missing_semicolon (yyval.ftype.t); ;
    break;}
case 505:
#line 2313 "parse.y"
{ yyval.ftype.t = parse_xref_tag (enum_type_node, yyvsp[0].ttype, 1);
		  yyval.ftype.new_type_flag = 0; ;
    break;}
case 506:
#line 2316 "parse.y"
{ yyval.ftype.t = parse_xref_tag (enum_type_node, yyvsp[0].ttype, 1);
		  yyval.ftype.new_type_flag = 0; ;
    break;}
case 507:
#line 2319 "parse.y"
{ yyval.ftype.t = yyvsp[0].ttype;
		  yyval.ftype.new_type_flag = 0;
		  if (!processing_template_decl)
		    pedwarn ("using `typename' outside of template"); ;
    break;}
case 508:
#line 2325 "parse.y"
{
		  if (yyvsp[-1].ttype && yyvsp[-2].ftype.t != error_mark_node)
		    {
		      tree type = TREE_TYPE (yyvsp[-2].ftype.t);

		      if (TREE_CODE (type) == TYPENAME_TYPE)
			/* In a definition of a member class template,
                           we will get here with an implicit typename,
                           a TYPENAME_TYPE with a type. */
			type = TREE_TYPE (type);
		      maybe_process_partial_specialization (type);
		      xref_basetypes (type, yyvsp[-1].ttype);
		    }
		  yyvsp[-2].ftype.t = begin_class_definition (TREE_TYPE (yyvsp[-2].ftype.t));
		  check_class_key (current_aggr, yyvsp[-2].ftype.t);
                  current_aggr = NULL_TREE; ;
    break;}
case 509:
#line 2342 "parse.y"
{
		  int semi;
		  tree t;

		  if (yychar == YYEMPTY)
		    yychar = YYLEX;
		  semi = yychar == ';';

		  t = finish_class_definition (yyvsp[-6].ftype.t, yyvsp[0].ttype, semi, yyvsp[-6].ftype.new_type_flag);
		  yyval.ttype = t;

		  /* restore current_aggr */
		  current_aggr = TREE_CODE (t) != RECORD_TYPE
				 ? union_type_node
				 : CLASSTYPE_DECLARED_CLASS (t)
				 ? class_type_node : record_type_node;
		;
    break;}
case 510:
#line 2360 "parse.y"
{
		  done_pending_defargs ();
		  begin_inline_definitions ();
		;
    break;}
case 511:
#line 2365 "parse.y"
{
		  yyval.ftype.t = yyvsp[-3].ttype;
		  yyval.ftype.new_type_flag = 1;
		;
    break;}
case 512:
#line 2370 "parse.y"
{
		  yyval.ftype.t = TREE_TYPE (yyvsp[0].ftype.t);
		  yyval.ftype.new_type_flag = yyvsp[0].ftype.new_type_flag;
		  check_class_key (current_aggr, yyval.ftype.t);
		;
    break;}
case 516:
#line 2385 "parse.y"
{ if (pedantic && !in_system_header)
		    pedwarn ("comma at end of enumerator list"); ;
    break;}
case 518:
#line 2392 "parse.y"
{ error ("storage class specifier `%s' not allowed after struct or class", IDENTIFIER_POINTER (yyvsp[0].ttype)); ;
    break;}
case 519:
#line 2394 "parse.y"
{ error ("type specifier `%s' not allowed after struct or class", IDENTIFIER_POINTER (yyvsp[0].ttype)); ;
    break;}
case 520:
#line 2396 "parse.y"
{ error ("type qualifier `%s' not allowed after struct or class", IDENTIFIER_POINTER (yyvsp[0].ttype)); ;
    break;}
case 521:
#line 2398 "parse.y"
{ error ("no body nor ';' separates two class, struct or union declarations"); ;
    break;}
case 522:
#line 2400 "parse.y"
{ yyval.ttype = build_tree_list (yyvsp[0].ttype, yyvsp[-1].ttype); ;
    break;}
case 523:
#line 2405 "parse.y"
{
		  current_aggr = yyvsp[-1].ttype;
		  yyval.ttype = build_tree_list (NULL_TREE, yyvsp[0].ttype);
		;
    break;}
case 524:
#line 2410 "parse.y"
{
		  current_aggr = yyvsp[-2].ttype;
		  yyval.ttype = build_tree_list (yyvsp[-1].ttype, yyvsp[0].ttype);
		;
    break;}
case 525:
#line 2415 "parse.y"
{
		  current_aggr = yyvsp[-3].ttype;
		  yyval.ttype = build_tree_list (yyvsp[-1].ttype, yyvsp[0].ttype);
		;
    break;}
case 526:
#line 2420 "parse.y"
{
		  current_aggr = yyvsp[-2].ttype;
		  yyval.ttype = build_tree_list (global_namespace, yyvsp[0].ttype);
		;
    break;}
case 527:
#line 2428 "parse.y"
{
		  current_aggr = yyvsp[-1].ttype;
		  yyval.ttype = yyvsp[0].ttype;
		;
    break;}
case 528:
#line 2433 "parse.y"
{
		  current_aggr = yyvsp[-2].ttype;
		  yyval.ttype = yyvsp[0].ttype;
		;
    break;}
case 529:
#line 2438 "parse.y"
{
		  current_aggr = yyvsp[-3].ttype;
		  yyval.ttype = yyvsp[0].ttype;
		;
    break;}
case 530:
#line 2446 "parse.y"
{
		  yyval.ftype.t = parse_handle_class_head (current_aggr,
						  TREE_PURPOSE (yyvsp[0].ttype), 
						  TREE_VALUE (yyvsp[0].ttype),
						  0, &yyval.ftype.new_type_flag);
		;
    break;}
case 531:
#line 2453 "parse.y"
{
		  current_aggr = yyvsp[-1].ttype;
		  yyval.ftype.t = TYPE_MAIN_DECL (parse_xref_tag (current_aggr, yyvsp[0].ttype, 0));
		  yyval.ftype.new_type_flag = 1;
		;
    break;}
case 532:
#line 2459 "parse.y"
{
		  yyval.ftype.t = yyvsp[0].ttype;
		  yyval.ftype.new_type_flag = 0;
		;
    break;}
case 533:
#line 2467 "parse.y"
{
		  yyungetc ('{', 1);
		  yyval.ftype.t = parse_handle_class_head (current_aggr,
						  TREE_PURPOSE (yyvsp[-1].ttype), 
						  TREE_VALUE (yyvsp[-1].ttype),
						  1, 
						  &yyval.ftype.new_type_flag);
		;
    break;}
case 534:
#line 2476 "parse.y"
{
		  yyungetc (':', 1);
		  yyval.ftype.t = parse_handle_class_head (current_aggr,
						  TREE_PURPOSE (yyvsp[-1].ttype), 
						  TREE_VALUE (yyvsp[-1].ttype),
						  1, &yyval.ftype.new_type_flag);
		;
    break;}
case 535:
#line 2484 "parse.y"
{
		  yyungetc ('{', 1);
		  yyval.ftype.t = yyvsp[-1].ttype;
		  yyval.ftype.new_type_flag = 0;
		  if (TREE_CODE (TREE_TYPE (yyvsp[-1].ttype)) == RECORD_TYPE)
		    /* We might be specializing a template with a different
		       class-key.  */
		    CLASSTYPE_DECLARED_CLASS (TREE_TYPE (yyvsp[-1].ttype))
		      = (current_aggr == class_type_node);
		;
    break;}
case 536:
#line 2495 "parse.y"
{
		  yyungetc (':', 1);
		  yyval.ftype.t = yyvsp[-1].ttype;
		  yyval.ftype.new_type_flag = 0;
		  if (TREE_CODE (TREE_TYPE (yyvsp[-1].ttype)) == RECORD_TYPE)
		    /* We might be specializing a template with a different
		       class-key.  */
		    CLASSTYPE_DECLARED_CLASS (TREE_TYPE (yyvsp[-1].ttype))
		      = (current_aggr == class_type_node);
		;
    break;}
case 537:
#line 2506 "parse.y"
{
		  yyungetc ('{', 1);
		  current_aggr = yyvsp[-2].ttype;
		  yyval.ftype.t = parse_handle_class_head (current_aggr,
						  NULL_TREE, yyvsp[-1].ttype,
						  1, &yyval.ftype.new_type_flag);
		;
    break;}
case 538:
#line 2514 "parse.y"
{
		  yyungetc (':', 1);
		  current_aggr = yyvsp[-2].ttype;
		  yyval.ftype.t = parse_handle_class_head (current_aggr,
						  NULL_TREE, yyvsp[-1].ttype,
						  1, &yyval.ftype.new_type_flag);
		;
    break;}
case 539:
#line 2522 "parse.y"
{
		  current_aggr = yyvsp[-1].ttype;
		  yyval.ftype.t = TYPE_MAIN_DECL (parse_xref_tag (yyvsp[-1].ttype, 
							 make_anon_name (), 
							 0));
		  yyval.ftype.new_type_flag = 0;
		  CLASSTYPE_DECLARED_CLASS (TREE_TYPE (yyval.ftype.t))
		    = yyvsp[-1].ttype == class_type_node;
		  yyungetc ('{', 1);
		;
    break;}
case 540:
#line 2536 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 541:
#line 2538 "parse.y"
{ error ("no bases given following `:'");
		  yyval.ttype = NULL_TREE; ;
    break;}
case 542:
#line 2541 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 544:
#line 2547 "parse.y"
{ yyval.ttype = chainon (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 545:
#line 2552 "parse.y"
{ yyval.ttype = finish_base_specifier (access_default_node, yyvsp[0].ttype); ;
    break;}
case 546:
#line 2554 "parse.y"
{ yyval.ttype = finish_base_specifier (yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 547:
#line 2559 "parse.y"
{ if (!TYPE_P (yyval.ttype))
		    yyval.ttype = error_mark_node; ;
    break;}
case 548:
#line 2562 "parse.y"
{ yyval.ttype = TREE_TYPE (yyval.ttype); ;
    break;}
case 550:
#line 2568 "parse.y"
{ if (yyvsp[-1].ttype != ridpointers[(int)RID_VIRTUAL])
		    error ("`%D' access", yyvsp[-1].ttype);
		  yyval.ttype = access_default_virtual_node; ;
    break;}
case 551:
#line 2572 "parse.y"
{
		  if (yyvsp[-2].ttype != access_default_virtual_node)
		    error ("multiple access specifiers");
		  else if (yyvsp[-1].ttype == access_public_node)
		    yyval.ttype = access_public_virtual_node;
		  else if (yyvsp[-1].ttype == access_protected_node)
		    yyval.ttype = access_protected_virtual_node;
		  else /* $2 == access_private_node */
		    yyval.ttype = access_private_virtual_node;
		;
    break;}
case 552:
#line 2583 "parse.y"
{ if (yyvsp[-1].ttype != ridpointers[(int)RID_VIRTUAL])
		    error ("`%D' access", yyvsp[-1].ttype);
		  else if (yyval.ttype == access_public_node)
		    yyval.ttype = access_public_virtual_node;
		  else if (yyval.ttype == access_protected_node)
		    yyval.ttype = access_protected_virtual_node;
		  else if (yyval.ttype == access_private_node)
		    yyval.ttype = access_private_virtual_node;
		  else
		    error ("multiple `virtual' specifiers");
		;
    break;}
case 557:
#line 2604 "parse.y"
{
		  current_access_specifier = yyvsp[-1].ttype;
                ;
    break;}
case 558:
#line 2613 "parse.y"
{
		  finish_member_declaration (yyvsp[0].ttype);
		  current_aggr = NULL_TREE;
		  reset_type_access_control ();
		;
    break;}
case 559:
#line 2619 "parse.y"
{
		  finish_member_declaration (yyvsp[0].ttype);
		  current_aggr = NULL_TREE;
		  reset_type_access_control ();
		;
    break;}
case 561:
#line 2629 "parse.y"
{ error ("missing ';' before right brace");
		  yyungetc ('}', 0); ;
    break;}
case 562:
#line 2634 "parse.y"
{ yyval.ttype = finish_method (yyval.ttype); ;
    break;}
case 563:
#line 2636 "parse.y"
{ yyval.ttype = finish_method (yyval.ttype); ;
    break;}
case 564:
#line 2638 "parse.y"
{ yyval.ttype = finish_method (yyval.ttype); ;
    break;}
case 565:
#line 2640 "parse.y"
{ yyval.ttype = finish_method (yyval.ttype); ;
    break;}
case 566:
#line 2642 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 567:
#line 2644 "parse.y"
{ yyval.ttype = yyvsp[0].ttype;
		  pedantic = yyvsp[-1].itype; ;
    break;}
case 568:
#line 2647 "parse.y"
{
		  if (yyvsp[0].ttype)
		    yyval.ttype = finish_member_template_decl (yyvsp[0].ttype);
		  else
		    /* The component was already processed.  */
		    yyval.ttype = NULL_TREE;

		  finish_template_decl (yyvsp[-1].ttype);
		;
    break;}
case 569:
#line 2657 "parse.y"
{
		  yyval.ttype = finish_member_class_template (yyvsp[-1].ftype.t);
		  finish_template_decl (yyvsp[-2].ttype);
		;
    break;}
case 570:
#line 2662 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 571:
#line 2670 "parse.y"
{
		  /* Most of the productions for component_decl only
		     allow the creation of one new member, so we call
		     finish_member_declaration in component_decl_list.
		     For this rule and the next, however, there can be
		     more than one member, e.g.:

		       int i, j;

		     and we need the first member to be fully
		     registered before the second is processed.
		     Therefore, the rules for components take care of
		     this processing.  To avoid registering the
		     components more than once, we send NULL_TREE up
		     here; that lets finish_member_declaration know
		     that there is nothing to do.  */
		  if (!yyvsp[0].itype)
		    grok_x_components (yyvsp[-1].ftype.t);
		  yyval.ttype = NULL_TREE;
		;
    break;}
case 572:
#line 2691 "parse.y"
{
		  if (!yyvsp[0].itype)
		    grok_x_components (yyvsp[-1].ftype.t);
		  yyval.ttype = NULL_TREE;
		;
    break;}
case 573:
#line 2697 "parse.y"
{ yyval.ttype = grokfield (yyval.ttype, NULL_TREE, yyvsp[0].ttype, yyvsp[-2].ttype, yyvsp[-1].ttype); ;
    break;}
case 574:
#line 2699 "parse.y"
{ yyval.ttype = grokfield (yyval.ttype, NULL_TREE, yyvsp[0].ttype, yyvsp[-2].ttype, yyvsp[-1].ttype); ;
    break;}
case 575:
#line 2701 "parse.y"
{ yyval.ttype = grokbitfield (NULL_TREE, NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 576:
#line 2703 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 577:
#line 2714 "parse.y"
{ tree specs, attrs;
		  split_specs_attrs (yyvsp[-4].ftype.t, &specs, &attrs);
		  yyval.ttype = grokfield (yyvsp[-3].ttype, specs, yyvsp[0].ttype, yyvsp[-2].ttype,
				  chainon (yyvsp[-1].ttype, attrs)); ;
    break;}
case 578:
#line 2719 "parse.y"
{ yyval.ttype = grokfield (yyval.ttype, NULL_TREE, yyvsp[0].ttype, yyvsp[-2].ttype, yyvsp[-1].ttype); ;
    break;}
case 579:
#line 2721 "parse.y"
{ yyval.ttype = do_class_using_decl (yyvsp[0].ttype); ;
    break;}
case 580:
#line 2728 "parse.y"
{ yyval.itype = 0; ;
    break;}
case 581:
#line 2730 "parse.y"
{
		  if (PROCESSING_REAL_TEMPLATE_DECL_P ())
		    yyvsp[0].ttype = finish_member_template_decl (yyvsp[0].ttype);
		  finish_member_declaration (yyvsp[0].ttype);
		  yyval.itype = 1;
		;
    break;}
case 582:
#line 2737 "parse.y"
{
		  check_multiple_declarators ();
		  if (PROCESSING_REAL_TEMPLATE_DECL_P ())
		    yyvsp[0].ttype = finish_member_template_decl (yyvsp[0].ttype);
		  finish_member_declaration (yyvsp[0].ttype);
		  yyval.itype = 2;
		;
    break;}
case 583:
#line 2748 "parse.y"
{ yyval.itype = 0; ;
    break;}
case 584:
#line 2750 "parse.y"
{
		  if (PROCESSING_REAL_TEMPLATE_DECL_P ())
		    yyvsp[0].ttype = finish_member_template_decl (yyvsp[0].ttype);
		  finish_member_declaration (yyvsp[0].ttype);
		  yyval.itype = 1;
		;
    break;}
case 585:
#line 2757 "parse.y"
{
		  check_multiple_declarators ();
		  if (PROCESSING_REAL_TEMPLATE_DECL_P ())
		    yyvsp[0].ttype = finish_member_template_decl (yyvsp[0].ttype);
		  finish_member_declaration (yyvsp[0].ttype);
		  yyval.itype = 2;
		;
    break;}
case 590:
#line 2778 "parse.y"
{ yyval.ttype = parse_field0 (yyvsp[-3].ttype, yyvsp[-4].ftype.t, yyvsp[-4].ftype.lookups,
				     yyvsp[-1].ttype, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 591:
#line 2781 "parse.y"
{ yyval.ttype = parse_bitfield0 (yyvsp[-3].ttype, yyvsp[-4].ftype.t, yyvsp[-4].ftype.lookups,
					yyvsp[0].ttype, yyvsp[-1].ttype); ;
    break;}
case 592:
#line 2787 "parse.y"
{ yyval.ttype = parse_field0 (yyvsp[-3].ttype, yyvsp[-4].ftype.t, yyvsp[-4].ftype.lookups,
				     yyvsp[-1].ttype, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 593:
#line 2790 "parse.y"
{ yyval.ttype = parse_field0 (yyvsp[-3].ttype, yyvsp[-4].ftype.t, yyvsp[-4].ftype.lookups,
				     yyvsp[-1].ttype, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 594:
#line 2793 "parse.y"
{ yyval.ttype = parse_bitfield0 (yyvsp[-3].ttype, yyvsp[-4].ftype.t, yyvsp[-4].ftype.lookups,
					yyvsp[0].ttype, yyvsp[-1].ttype); ;
    break;}
case 595:
#line 2796 "parse.y"
{ yyval.ttype = parse_bitfield0 (NULL_TREE, yyvsp[-3].ftype.t,
					yyvsp[-3].ftype.lookups, yyvsp[0].ttype, yyvsp[-1].ttype); ;
    break;}
case 596:
#line 2802 "parse.y"
{ yyval.ttype = parse_field (yyvsp[-3].ttype, yyvsp[-1].ttype, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 597:
#line 2804 "parse.y"
{ yyval.ttype = parse_bitfield (yyvsp[-3].ttype, yyvsp[0].ttype, yyvsp[-1].ttype); ;
    break;}
case 598:
#line 2809 "parse.y"
{ yyval.ttype = parse_field (yyvsp[-3].ttype, yyvsp[-1].ttype, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 599:
#line 2811 "parse.y"
{ yyval.ttype = parse_bitfield (yyvsp[-3].ttype, yyvsp[0].ttype, yyvsp[-1].ttype); ;
    break;}
case 600:
#line 2813 "parse.y"
{ yyval.ttype = parse_bitfield (NULL_TREE, yyvsp[0].ttype, yyvsp[-1].ttype); ;
    break;}
case 605:
#line 2832 "parse.y"
{ build_enumerator (yyvsp[0].ttype, NULL_TREE, current_enum_type); ;
    break;}
case 606:
#line 2834 "parse.y"
{ build_enumerator (yyvsp[-2].ttype, yyvsp[0].ttype, current_enum_type); ;
    break;}
case 607:
#line 2840 "parse.y"
{ yyval.ftype.t = build_tree_list (yyvsp[-1].ftype.t, yyvsp[0].ttype);
		  yyval.ftype.new_type_flag = yyvsp[-1].ftype.new_type_flag; ;
    break;}
case 608:
#line 2843 "parse.y"
{ yyval.ftype.t = build_tree_list (yyvsp[0].ftype.t, NULL_TREE);
		  yyval.ftype.new_type_flag = yyvsp[0].ftype.new_type_flag; ;
    break;}
case 609:
#line 2848 "parse.y"
{
		  if (pedantic)
		    pedwarn ("ISO C++ forbids array dimensions with parenthesized type in new");
		  yyval.ftype.t = build_nt (ARRAY_REF, TREE_VALUE (yyvsp[-4].ftype.t), yyvsp[-1].ttype);
		  yyval.ftype.t = build_tree_list (TREE_PURPOSE (yyvsp[-4].ftype.t), yyval.ftype.t);
		  yyval.ftype.new_type_flag = yyvsp[-4].ftype.new_type_flag;
		;
    break;}
case 610:
#line 2859 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 611:
#line 2861 "parse.y"
{ yyval.ttype = tree_cons (NULL_TREE, yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 612:
#line 2866 "parse.y"
{ yyval.ftype.t = hash_tree_cons (NULL_TREE, yyvsp[0].ttype, NULL_TREE);
		  yyval.ftype.new_type_flag = 0; ;
    break;}
case 613:
#line 2869 "parse.y"
{ yyval.ftype.t = hash_tree_cons (NULL_TREE, yyvsp[0].ttype, yyvsp[-1].ftype.t);
		  yyval.ftype.new_type_flag = yyvsp[-1].ftype.new_type_flag; ;
    break;}
case 614:
#line 2872 "parse.y"
{ yyval.ftype.t = hash_tree_cons (yyvsp[0].ttype, NULL_TREE, NULL_TREE);
		  yyval.ftype.new_type_flag = 0; ;
    break;}
case 615:
#line 2875 "parse.y"
{ yyval.ftype.t = hash_tree_cons (yyvsp[0].ttype, NULL_TREE, yyvsp[-1].ftype.t);
		  yyval.ftype.new_type_flag = yyvsp[-1].ftype.new_type_flag; ;
    break;}
case 616:
#line 2885 "parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 617:
#line 2887 "parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 618:
#line 2889 "parse.y"
{ yyval.ttype = empty_parms (); ;
    break;}
case 619:
#line 2891 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 621:
#line 2899 "parse.y"
{
		  /* Provide support for '(' attributes '*' declarator ')'
		     etc */
		  yyval.ttype = tree_cons (yyvsp[-1].ttype, yyvsp[0].ttype, NULL_TREE);
		;
    break;}
case 622:
#line 2909 "parse.y"
{ yyval.ttype = make_pointer_declarator (yyvsp[-1].ftype.t, yyvsp[0].ttype); ;
    break;}
case 623:
#line 2911 "parse.y"
{ yyval.ttype = make_reference_declarator (yyvsp[-1].ftype.t, yyvsp[0].ttype); ;
    break;}
case 624:
#line 2913 "parse.y"
{ yyval.ttype = make_pointer_declarator (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 625:
#line 2915 "parse.y"
{ yyval.ttype = make_reference_declarator (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 626:
#line 2917 "parse.y"
{ tree arg = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype);
		  yyval.ttype = build_nt (SCOPE_REF, yyvsp[-2].ttype, arg);
		;
    break;}
case 628:
#line 2925 "parse.y"
{ yyval.ttype = make_call_declarator (yyval.ttype, yyvsp[-2].ttype, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 629:
#line 2927 "parse.y"
{ yyval.ttype = build_nt (ARRAY_REF, yyval.ttype, yyvsp[-1].ttype); ;
    break;}
case 630:
#line 2929 "parse.y"
{ yyval.ttype = build_nt (ARRAY_REF, yyval.ttype, NULL_TREE); ;
    break;}
case 631:
#line 2931 "parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 632:
#line 2933 "parse.y"
{ push_nested_class (yyvsp[-1].ttype, 3);
		  yyval.ttype = build_nt (SCOPE_REF, yyval.ttype, yyvsp[0].ttype);
		  TREE_COMPLEXITY (yyval.ttype) = current_class_depth; ;
    break;}
case 634:
#line 2941 "parse.y"
{
		  if (TREE_CODE (yyvsp[0].ttype) == IDENTIFIER_NODE)
		    {
		      yyval.ttype = lookup_name (yyvsp[0].ttype, 1);
		      maybe_note_name_used_in_class (yyvsp[0].ttype, yyval.ttype);
		    }
		  else
		    yyval.ttype = yyvsp[0].ttype;
		;
    break;}
case 635:
#line 2951 "parse.y"
{
		  if (TREE_CODE (yyvsp[0].ttype) == IDENTIFIER_NODE)
		    yyval.ttype = IDENTIFIER_GLOBAL_VALUE (yyvsp[0].ttype);
		  else
		    yyval.ttype = yyvsp[0].ttype;
		  got_scope = NULL_TREE;
		;
    break;}
case 638:
#line 2964 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 639:
#line 2969 "parse.y"
{ yyval.ttype = get_type_decl (yyvsp[0].ttype); ;
    break;}
case 641:
#line 2978 "parse.y"
{
		  /* Provide support for '(' attributes '*' declarator ')'
		     etc */
		  yyval.ttype = tree_cons (yyvsp[-1].ttype, yyvsp[0].ttype, NULL_TREE);
		;
    break;}
case 642:
#line 2987 "parse.y"
{ yyval.ttype = make_pointer_declarator (yyvsp[-1].ftype.t, yyvsp[0].ttype); ;
    break;}
case 643:
#line 2989 "parse.y"
{ yyval.ttype = make_reference_declarator (yyvsp[-1].ftype.t, yyvsp[0].ttype); ;
    break;}
case 644:
#line 2991 "parse.y"
{ yyval.ttype = make_pointer_declarator (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 645:
#line 2993 "parse.y"
{ yyval.ttype = make_reference_declarator (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 646:
#line 2995 "parse.y"
{ tree arg = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype);
		  yyval.ttype = build_nt (SCOPE_REF, yyvsp[-2].ttype, arg);
		;
    break;}
case 648:
#line 3003 "parse.y"
{ yyval.ttype = make_pointer_declarator (yyvsp[-1].ftype.t, yyvsp[0].ttype); ;
    break;}
case 649:
#line 3005 "parse.y"
{ yyval.ttype = make_reference_declarator (yyvsp[-1].ftype.t, yyvsp[0].ttype); ;
    break;}
case 650:
#line 3007 "parse.y"
{ yyval.ttype = make_pointer_declarator (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 651:
#line 3009 "parse.y"
{ yyval.ttype = make_reference_declarator (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 652:
#line 3011 "parse.y"
{ tree arg = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype);
		  yyval.ttype = build_nt (SCOPE_REF, yyvsp[-2].ttype, arg);
		;
    break;}
case 654:
#line 3019 "parse.y"
{ yyval.ttype = make_call_declarator (yyval.ttype, yyvsp[-2].ttype, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 655:
#line 3021 "parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 656:
#line 3023 "parse.y"
{ yyval.ttype = build_nt (ARRAY_REF, yyval.ttype, yyvsp[-1].ttype); ;
    break;}
case 657:
#line 3025 "parse.y"
{ yyval.ttype = build_nt (ARRAY_REF, yyval.ttype, NULL_TREE); ;
    break;}
case 658:
#line 3027 "parse.y"
{ enter_scope_of (yyvsp[0].ttype); ;
    break;}
case 659:
#line 3029 "parse.y"
{ enter_scope_of (yyvsp[0].ttype); yyval.ttype = yyvsp[0].ttype;;
    break;}
case 660:
#line 3031 "parse.y"
{ yyval.ttype = build_nt (SCOPE_REF, global_namespace, yyvsp[0].ttype);
		  enter_scope_of (yyval.ttype);
		;
    break;}
case 661:
#line 3035 "parse.y"
{ got_scope = NULL_TREE;
		  yyval.ttype = build_nt (SCOPE_REF, yyvsp[-1].ttype, yyvsp[0].ttype);
		  enter_scope_of (yyval.ttype);
		;
    break;}
case 662:
#line 3043 "parse.y"
{ got_scope = NULL_TREE;
		  yyval.ttype = build_nt (SCOPE_REF, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 663:
#line 3046 "parse.y"
{ got_scope = NULL_TREE;
 		  yyval.ttype = build_nt (SCOPE_REF, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 664:
#line 3052 "parse.y"
{ got_scope = NULL_TREE;
		  yyval.ttype = build_nt (SCOPE_REF, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 665:
#line 3055 "parse.y"
{ got_scope = NULL_TREE;
		  yyval.ttype = build_nt (SCOPE_REF, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 667:
#line 3062 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 668:
#line 3067 "parse.y"
{ yyval.ttype = build_functional_cast (yyvsp[-3].ftype.t, yyvsp[-1].ttype); ;
    break;}
case 669:
#line 3069 "parse.y"
{ yyval.ttype = reparse_decl_as_expr (yyvsp[-3].ftype.t, yyvsp[-1].ttype); ;
    break;}
case 670:
#line 3071 "parse.y"
{ yyval.ttype = reparse_absdcl_as_expr (yyvsp[-1].ftype.t, yyvsp[0].ttype); ;
    break;}
case 675:
#line 3083 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 676:
#line 3085 "parse.y"
{ got_scope = yyval.ttype
		    = make_typename_type (yyvsp[-3].ttype, yyvsp[-1].ttype, tf_error | tf_parsing); ;
    break;}
case 677:
#line 3089 "parse.y"
{ got_scope = yyval.ttype
		    = make_typename_type (yyvsp[-2].ttype, yyvsp[-1].ttype, tf_error | tf_parsing); ;
    break;}
case 678:
#line 3092 "parse.y"
{ got_scope = yyval.ttype
		    = make_typename_type (yyvsp[-2].ttype, yyvsp[-1].ttype, tf_error | tf_parsing); ;
    break;}
case 679:
#line 3100 "parse.y"
{
		  if (TREE_CODE (yyvsp[-1].ttype) == IDENTIFIER_NODE)
		    {
		      yyval.ttype = lastiddecl;
		      maybe_note_name_used_in_class (yyvsp[-1].ttype, yyval.ttype);
		    }
		  got_scope = yyval.ttype =
		    complete_type (TYPE_MAIN_VARIANT (TREE_TYPE (yyval.ttype)));
		;
    break;}
case 680:
#line 3110 "parse.y"
{
		  if (TREE_CODE (yyvsp[-1].ttype) == IDENTIFIER_NODE)
		    yyval.ttype = lastiddecl;
		  got_scope = yyval.ttype = TREE_TYPE (yyval.ttype);
		;
    break;}
case 681:
#line 3116 "parse.y"
{
		  if (TREE_CODE (yyval.ttype) == IDENTIFIER_NODE)
		    yyval.ttype = lastiddecl;
		  got_scope = yyval.ttype;
		;
    break;}
case 682:
#line 3122 "parse.y"
{ got_scope = yyval.ttype = complete_type (TREE_TYPE (yyvsp[-1].ttype)); ;
    break;}
case 684:
#line 3128 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 685:
#line 3133 "parse.y"
{
		  if (TYPE_P (yyvsp[-1].ttype))
		    yyval.ttype = make_typename_type (yyvsp[-1].ttype, yyvsp[0].ttype, tf_error | tf_parsing);
		  else if (TREE_CODE (yyvsp[0].ttype) == IDENTIFIER_NODE)
		    error ("`%T' is not a class or namespace", yyvsp[0].ttype);
		  else
		    {
		      yyval.ttype = yyvsp[0].ttype;
		      if (TREE_CODE (yyval.ttype) == TYPE_DECL)
			yyval.ttype = TREE_TYPE (yyval.ttype);
		    }
		;
    break;}
case 686:
#line 3146 "parse.y"
{ yyval.ttype = TREE_TYPE (yyvsp[0].ttype); ;
    break;}
case 687:
#line 3148 "parse.y"
{ yyval.ttype = make_typename_type (yyvsp[-1].ttype, yyvsp[0].ttype, tf_error | tf_parsing); ;
    break;}
case 688:
#line 3150 "parse.y"
{ yyval.ttype = make_typename_type (yyvsp[-2].ttype, yyvsp[0].ttype, tf_error | tf_parsing); ;
    break;}
case 689:
#line 3155 "parse.y"
{
		  if (TREE_CODE (yyvsp[0].ttype) == IDENTIFIER_NODE)
		    error ("`%T' is not a class or namespace", yyvsp[0].ttype);
		  else if (TREE_CODE (yyvsp[0].ttype) == TYPE_DECL)
		    yyval.ttype = TREE_TYPE (yyvsp[0].ttype);
		;
    break;}
case 690:
#line 3162 "parse.y"
{
		  if (TYPE_P (yyvsp[-1].ttype))
		    yyval.ttype = make_typename_type (yyvsp[-1].ttype, yyvsp[0].ttype, tf_error | tf_parsing);
		  else if (TREE_CODE (yyvsp[0].ttype) == IDENTIFIER_NODE)
		    error ("`%T' is not a class or namespace", yyvsp[0].ttype);
		  else
		    {
		      yyval.ttype = yyvsp[0].ttype;
		      if (TREE_CODE (yyval.ttype) == TYPE_DECL)
			yyval.ttype = TREE_TYPE (yyval.ttype);
		    }
		;
    break;}
case 691:
#line 3175 "parse.y"
{ got_scope = yyval.ttype
		    = make_typename_type (yyvsp[-2].ttype, yyvsp[-1].ttype, tf_error | tf_parsing); ;
    break;}
case 692:
#line 3178 "parse.y"
{ got_scope = yyval.ttype
		    = make_typename_type (yyvsp[-3].ttype, yyvsp[-1].ttype, tf_error | tf_parsing); ;
    break;}
case 693:
#line 3186 "parse.y"
{
		  if (TREE_CODE (yyvsp[-1].ttype) != TYPE_DECL)
		    yyval.ttype = lastiddecl;

		  /* Retrieve the type for the identifier, which might involve
		     some computation. */
		  got_scope = complete_type (TREE_TYPE (yyval.ttype));

		  if (yyval.ttype == error_mark_node)
		    error ("`%T' is not a class or namespace", yyvsp[-1].ttype);
		;
    break;}
case 694:
#line 3198 "parse.y"
{
		  if (TREE_CODE (yyvsp[-1].ttype) != TYPE_DECL)
		    yyval.ttype = lastiddecl;
		  got_scope = complete_type (TREE_TYPE (yyval.ttype));
		;
    break;}
case 695:
#line 3204 "parse.y"
{ got_scope = yyval.ttype = complete_type (TREE_TYPE (yyval.ttype)); ;
    break;}
case 698:
#line 3208 "parse.y"
{
		  if (TREE_CODE (yyval.ttype) == IDENTIFIER_NODE)
		    yyval.ttype = lastiddecl;
		  got_scope = yyval.ttype;
		;
    break;}
case 699:
#line 3217 "parse.y"
{ yyval.ttype = build_min_nt (TEMPLATE_ID_EXPR, yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 700:
#line 3222 "parse.y"
{
		  if (TREE_CODE (yyvsp[0].ttype) == IDENTIFIER_NODE)
		    yyval.ttype = IDENTIFIER_GLOBAL_VALUE (yyvsp[0].ttype);
		  else
		    yyval.ttype = yyvsp[0].ttype;
		  got_scope = NULL_TREE;
		;
    break;}
case 702:
#line 3231 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 703:
#line 3236 "parse.y"
{ got_scope = NULL_TREE; ;
    break;}
case 704:
#line 3238 "parse.y"
{ yyval.ttype = yyvsp[-1].ttype; got_scope = NULL_TREE; ;
    break;}
case 705:
#line 3245 "parse.y"
{ got_scope = void_type_node; ;
    break;}
case 706:
#line 3251 "parse.y"
{ yyval.ttype = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 707:
#line 3253 "parse.y"
{ yyval.ttype = make_pointer_declarator (yyvsp[0].ttype, NULL_TREE); ;
    break;}
case 708:
#line 3255 "parse.y"
{ yyval.ttype = make_reference_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 709:
#line 3257 "parse.y"
{ yyval.ttype = make_reference_declarator (yyvsp[0].ttype, NULL_TREE); ;
    break;}
case 710:
#line 3259 "parse.y"
{ tree arg = make_pointer_declarator (yyvsp[0].ttype, NULL_TREE);
		  yyval.ttype = build_nt (SCOPE_REF, yyvsp[-1].ttype, arg);
		;
    break;}
case 711:
#line 3263 "parse.y"
{ tree arg = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype);
		  yyval.ttype = build_nt (SCOPE_REF, yyvsp[-2].ttype, arg);
		;
    break;}
case 713:
#line 3272 "parse.y"
{ yyval.ttype = build_nt (ARRAY_REF, NULL_TREE, yyvsp[-1].ttype); ;
    break;}
case 714:
#line 3274 "parse.y"
{ yyval.ttype = build_nt (ARRAY_REF, yyval.ttype, yyvsp[-1].ttype); ;
    break;}
case 716:
#line 3280 "parse.y"
{
		  /* Provide support for '(' attributes '*' declarator ')'
		     etc */
		  yyval.ttype = tree_cons (yyvsp[-1].ttype, yyvsp[0].ttype, NULL_TREE);
		;
    break;}
case 717:
#line 3290 "parse.y"
{ yyval.ttype = make_pointer_declarator (yyvsp[-1].ftype.t, yyvsp[0].ttype); ;
    break;}
case 718:
#line 3292 "parse.y"
{ yyval.ttype = make_pointer_declarator (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 719:
#line 3294 "parse.y"
{ yyval.ttype = make_pointer_declarator (yyvsp[0].ftype.t, NULL_TREE); ;
    break;}
case 720:
#line 3296 "parse.y"
{ yyval.ttype = make_pointer_declarator (NULL_TREE, NULL_TREE); ;
    break;}
case 721:
#line 3298 "parse.y"
{ yyval.ttype = make_reference_declarator (yyvsp[-1].ftype.t, yyvsp[0].ttype); ;
    break;}
case 722:
#line 3300 "parse.y"
{ yyval.ttype = make_reference_declarator (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 723:
#line 3302 "parse.y"
{ yyval.ttype = make_reference_declarator (yyvsp[0].ftype.t, NULL_TREE); ;
    break;}
case 724:
#line 3304 "parse.y"
{ yyval.ttype = make_reference_declarator (NULL_TREE, NULL_TREE); ;
    break;}
case 725:
#line 3306 "parse.y"
{ tree arg = make_pointer_declarator (yyvsp[0].ttype, NULL_TREE);
		  yyval.ttype = build_nt (SCOPE_REF, yyvsp[-1].ttype, arg);
		;
    break;}
case 726:
#line 3310 "parse.y"
{ tree arg = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype);
		  yyval.ttype = build_nt (SCOPE_REF, yyvsp[-2].ttype, arg);
		;
    break;}
case 728:
#line 3319 "parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 729:
#line 3322 "parse.y"
{ yyval.ttype = make_call_declarator (yyval.ttype, yyvsp[-3].ttype, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 730:
#line 3324 "parse.y"
{ yyval.ttype = make_call_declarator (yyval.ttype, empty_parms (), yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 731:
#line 3326 "parse.y"
{ yyval.ttype = build_nt (ARRAY_REF, yyval.ttype, yyvsp[-1].ttype); ;
    break;}
case 732:
#line 3328 "parse.y"
{ yyval.ttype = build_nt (ARRAY_REF, yyval.ttype, NULL_TREE); ;
    break;}
case 733:
#line 3330 "parse.y"
{ yyval.ttype = make_call_declarator (NULL_TREE, yyvsp[-3].ttype, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 734:
#line 3332 "parse.y"
{ set_quals_and_spec (yyval.ttype, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 735:
#line 3334 "parse.y"
{ set_quals_and_spec (yyval.ttype, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 736:
#line 3336 "parse.y"
{ yyval.ttype = build_nt (ARRAY_REF, NULL_TREE, yyvsp[-1].ttype); ;
    break;}
case 737:
#line 3338 "parse.y"
{ yyval.ttype = build_nt (ARRAY_REF, NULL_TREE, NULL_TREE); ;
    break;}
case 744:
#line 3361 "parse.y"
{ if (pedantic)
		    pedwarn ("ISO C++ forbids label declarations"); ;
    break;}
case 747:
#line 3372 "parse.y"
{
		  while (yyvsp[-1].ttype)
		    {
		      finish_label_decl (TREE_VALUE (yyvsp[-1].ttype));
		      yyvsp[-1].ttype = TREE_CHAIN (yyvsp[-1].ttype);
		    }
		;
    break;}
case 748:
#line 3383 "parse.y"
{ yyval.ttype = begin_compound_stmt (0); ;
    break;}
case 749:
#line 3385 "parse.y"
{ STMT_LINENO (yyvsp[-1].ttype) = yyvsp[-3].itype;
		  finish_compound_stmt (0, yyvsp[-1].ttype); ;
    break;}
case 750:
#line 3391 "parse.y"
{ last_expr_type = NULL_TREE; ;
    break;}
case 751:
#line 3396 "parse.y"
{ yyval.ttype = begin_if_stmt ();
		  cond_stmt_keyword = "if"; ;
    break;}
case 752:
#line 3399 "parse.y"
{ finish_if_stmt_cond (yyvsp[0].ttype, yyvsp[-1].ttype); ;
    break;}
case 753:
#line 3401 "parse.y"
{ yyval.ttype = yyvsp[-3].ttype;
		  finish_then_clause (yyvsp[-3].ttype); ;
    break;}
case 755:
#line 3408 "parse.y"
{ yyval.ttype = begin_compound_stmt (0); ;
    break;}
case 756:
#line 3410 "parse.y"
{ STMT_LINENO (yyvsp[-2].ttype) = yyvsp[-1].itype;
		  if (yyvsp[0].ttype) STMT_LINENO (yyvsp[0].ttype) = yyvsp[-1].itype;
		  finish_compound_stmt (0, yyvsp[-2].ttype); ;
    break;}
case 758:
#line 3418 "parse.y"
{ if (yyvsp[0].ttype) STMT_LINENO (yyvsp[0].ttype) = yyvsp[-1].itype; ;
    break;}
case 759:
#line 3423 "parse.y"
{ finish_stmt ();
		  yyval.ttype = NULL_TREE; ;
    break;}
case 760:
#line 3426 "parse.y"
{ yyval.ttype = finish_expr_stmt (yyvsp[-1].ttype); ;
    break;}
case 761:
#line 3428 "parse.y"
{ begin_else_clause (); ;
    break;}
case 762:
#line 3430 "parse.y"
{
		  yyval.ttype = yyvsp[-3].ttype;
		  finish_else_clause (yyvsp[-3].ttype);
		  finish_if_stmt ();
		;
    break;}
case 763:
#line 3436 "parse.y"
{ yyval.ttype = yyvsp[0].ttype;
		  finish_if_stmt (); ;
    break;}
case 764:
#line 3439 "parse.y"
{
		  yyval.ttype = begin_while_stmt ();
		  cond_stmt_keyword = "while";
		;
    break;}
case 765:
#line 3444 "parse.y"
{ finish_while_stmt_cond (yyvsp[0].ttype, yyvsp[-1].ttype); ;
    break;}
case 766:
#line 3446 "parse.y"
{ yyval.ttype = yyvsp[-3].ttype;
		  finish_while_stmt (yyvsp[-3].ttype); ;
    break;}
case 767:
#line 3449 "parse.y"
{ yyval.ttype = begin_do_stmt (); ;
    break;}
case 768:
#line 3451 "parse.y"
{
		  finish_do_body (yyvsp[-2].ttype);
		  cond_stmt_keyword = "do";
		;
    break;}
case 769:
#line 3456 "parse.y"
{ yyval.ttype = yyvsp[-5].ttype;
		  finish_do_stmt (yyvsp[-1].ttype, yyvsp[-5].ttype); ;
    break;}
case 770:
#line 3459 "parse.y"
{ yyval.ttype = begin_for_stmt (); ;
    break;}
case 771:
#line 3461 "parse.y"
{ finish_for_init_stmt (yyvsp[-2].ttype); ;
    break;}
case 772:
#line 3463 "parse.y"
{ finish_for_cond (yyvsp[-1].ttype, yyvsp[-5].ttype); ;
    break;}
case 773:
#line 3465 "parse.y"
{ finish_for_expr (yyvsp[-1].ttype, yyvsp[-8].ttype); ;
    break;}
case 774:
#line 3467 "parse.y"
{ yyval.ttype = yyvsp[-10].ttype;
		  finish_for_stmt (yyvsp[-10].ttype); ;
    break;}
case 775:
#line 3470 "parse.y"
{ yyval.ttype = begin_switch_stmt (); ;
    break;}
case 776:
#line 3472 "parse.y"
{ finish_switch_cond (yyvsp[-1].ttype, yyvsp[-3].ttype); ;
    break;}
case 777:
#line 3474 "parse.y"
{ yyval.ttype = yyvsp[-5].ttype;
		  finish_switch_stmt (yyvsp[-5].ttype); ;
    break;}
case 778:
#line 3477 "parse.y"
{ yyval.ttype = finish_case_label (yyvsp[-1].ttype, NULL_TREE); ;
    break;}
case 779:
#line 3479 "parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 780:
#line 3481 "parse.y"
{ yyval.ttype = finish_case_label (yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 781:
#line 3483 "parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 782:
#line 3485 "parse.y"
{ yyval.ttype = finish_case_label (NULL_TREE, NULL_TREE); ;
    break;}
case 783:
#line 3487 "parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 784:
#line 3489 "parse.y"
{ yyval.ttype = finish_break_stmt (); ;
    break;}
case 785:
#line 3491 "parse.y"
{ yyval.ttype = finish_continue_stmt (); ;
    break;}
case 786:
#line 3493 "parse.y"
{ yyval.ttype = finish_return_stmt (NULL_TREE); ;
    break;}
case 787:
#line 3495 "parse.y"
{ yyval.ttype = finish_return_stmt (yyvsp[-1].ttype); ;
    break;}
case 788:
#line 3497 "parse.y"
{ yyval.ttype = finish_asm_stmt (yyvsp[-4].ttype, yyvsp[-2].ttype, NULL_TREE, NULL_TREE,
					NULL_TREE);
		  ASM_INPUT_P (yyval.ttype) = 1; ;
    break;}
case 789:
#line 3502 "parse.y"
{ yyval.ttype = finish_asm_stmt (yyvsp[-6].ttype, yyvsp[-4].ttype, yyvsp[-2].ttype, NULL_TREE, NULL_TREE); ;
    break;}
case 790:
#line 3506 "parse.y"
{ yyval.ttype = finish_asm_stmt (yyvsp[-8].ttype, yyvsp[-6].ttype, yyvsp[-4].ttype, yyvsp[-2].ttype, NULL_TREE); ;
    break;}
case 791:
#line 3508 "parse.y"
{ yyval.ttype = finish_asm_stmt (yyvsp[-6].ttype, yyvsp[-4].ttype, NULL_TREE, yyvsp[-2].ttype, NULL_TREE); ;
    break;}
case 792:
#line 3512 "parse.y"
{ yyval.ttype = finish_asm_stmt (yyvsp[-10].ttype, yyvsp[-8].ttype, yyvsp[-6].ttype, yyvsp[-4].ttype, yyvsp[-2].ttype); ;
    break;}
case 793:
#line 3515 "parse.y"
{ yyval.ttype = finish_asm_stmt (yyvsp[-8].ttype, yyvsp[-6].ttype, NULL_TREE, yyvsp[-4].ttype, yyvsp[-2].ttype); ;
    break;}
case 794:
#line 3518 "parse.y"
{ yyval.ttype = finish_asm_stmt (yyvsp[-8].ttype, yyvsp[-6].ttype, yyvsp[-4].ttype, NULL_TREE, yyvsp[-2].ttype); ;
    break;}
case 795:
#line 3520 "parse.y"
{
		  if (pedantic)
		    pedwarn ("ISO C++ forbids computed gotos");
		  yyval.ttype = finish_goto_stmt (yyvsp[-1].ttype);
		;
    break;}
case 796:
#line 3526 "parse.y"
{ yyval.ttype = finish_goto_stmt (yyvsp[-1].ttype); ;
    break;}
case 797:
#line 3528 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 798:
#line 3530 "parse.y"
{ error ("label must be followed by statement");
		  yyungetc ('}', 0);
		  yyval.ttype = NULL_TREE; ;
    break;}
case 799:
#line 3534 "parse.y"
{ finish_stmt ();
		  yyval.ttype = NULL_TREE; ;
    break;}
case 800:
#line 3537 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 801:
#line 3539 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 802:
#line 3541 "parse.y"
{ do_local_using_decl (yyvsp[0].ttype);
		  yyval.ttype = NULL_TREE; ;
    break;}
case 803:
#line 3544 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 804:
#line 3549 "parse.y"
{ yyval.ttype = begin_function_try_block (); ;
    break;}
case 805:
#line 3551 "parse.y"
{ finish_function_try_block (yyvsp[-1].ttype); ;
    break;}
case 806:
#line 3553 "parse.y"
{ finish_function_handler_sequence (yyvsp[-3].ttype); ;
    break;}
case 807:
#line 3558 "parse.y"
{ yyval.ttype = begin_try_block (); ;
    break;}
case 808:
#line 3560 "parse.y"
{ finish_try_block (yyvsp[-1].ttype); ;
    break;}
case 809:
#line 3562 "parse.y"
{ finish_handler_sequence (yyvsp[-3].ttype); ;
    break;}
case 812:
#line 3569 "parse.y"
{ /* Generate a fake handler block to avoid later aborts. */
		  tree fake_handler = begin_handler ();
		  finish_handler_parms (NULL_TREE, fake_handler);
		  finish_handler (fake_handler);
		  yyval.ttype = fake_handler;

		  error ("must have at least one catch per try block");
		;
    break;}
case 813:
#line 3581 "parse.y"
{ yyval.ttype = begin_handler (); ;
    break;}
case 814:
#line 3583 "parse.y"
{ finish_handler_parms (yyvsp[0].ttype, yyvsp[-1].ttype); ;
    break;}
case 815:
#line 3585 "parse.y"
{ finish_handler (yyvsp[-3].ttype); ;
    break;}
case 818:
#line 3595 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 819:
#line 3611 "parse.y"
{
		  check_for_new_type ("inside exception declarations", yyvsp[-1].ftype);
		  yyval.ttype = start_handler_parms (TREE_PURPOSE (yyvsp[-1].ftype.t),
					    TREE_VALUE (yyvsp[-1].ftype.t));
		;
    break;}
case 820:
#line 3620 "parse.y"
{ finish_label_stmt (yyvsp[-1].ttype); ;
    break;}
case 821:
#line 3622 "parse.y"
{ finish_label_stmt (yyvsp[-1].ttype); ;
    break;}
case 822:
#line 3624 "parse.y"
{ finish_label_stmt (yyvsp[-1].ttype); ;
    break;}
case 823:
#line 3626 "parse.y"
{ finish_label_stmt (yyvsp[-1].ttype); ;
    break;}
case 824:
#line 3631 "parse.y"
{ finish_expr_stmt (yyvsp[-1].ttype); ;
    break;}
case 826:
#line 3634 "parse.y"
{ if (pedantic)
		    pedwarn ("ISO C++ forbids compound statements inside for initializations");
		;
    break;}
case 827:
#line 3643 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 829:
#line 3649 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 831:
#line 3652 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 832:
#line 3659 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 835:
#line 3666 "parse.y"
{ yyval.ttype = chainon (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 836:
#line 3671 "parse.y"
{ yyval.ttype = build_tree_list (build_tree_list (NULL_TREE, yyvsp[-3].ttype), yyvsp[-1].ttype); ;
    break;}
case 837:
#line 3673 "parse.y"
{ yyvsp[-5].ttype = build_string (IDENTIFIER_LENGTH (yyvsp[-5].ttype),
				     IDENTIFIER_POINTER (yyvsp[-5].ttype));
		  yyval.ttype = build_tree_list (build_tree_list (yyvsp[-5].ttype, yyvsp[-3].ttype), yyvsp[-1].ttype); ;
    break;}
case 838:
#line 3680 "parse.y"
{ yyval.ttype = tree_cons (NULL_TREE, yyvsp[0].ttype, NULL_TREE);;
    break;}
case 839:
#line 3682 "parse.y"
{ yyval.ttype = tree_cons (NULL_TREE, yyvsp[0].ttype, yyvsp[-2].ttype); ;
    break;}
case 840:
#line 3693 "parse.y"
{
		  yyval.ttype = empty_parms();
		;
    break;}
case 842:
#line 3698 "parse.y"
{ yyval.ttype = finish_parmlist (build_tree_list (NULL_TREE, yyvsp[0].ftype.t), 0);
		  check_for_new_type ("inside parameter list", yyvsp[0].ftype); ;
    break;}
case 843:
#line 3706 "parse.y"
{ yyval.ttype = finish_parmlist (yyval.ttype, 0); ;
    break;}
case 844:
#line 3708 "parse.y"
{ yyval.ttype = finish_parmlist (yyvsp[-1].ttype, 1); ;
    break;}
case 845:
#line 3711 "parse.y"
{ yyval.ttype = finish_parmlist (yyvsp[-1].ttype, 1); ;
    break;}
case 846:
#line 3713 "parse.y"
{ yyval.ttype = finish_parmlist (build_tree_list (NULL_TREE,
							 yyvsp[-1].ftype.t), 1); ;
    break;}
case 847:
#line 3716 "parse.y"
{ yyval.ttype = finish_parmlist (NULL_TREE, 1); ;
    break;}
case 848:
#line 3718 "parse.y"
{
		  /* This helps us recover from really nasty
		     parse errors, for example, a missing right
		     parenthesis.  */
		  yyerror ("possibly missing ')'");
		  yyval.ttype = finish_parmlist (yyvsp[-1].ttype, 0);
		  yyungetc (':', 0);
		  yychar = ')';
		;
    break;}
case 849:
#line 3728 "parse.y"
{
		  /* This helps us recover from really nasty
		     parse errors, for example, a missing right
		     parenthesis.  */
		  yyerror ("possibly missing ')'");
		  yyval.ttype = finish_parmlist (build_tree_list (NULL_TREE,
							 yyvsp[-1].ftype.t), 0);
		  yyungetc (':', 0);
		  yychar = ')';
		;
    break;}
case 850:
#line 3743 "parse.y"
{ maybe_snarf_defarg (); ;
    break;}
case 851:
#line 3745 "parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 854:
#line 3756 "parse.y"
{ check_for_new_type ("in a parameter list", yyvsp[0].ftype);
		  yyval.ttype = build_tree_list (NULL_TREE, yyvsp[0].ftype.t); ;
    break;}
case 855:
#line 3759 "parse.y"
{ check_for_new_type ("in a parameter list", yyvsp[-1].ftype);
		  yyval.ttype = build_tree_list (yyvsp[0].ttype, yyvsp[-1].ftype.t); ;
    break;}
case 856:
#line 3762 "parse.y"
{ check_for_new_type ("in a parameter list", yyvsp[0].ftype);
		  yyval.ttype = chainon (yyval.ttype, yyvsp[0].ftype.t); ;
    break;}
case 857:
#line 3765 "parse.y"
{ yyval.ttype = chainon (yyval.ttype, build_tree_list (NULL_TREE, yyvsp[0].ttype)); ;
    break;}
case 858:
#line 3767 "parse.y"
{ yyval.ttype = chainon (yyval.ttype, build_tree_list (yyvsp[0].ttype, yyvsp[-2].ttype)); ;
    break;}
case 860:
#line 3773 "parse.y"
{ check_for_new_type ("in a parameter list", yyvsp[-1].ftype);
		  yyval.ttype = build_tree_list (NULL_TREE, yyvsp[-1].ftype.t); ;
    break;}
case 861:
#line 3783 "parse.y"
{ yyval.ftype.new_type_flag = yyvsp[-1].ftype.new_type_flag;
		  yyval.ftype.t = build_tree_list (yyvsp[-1].ftype.t, yyvsp[0].ttype); ;
    break;}
case 862:
#line 3786 "parse.y"
{ yyval.ftype.t = build_tree_list (yyvsp[-1].ftype.t, yyvsp[0].ttype);
		  yyval.ftype.new_type_flag = yyvsp[-1].ftype.new_type_flag; ;
    break;}
case 863:
#line 3789 "parse.y"
{ yyval.ftype.t = build_tree_list (build_tree_list (NULL_TREE, yyvsp[-1].ftype.t),
					  yyvsp[0].ttype);
		  yyval.ftype.new_type_flag = yyvsp[-1].ftype.new_type_flag; ;
    break;}
case 864:
#line 3793 "parse.y"
{ yyval.ftype.t = build_tree_list (yyvsp[-1].ftype.t, yyvsp[0].ttype);
		  yyval.ftype.new_type_flag = yyvsp[-1].ftype.new_type_flag; ;
    break;}
case 865:
#line 3796 "parse.y"
{ yyval.ftype.t = build_tree_list (yyvsp[0].ftype.t, NULL_TREE);
		  yyval.ftype.new_type_flag = yyvsp[0].ftype.new_type_flag; ;
    break;}
case 866:
#line 3799 "parse.y"
{ yyval.ftype.t = build_tree_list (yyvsp[-1].ftype.t, yyvsp[0].ttype);
		  yyval.ftype.new_type_flag = 0; ;
    break;}
case 867:
#line 3805 "parse.y"
{ yyval.ftype.t = build_tree_list (NULL_TREE, yyvsp[0].ftype.t);
		  yyval.ftype.new_type_flag = yyvsp[0].ftype.new_type_flag;  ;
    break;}
case 868:
#line 3808 "parse.y"
{ yyval.ftype.t = build_tree_list (yyvsp[0].ttype, yyvsp[-1].ftype.t);
		  yyval.ftype.new_type_flag = yyvsp[-1].ftype.new_type_flag;  ;
    break;}
case 871:
#line 3819 "parse.y"
{ see_typename (); ;
    break;}
case 872:
#line 3824 "parse.y"
{
		  error ("type specifier omitted for parameter");
		  yyval.ttype = build_tree_list (integer_type_node, NULL_TREE);
		;
    break;}
case 873:
#line 3829 "parse.y"
{
		  if (TREE_CODE (yyval.ttype) == SCOPE_REF)
		    {
		      if (TREE_CODE (TREE_OPERAND (yyval.ttype, 0)) == TEMPLATE_TYPE_PARM
			  || TREE_CODE (TREE_OPERAND (yyval.ttype, 0)) == BOUND_TEMPLATE_TEMPLATE_PARM)
			error ("`%E' is not a type, use `typename %E' to make it one", yyval.ttype, yyval.ttype);
		      else
			error ("no type `%D' in `%T'", TREE_OPERAND (yyval.ttype, 1), TREE_OPERAND (yyval.ttype, 0));
		    }
		  else
		    error ("type specifier omitted for parameter `%E'", yyval.ttype);
		  yyval.ttype = build_tree_list (integer_type_node, yyval.ttype);
		;
    break;}
case 874:
#line 3846 "parse.y"
{
                  error("'%D' is used as a type, but is not defined as a type.", yyvsp[-4].ttype);
                  yyvsp[-2].ttype = error_mark_node;
		;
    break;}
case 875:
#line 3854 "parse.y"
{ ;
    break;}
case 877:
#line 3860 "parse.y"
{ ;
    break;}
case 879:
#line 3866 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 880:
#line 3868 "parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 881:
#line 3870 "parse.y"
{ yyval.ttype = empty_except_spec; ;
    break;}
case 882:
#line 3875 "parse.y"
{
		  check_for_new_type ("exception specifier", yyvsp[0].ftype);
		  yyval.ttype = groktypename (yyvsp[0].ftype.t);
		;
    break;}
case 883:
#line 3880 "parse.y"
{ yyval.ttype = error_mark_node; ;
    break;}
case 884:
#line 3885 "parse.y"
{ yyval.ttype = add_exception_specifier (NULL_TREE, yyvsp[0].ttype, 1); ;
    break;}
case 885:
#line 3887 "parse.y"
{ yyval.ttype = add_exception_specifier (yyvsp[-2].ttype, yyvsp[0].ttype, 1); ;
    break;}
case 886:
#line 3892 "parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 887:
#line 3894 "parse.y"
{ yyval.ttype = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 888:
#line 3896 "parse.y"
{ yyval.ttype = make_reference_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 889:
#line 3898 "parse.y"
{ tree arg = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype);
		  yyval.ttype = build_nt (SCOPE_REF, yyvsp[-2].ttype, arg);
		;
    break;}
case 890:
#line 3905 "parse.y"
{
	  saved_scopes = tree_cons (got_scope, got_object, saved_scopes);
	  TREE_LANG_FLAG_0 (saved_scopes) = looking_for_typename;
	  /* We look for conversion-type-id's in both the class and current
	     scopes, just as for ID in 'ptr->ID::'.  */
	  looking_for_typename = 1;
	  got_object = got_scope;
          got_scope = NULL_TREE;
	;
    break;}
case 891:
#line 3917 "parse.y"
{ got_scope = TREE_PURPOSE (saved_scopes);
          got_object = TREE_VALUE (saved_scopes);
	  looking_for_typename = TREE_LANG_FLAG_0 (saved_scopes);
          saved_scopes = TREE_CHAIN (saved_scopes);
	  yyval.ttype = got_scope;
	;
    break;}
case 892:
#line 3927 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (MULT_EXPR)); ;
    break;}
case 893:
#line 3929 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (TRUNC_DIV_EXPR)); ;
    break;}
case 894:
#line 3931 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (TRUNC_MOD_EXPR)); ;
    break;}
case 895:
#line 3933 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (PLUS_EXPR)); ;
    break;}
case 896:
#line 3935 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (MINUS_EXPR)); ;
    break;}
case 897:
#line 3937 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (BIT_AND_EXPR)); ;
    break;}
case 898:
#line 3939 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (BIT_IOR_EXPR)); ;
    break;}
case 899:
#line 3941 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (BIT_XOR_EXPR)); ;
    break;}
case 900:
#line 3943 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (BIT_NOT_EXPR)); ;
    break;}
case 901:
#line 3945 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (COMPOUND_EXPR)); ;
    break;}
case 902:
#line 3947 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (yyvsp[-1].code)); ;
    break;}
case 903:
#line 3949 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (LT_EXPR)); ;
    break;}
case 904:
#line 3951 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (GT_EXPR)); ;
    break;}
case 905:
#line 3953 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (yyvsp[-1].code)); ;
    break;}
case 906:
#line 3955 "parse.y"
{ yyval.ttype = frob_opname (ansi_assopname (yyvsp[-1].code)); ;
    break;}
case 907:
#line 3957 "parse.y"
{ yyval.ttype = frob_opname (ansi_assopname (NOP_EXPR)); ;
    break;}
case 908:
#line 3959 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (yyvsp[-1].code)); ;
    break;}
case 909:
#line 3961 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (yyvsp[-1].code)); ;
    break;}
case 910:
#line 3963 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (POSTINCREMENT_EXPR)); ;
    break;}
case 911:
#line 3965 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (PREDECREMENT_EXPR)); ;
    break;}
case 912:
#line 3967 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (TRUTH_ANDIF_EXPR)); ;
    break;}
case 913:
#line 3969 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (TRUTH_ORIF_EXPR)); ;
    break;}
case 914:
#line 3971 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (TRUTH_NOT_EXPR)); ;
    break;}
case 915:
#line 3973 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (COND_EXPR)); ;
    break;}
case 916:
#line 3975 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (yyvsp[-1].code)); ;
    break;}
case 917:
#line 3977 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (COMPONENT_REF)); ;
    break;}
case 918:
#line 3979 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (MEMBER_REF)); ;
    break;}
case 919:
#line 3981 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (CALL_EXPR)); ;
    break;}
case 920:
#line 3983 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (ARRAY_REF)); ;
    break;}
case 921:
#line 3985 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (NEW_EXPR)); ;
    break;}
case 922:
#line 3987 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (DELETE_EXPR)); ;
    break;}
case 923:
#line 3989 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (VEC_NEW_EXPR)); ;
    break;}
case 924:
#line 3991 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (VEC_DELETE_EXPR)); ;
    break;}
case 925:
#line 3993 "parse.y"
{ yyval.ttype = frob_opname (grokoptypename (yyvsp[-2].ftype.t, yyvsp[-1].ttype, yyvsp[0].ttype)); ;
    break;}
case 926:
#line 3995 "parse.y"
{ yyval.ttype = frob_opname (ansi_opname (ERROR_MARK)); ;
    break;}
case 927:
#line 4002 "parse.y"
{ if (yychar == YYEMPTY)
		    yychar = YYLEX;
		  yyval.itype = lineno; ;
    break;}
}

#line 705 "/usr/share/bison/bison.simple"


  yyvsp -= yylen;
  yyssp -= yylen;
#if YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG
  if (yydebug)
    {
      short *yyssp1 = yyss - 1;
      YYFPRINTF (stderr, "state stack now");
      while (yyssp1 != yyssp)
	YYFPRINTF (stderr, " %d", *++yyssp1);
      YYFPRINTF (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;
#if YYLSP_NEEDED
  *++yylsp = yyloc;
#endif

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  char *yymsg;
	  int yyx, yycount;

	  yycount = 0;
	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  for (yyx = yyn < 0 ? -yyn : 0;
	       yyx < (int) (sizeof (yytname) / sizeof (char *)); yyx++)
	    if (yycheck[yyx + yyn] == yyx)
	      yysize += yystrlen (yytname[yyx]) + 15, yycount++;
	  yysize += yystrlen ("parse error, unexpected ") + 1;
	  yysize += yystrlen (yytname[YYTRANSLATE (yychar)]);
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "parse error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[YYTRANSLATE (yychar)]);

	      if (yycount < 5)
		{
		  yycount = 0;
		  for (yyx = yyn < 0 ? -yyn : 0;
		       yyx < (int) (sizeof (yytname) / sizeof (char *));
		       yyx++)
		    if (yycheck[yyx + yyn] == yyx)
		      {
			const char *yyq = ! yycount ? ", expecting " : " or ";
			yyp = yystpcpy (yyp, yyq);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yycount++;
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exhausted");
	}
      else
#endif /* defined (YYERROR_VERBOSE) */
	yyerror ("parse error");
    }
  goto yyerrlab1;


/*--------------------------------------------------.
| yyerrlab1 -- error raised explicitly by an action |
`--------------------------------------------------*/
yyerrlab1:
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;
      YYDPRINTF ((stderr, "Discarding token %d (%s).\n",
		  yychar, yytname[yychar1]));
      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;


/*-------------------------------------------------------------------.
| yyerrdefault -- current state does not do anything special for the |
| error token.                                                       |
`-------------------------------------------------------------------*/
yyerrdefault:
#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */

  /* If its default is to accept any token, ok.  Otherwise pop it.  */
  yyn = yydefact[yystate];
  if (yyn)
    goto yydefault;
#endif


/*---------------------------------------------------------------.
| yyerrpop -- pop the current state because it cannot handle the |
| error token                                                    |
`---------------------------------------------------------------*/
yyerrpop:
  if (yyssp == yyss)
    YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#if YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG
  if (yydebug)
    {
      short *yyssp1 = yyss - 1;
      YYFPRINTF (stderr, "Error: state stack now");
      while (yyssp1 != yyssp)
	YYFPRINTF (stderr, " %d", *++yyssp1);
      YYFPRINTF (stderr, "\n");
    }
#endif

/*--------------.
| yyerrhandle.  |
`--------------*/
yyerrhandle:
  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;
#if YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

/*---------------------------------------------.
| yyoverflowab -- parser overflow comes here.  |
`---------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}
#line 4006 "parse.y"


#ifdef SPEW_DEBUG
const char *
debug_yytranslate (value)
    int value;
{
  return yytname[YYTRANSLATE (value)];
}
#endif

/* Free malloced parser stacks if necessary.  */

void
free_parser_stacks ()
{
  if (malloced_yyss)
    {
      free (malloced_yyss);
      free (malloced_yyvs);
    }
}

/* Return the value corresponding to TOKEN in the global scope.  */

static tree
parse_scoped_id (token)
     tree token;
{
  cxx_binding binding;
 
  cxx_binding_clear (&binding);
  if (!qualified_lookup_using_namespace (token, global_namespace, &binding, 0))
    binding.value = NULL;
  if (yychar == YYEMPTY)
    yychar = yylex();

  return do_scoped_id (token, binding.value);
}

/* AGGR may be either a type node (like class_type_node) or a
   TREE_LIST whose TREE_PURPOSE is a list of attributes and whose
   TREE_VALUE is a type node.  Set *TAG_KIND and *ATTRIBUTES to
   represent the information encoded.  */

static void
parse_split_aggr (tree aggr, enum tag_types *tag_kind, tree *attributes)
{
  if (TREE_CODE (aggr) == TREE_LIST) 
    {
      *attributes = TREE_PURPOSE (aggr);
      aggr = TREE_VALUE (aggr);
    }
  else
    *attributes = NULL_TREE;
  *tag_kind = (enum tag_types) tree_low_cst (aggr, 1);
}

/* Like xref_tag, except that the AGGR may be either a type node (like
   class_type_node) or a TREE_LIST whose TREE_PURPOSE is a list of
   attributes and whose TREE_VALUE is a type node.  */

static tree
parse_xref_tag (tree aggr, tree name, int globalize)
{
  tree attributes;
  enum tag_types tag_kind;
  parse_split_aggr (aggr, &tag_kind, &attributes);
  return xref_tag (tag_kind, name, attributes, globalize);
}

/* Like handle_class_head, but AGGR may be as for parse_xref_tag.  */

static tree
parse_handle_class_head (tree aggr, tree scope, tree id, 
			 int defn_p, int *new_type_p)
{
  tree attributes;
  enum tag_types tag_kind;
  parse_split_aggr (aggr, &tag_kind, &attributes);
  return handle_class_head (tag_kind, scope, id, attributes, 
			    defn_p, new_type_p);
}

/* Like do_decl_instantiation, but the declarator has not yet been
   parsed.  */

static void
parse_decl_instantiation (tree declspecs, tree declarator, tree storage)
{
  tree decl = grokdeclarator (declarator, declspecs, NORMAL, 0, NULL);
  do_decl_instantiation (decl, storage);
}

/* Like begin_function_definition, but SPECS_ATTRS is a combined list
   containing both a decl-specifier-seq and attributes.  */

static int
parse_begin_function_definition (tree specs_attrs, tree declarator)
{
  tree specs;
  tree attrs;
  
  split_specs_attrs (specs_attrs, &specs, &attrs);
  return begin_function_definition (specs, attrs, declarator);
}

/* Like finish_call_expr, but the name for FN has not yet been
   resolved.  */

static tree
parse_finish_call_expr (tree fn, tree args, int koenig)
{
  bool disallow_virtual;

  if (TREE_CODE (fn) == OFFSET_REF)
    return build_offset_ref_call_from_tree (fn, args);

  if (TREE_CODE (fn) == SCOPE_REF)
    {
      tree scope = TREE_OPERAND (fn, 0);
      tree name = TREE_OPERAND (fn, 1);

      if (scope == error_mark_node || name == error_mark_node)
	return error_mark_node;
      if (!processing_template_decl)
	fn = resolve_scoped_fn_name (scope, name);
      disallow_virtual = true;
    }
  else
    disallow_virtual = false;

  if (koenig && TREE_CODE (fn) == IDENTIFIER_NODE)
    {
      tree f;
      
      /* Do the Koenig lookup.  */
      fn = do_identifier (fn, 2, args);
      /* If name lookup didn't find any matching declarations, we've
	 got an unbound identifier.  */
      if (TREE_CODE (fn) == IDENTIFIER_NODE)
	{
	  /* For some reason, do_identifier does not resolve
	     conversion operator names if the only matches would be
	     template conversion operators.  So, we do it here.  */
	  if (IDENTIFIER_TYPENAME_P (fn) && current_class_type)
	    {
	      f = lookup_member (current_class_type, fn,
				 /*protect=*/1, /*want_type=*/0);
	      if (f)
		return finish_call_expr (f, args,
					 /*disallow_virtual=*/false);
	    }
	  /* If the name still could not be resolved, then the program
	     is ill-formed.  */
	  if (TREE_CODE (fn) == IDENTIFIER_NODE)
	    {
	      unqualified_name_lookup_error (fn);
	      return error_mark_node;
	    }
	}
      else if (TREE_CODE (fn) == FUNCTION_DECL
	       || DECL_FUNCTION_TEMPLATE_P (fn)
	       || TREE_CODE (fn) == OVERLOAD)
	{
	  tree scope = DECL_CONTEXT (get_first_fn (fn));
	  if (scope && TYPE_P (scope))
	    {
	      tree access_scope;

	      if (DERIVED_FROM_P (scope, current_class_type)
		  && current_class_ref)
		{
		  fn = build_baselink (lookup_base (current_class_type,
						    scope,
						    ba_any,
						    NULL),
				       TYPE_BINFO (current_class_type),
				       fn,
				       /*optype=*/NULL_TREE);
		  return finish_object_call_expr (fn,
						  current_class_ref,
						  args);
		}


	      access_scope = current_class_type;
	      while (!DERIVED_FROM_P (scope, access_scope))
		{
		  access_scope = TYPE_CONTEXT (access_scope);
		  while (DECL_P (access_scope))
		    access_scope = DECL_CONTEXT (access_scope);
		}
	      
	      fn = build_baselink (NULL_TREE,
				   TYPE_BINFO (access_scope),
				   fn,
				   /*optype=*/NULL_TREE);
	    }
	}
    }

  if (TREE_CODE (fn) == COMPONENT_REF)
    /* If the parser sees `(x->y)(bar)' we get here because the
       parentheses confuse the parser.  Treat this like 
       `x->y(bar)'.  */
    return finish_object_call_expr (TREE_OPERAND (fn, 1),
				    TREE_OPERAND (fn, 0),
				    args);

  if (processing_template_decl)
    return build_nt (CALL_EXPR, fn, args, NULL_TREE);

  return build_call_from_tree (fn, args, disallow_virtual);
}

#include "gt-cp-parse.h"
