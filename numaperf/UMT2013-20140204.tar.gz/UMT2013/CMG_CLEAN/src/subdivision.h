void hexIntoPyr            (Subdivision *this, int *nodeIdList);
void hexIntoPriAndPyr      (Subdivision *this, int *nodeIdList);
void hexIntoHexAndPri      (Subdivision *this, int *nodeIdList);
void hexIntoHex            (Subdivision *this, int *nodeIdList);
void priIntoPyrAndTet      (Subdivision *this, int *nodeIdList);
void priIntoPriAndTet      (Subdivision *this, int *nodeIdList);
void priIntoPri            (Subdivision *this, int *nodeIdList);
void pyrIntoPyrAndTet      (Subdivision *this, int *nodeIdList);
void pyrIntoPriAndPyrAndTet(Subdivision *this, int *nodeIdList);
void pyrIntoHexAndPyr      (Subdivision *this, int *nodeIdList);

