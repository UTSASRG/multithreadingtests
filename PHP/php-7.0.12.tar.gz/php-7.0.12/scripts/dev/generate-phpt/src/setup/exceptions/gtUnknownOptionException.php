<?php

  class gtUnknownOptionException extends RuntimeException
  {
  }

?>
