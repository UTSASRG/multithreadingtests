#include "geom/CMI/MeshBase.hh"
#include "Region.cc"
using namespace Geometry;

template class Region< MeshBase >;
