#include "geom/CMI/MeshBase.hh"
#include "communication/DomainNeighborMap.cc"
using namespace Communication;
using namespace Geometry;

template class DomainNeighborMap< FaceBase >;
 
