#ifndef __NODE_BASE__
#define __NODE_BASE__



class NodeBase
#endif
